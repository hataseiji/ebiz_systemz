DROP FUNCTION IF EXISTS marume;
DELIMITER //
CREATE FUNCTION marume(
    _I_marume             tinyint(1),
    _I_kurai			  tinyint(2),
    _I_kingaku            decimal(17,5)
) returns decimal(17,5)
/*
    数字をまるめます
	_I_marume		まるめ方法		0:四捨五入 1:切捨て 2:切上げ
	_I_kurai        位取り		0:円単位 1:十円単位 2:百円単位 3:千円単位
*/
BEGIN
	DECLARE _O_kingaku      decimal(17,5) DEFAULT 0;
	DECLARE _W_kingaku      decimal(17,5) DEFAULT 0;
	DECLARE _marume         decimal(17,5);
	DECLARE _sign           tinyint;

	IF _I_marume < 0 or _I_marume > 2 THEN 
		return _I_kingaku;
	END IF;
	IF _I_kurai < 0 or _I_kurai > 3 THEN 
		return _I_kingaku;
	END IF;

	SET _sign = 1;
	IF _I_kingaku < 0 THEN
		SET _sign = -1;
 	END IF;
	SET _W_kingaku  = _I_kingaku * _sign;

	SET _I_kurai = _I_kurai * -1;
    IF _I_marume = 0 THEN       -- 四捨五入
    	IF _I_kurai = 0 THEN
    		SET _marume = 0.5;
    	ELSEIF _I_kurai = -1 THEN
    		SET _marume = 5;
    	ELSEIF _I_kurai = -2 THEN
    		SET _marume = 50;
    	ELSEIF _I_kurai = -3 THEN
    		SET _marume = 500;
    	END IF;
        SET _O_kingaku = TRUNCATE(_W_kingaku + _marume, _I_kurai);
    ELSEIF _I_marume = 1 THEN  -- 切り捨て
        SET _O_kingaku = TRUNCATE(_W_kingaku, _I_kurai);
    ELSEIF _I_marume = 2 THEN  -- 切り上げ
    	IF _I_kurai = 0 THEN
    		SET _marume = 0.99999;
    	ELSEIF _I_kurai = -1 THEN
    		SET _marume = 9.99999;
    	ELSEIF _I_kurai = -2 THEN
    		SET _marume = 99.99999;
    	ELSEIF _I_kurai = -3 THEN
    		SET _marume = 999.99999;
    	END IF;
        SET _O_kingaku = TRUNCATE(_W_kingaku + _marume, _I_kurai);
    END IF;
    return _O_kingaku * _sign;
END;
//
DELIMITER ;
