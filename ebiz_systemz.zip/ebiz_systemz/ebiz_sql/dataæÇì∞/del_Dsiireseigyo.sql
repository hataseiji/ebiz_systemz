DROP PROCEDURE IF EXISTS del_Dsiireseigyo;
DELIMITER //
CREATE PROCEDURE del_Dsiireseigyo (
    IN _i_kaikeiNendo      integer(4),
    IN _i_denpyouNO        integer(6),
    OUT _o_ErrorMsg        varchar(256),
    OUT _o_Result        Boolean
)
BEGIN
    DECLARE _counter integer;

    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    select count(*) INTO _counter from Dsiireseigyo where kaikeinendo = _i_kaikeinendo and denpyouNO = _i_denpyouNO;
    if _counter = 0 then
        set _o_ErrorMsg = '存在しないレコードです。';
    else
        -- データ更新
        delete from Dsiireseigyo where kaikeinendo = _i_kaikeinendo and denpyouNO = _i_denpyouNO;
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
