drop trigger IF EXISTS tri_del_Didou;
delimiter ;;
CREATE TRIGGER `tri_del_Didou` AFTER DELETE ON `Didou` FOR EACH ROW BEGIN
    INSERT INTO Didoulog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        idouKBN,
        idoudate,
        motosoukoCD,
        sakisoukoCD,
        denpyou_tekiyou1,
        denpyou_tekiyou2,
        midouKBN,
        syouhinCD,
        syouhinNM,
        tyoubo,
        suryou,
        taniCD,
        tanka,
        kingaku,
        meisai_tekiyou,
        insertdate,
        insertTantosya
    )
    values
    (
        OLD.kaikeiNendo,
        OLD.denpyouNO,
        OLD.gyouNO,
        1,
        1,

        cal_KeijouDate(OLD.idoudate),
        OLD.dataKBN,
        OLD.torihikiKBN,
        OLD.idouKBN,
        OLD.idoudate,
        OLD.motosoukoCD,
        OLD.sakisoukoCD,
        OLD.denpyou_tekiyou1,
        OLD.denpyou_tekiyou2,
        OLD.midouKBN,
        OLD.syouhinCD,
        OLD.syouhinNM,
        OLD.tyoubo * -1,
        OLD.suryou * -1,
        OLD.taniCD,
        OLD.tanka,
        OLD.kingaku * -1,
        OLD.meisai_tekiyou,
        CURRENT_TIMESTAMP(),
        OLD.insertTantosya
    );

    update Didoulog set yuukou=1
    WHERE   kaikeiNendo = OLD.kaikeiNendo
        and denpyouNO   = OLD.denpyouNO;

    END;
 ;;
delimiter ;
