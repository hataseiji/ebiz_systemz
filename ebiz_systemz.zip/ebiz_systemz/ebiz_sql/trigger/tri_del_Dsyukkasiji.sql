drop trigger IF EXISTS tri_del_Dsyukkasiji;
delimiter ;;
CREATE TRIGGER `tri_del_Dsyukkasiji` AFTER DELETE ON `Dsyukkasiji` FOR EACH ROW BEGIN
    INSERT INTO Dsyukkasijilog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        syukkasijiKBN,
        syukkasijidate,
        soukoCD,
        jutyuuKaikeiNendo,
        jutyuuNO,
        jutyuu_gyouNO,
        msyukkasijiKBN,
        syouhinCD,
        syouhinNM,
        suryou,
        sijisuryou,
        taniCD,
        nouki,
        syukka_flg,
        syukkaKaikeiNendo,
        syukkaNO,
        syukka_gyouNO,
        tokuisakiNM,
        insertdate,
        insertTantosya
    )
    values
    (
        OLD.kaikeiNendo,
        OLD.denpyouNO,
        OLD.gyouNO,
        1,
        1,
        cal_KeijouDate(OLD.syukkasijidate),
        OLD.dataKBN,
        OLD.torihikiKBN,
        OLD.syukkasijiKBN,
        OLD.syukkasijidate,
        OLD.soukoCD,
        OLD.jutyuuKaikeiNendo,
        OLD.jutyuuNO,
        OLD.jutyuu_gyouNO,
        OLD.msyukkasijiKBN,
        OLD.syouhinCD,
        OLD.syouhinNM,
        OLD.suryou * -1,
        OLD.sijisuryou * -1,
        OLD.taniCD,
        OLD.nouki,
        OLD.syukka_flg,
        OLD.syukkaKaikeiNendo,
        OLD.syukkaNO,
        OLD.syukka_gyouNO,
        OLD.tokuisakiNM,
        CURRENT_TIMESTAMP(),
        OLD.insertTantosya
    );

    update Dsyukkasijilog set yuukou=1
    WHERE   kaikeiNendo = OLD.kaikeiNendo
        and denpyouNO   = OLD.denpyouNO;
END;
 ;;
delimiter ;
