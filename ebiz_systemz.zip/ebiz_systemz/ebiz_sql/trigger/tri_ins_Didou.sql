drop trigger IF EXISTS tri_ins_Didou;
delimiter ;;
CREATE TRIGGER `tri_ins_Didou` AFTER INSERT ON `Didou` FOR EACH ROW BEGIN
    INSERT INTO Didoulog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        idouKBN,
        idoudate,
        motosoukoCD,
        sakisoukoCD,
        denpyou_tekiyou1,
        denpyou_tekiyou2,
        midouKBN,
        syouhinCD,
        syouhinNM,
        tyoubo,  -- 2013/12/07
        suryou,
        taniCD,
        tanka,
        kingaku,
        meisai_tekiyou,
        DenpyouHakkou,
        insertdate,
        insertTantosya
    )
    values
    (
        NEW.kaikeiNendo,
        NEW.denpyouNO,
        NEW.gyouNO,
        0, /* 黒 */
        0, /* 有効 */
        cal_KeijouDate(NEW.idoudate),
        NEW.dataKBN,
        NEW.torihikiKBN,
        NEW.idouKBN,
        NEW.idoudate,
        NEW.motosoukoCD,
        NEW.sakisoukoCD,
        NEW.denpyou_tekiyou1,
        NEW.denpyou_tekiyou2,
        NEW.midouKBN,
        NEW.syouhinCD,
        NEW.syouhinNM,
        NEW.tyoubo,  -- 2013/12/07
        NEW.suryou,
        NEW.taniCD,
        NEW.tanka,
        NEW.kingaku,
        NEW.meisai_tekiyou,
        NEW.DenpyouHakkou,
        CURRENT_TIMESTAMP(),
        NEW.insertTantosya
    );
END;
 ;;
delimiter ;
