drop trigger IF EXISTS tri_del_Dsyukka;
delimiter ;;
CREATE TRIGGER `tri_del_Dsyukka` AFTER DELETE ON `Dsyukka` FOR EACH ROW BEGIN
    INSERT INTO Dsyukkalog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        syukkaKBN,
        jutyuuKaikeiNendo,
        jutyuuNO,
        jutyuu_gyouNO,
        uriageKaikeiNendo,
        uriageNO,
        uriage_gyouNO,
        syukkadate,
        soukoCD,
        denpyou_tekiyou1,
        denpyou_tekiyou2,
        nouhinsyo_tankaKBN,
        msyukkaKBN,
        syouhinCD,
        syouhinNM,
        suryou,
        taniCD,
        tanka,
        kingaku,
        meisai_tekiyou,
        hontai_kingaku,
        syouhizei,
        DenpyouHakkou,
        NouhinsyoHakkou, -- 2013/12/02
        updDataKBN,
        insertdate,
        insertTantosya
    )
    values
    (
        OLD.kaikeiNendo,
        OLD.denpyouNO,
        OLD.gyouNO,
        1,  /* 赤 */
        1,  /* 無効 */
        -- OLD.keijounengetu,
        cal_KeijouDate(OLD.syukkadate),
        OLD.dataKBN,
        OLD.torihikiKBN,
        OLD.syukkaKBN,
        OLD.jutyuuKaikeiNendo,
        OLD.jutyuuNO,
        OLD.jutyuu_gyouNO,
        OLD.uriageKaikeiNendo,
        OLD.uriageNO,
        OLD.uriage_gyouNO,
        OLD.syukkadate,
        OLD.soukoCD,
        OLD.denpyou_tekiyou1,
        OLD.denpyou_tekiyou2,
        OLD.nouhinsyo_tankaKBN,
        OLD.msyukkaKBN,
        OLD.syouhinCD,
        OLD.syouhinNM,
        OLD.suryou * -1,
        OLD.taniCD,
        OLD.tanka,
        OLD.kingaku * -1,
        OLD.meisai_tekiyou,
        OLD.hontai_kingaku * -1,
        OLD.syouhizei * -1,
        OLD.DenpyouHakkou,
        OLD.NouhinsyoHakkou, -- 2013/12/02
        OLD.updDataKBN,
        OLD.insertdate,
        OLD.insertTantosya
    );
    -- 全てのログは無効
    update Dsyukkalog set yuukou=1 where kaikeiNendo=OLD.kaikeiNendo and denpyouNO=OLD.denpyouNO;
END;
 ;;
delimiter ;
