drop trigger IF EXISTS tri_UriageToUrikake;
delimiter ;;
CREATE TRIGGER `tri_UriageToUrikake` AFTER INSERT ON `Duriagelog` FOR EACH ROW BEGIN
    DECLARE _int_counter        integer;       /* insert可否 (明細の有無) */
    DECLARE _keijoutukisuu      tinyint(2);    /* 計上月数 (期首年月からの経過月数) */
    DECLARE _kisyu_yyyymm       integer(6);    /* 期首年月 */
    DECLARE _kaikei_nendo       integer(4);    /* 会計年度 */
    DECLARE _yosan              decimal(12);    /* 予算 */
    DECLARE _uriagegaku         decimal(12);    /* 売上 */
    DECLARE _hennpinngaku       decimal(12);    /* 返品 */
    DECLARE _nebikigaku         decimal(12);    /* 値引 */
    DECLARE _nyuukinngaku       decimal(12);    /* 入金 */
    DECLARE _syouhizeigaku      decimal(12);    /* 消費税 */

    /* 管理マスタ.期首年月取得 */
    select kisyu_yyyymm, kaikei_nendo into _kisyu_yyyymm, _kaikei_nendo from Mkanri where kanriCD=1;

    /* 計上月数算出 */
    SET _keijoutukisuu = NEW.keijounengetu - _kisyu_yyyymm;
    if _keijoutukisuu >= 97 then
        SET _keijoutukisuu = _keijoutukisuu - 88;
    end if;

    SET _yosan         = 0;
    SET _uriagegaku    = 0;
    SET _hennpinngaku  = 0;
    SET _nebikigaku    = 0;
    SET _nyuukinngaku  = 0;
    SET _syouhizeigaku = 0;

    /* 取引区分により集計先を切り分ける */
    if NEW.torihikiKBN = 10 or NEW.torihikiKBN = 11 then
        SET _uriagegaku = NEW.hontai_kingaku;
        SET _syouhizeigaku = NEW.kaikei_syouhizei;
    elseif NEW.torihikiKBN = 20 then
        SET _hennpinngaku = NEW.hontai_kingaku;
        SET _syouhizeigaku = NEW.kaikei_syouhizei;
    elseif NEW.torihikiKBN = 30 then
        SET _nebikigaku = NEW.hontai_kingaku;
        SET _syouhizeigaku = NEW.kaikei_syouhizei;
    elseif NEW.torihikiKBN = 81 or NEW.torihikiKBN = 82 then
        SET _syouhizeigaku = NEW.kaikei_syouhizei;
    end if;

    /* 得意先別月別売掛ファイル更新 */
    select count(*) INTO _int_counter from Durikakezan DUZN where DUZN.tokuisakiCD = NEW.tokuisakiCD and DUZN.keijounengetu = NEW.keijounengetu;
    if _int_counter = 0 then

        INSERT INTO Durikakezan
        (
            tokuisakiCD,
            keijounengetu,
            keijoutukisuu,
            kaikeinendo,
            yosan,
            zan,
            uriagegaku,
            hennpinngaku,
            nebikigaku,
            nyuukinngaku,
            syouhizeigaku,
            genka,
            insertdate,
            insertTantosya,
            updatedate,
            updateTantosya
        )
        values
        (
            NEW.tokuisakiCD,
            NEW.keijounengetu,
            _keijoutukisuu,
            _kaikei_nendo,
            _yosan,
            0,
            _uriagegaku,
            _hennpinngaku,
            _nebikigaku,
            _nyuukinngaku,
            _syouhizeigaku,
            NEW.genka_kingaku,
            NEW.insertdate,
            NEW.insertTantosya,
            NEW.insertdate,
            NEW.insertTantosya
        );
    else
        update Durikakezan set
            keijoutukisuu  = _keijoutukisuu,
            kaikeinendo    = _kaikei_nendo,
            yosan          = yosan         + _yosan,
            uriagegaku     = uriagegaku    + _uriagegaku,
            hennpinngaku   = hennpinngaku  + _hennpinngaku,
            nebikigaku     = nebikigaku    + _nebikigaku,
            nyuukinngaku   = nyuukinngaku  + _nyuukinngaku,
            syouhizeigaku  = syouhizeigaku + _syouhizeigaku,
            genka          = genka         + NEW.genka_kingaku,
            updatedate    = NEW.insertdate,
            updateTantosya = NEW.insertTantosya
        where
                tokuisakiCD    = NEW.tokuisakiCD
            and keijounengetu  = NEW.keijounengetu;
    end if;

    /* 月別商品売上実績ファイル更新 */
    select count(*) INTO _int_counter from Dsyouhinuriage where syouhinCD = NEW.syouhinCD and keijounengetu = NEW.keijounengetu;
    if _int_counter = 0 then

        INSERT INTO Dsyouhinuriage
        (
            syouhinCD,
            keijounengetu,
            keijoutukisuu,
            kaikeiNendo,
            uriagegaku,
            hennpinngaku,
            nebikigaku,
            syouhizeigaku,
            genka,
            insertdate,
            insertTantosya,
            updatedate,
            updateTantosya
        )
        values
        (
            NEW.syouhinCD,
            NEW.keijounengetu,
            _keijoutukisuu,
            _kaikei_nendo,
            _uriagegaku,
            _hennpinngaku,
            _nebikigaku,
            _syouhizeigaku,
            NEW.genka_kingaku,
            NEW.insertdate,
            NEW.insertTantosya,
            NEW.insertdate,
            NEW.insertTantosya
        );
    else
        update Dsyouhinuriage set
            keijoutukisuu  = _keijoutukisuu,
            uriagegaku     = uriagegaku    + _uriagegaku,
            hennpinngaku   = hennpinngaku  + _hennpinngaku,
            nebikigaku     = nebikigaku    + _nebikigaku,
            syouhizeigaku  = syouhizeigaku + _syouhizeigaku,
            genka          = genka         + NEW.genka_kingaku,
            updatedate    = NEW.insertdate,
            updateTantosya = NEW.insertTantosya
        where
                syouhinCD      = NEW.syouhinCD
            and keijounengetu  = NEW.keijounengetu;
    end if;
END;
 ;;
delimiter ;
