DROP PROCEDURE IF EXISTS upd_Msouko;
DELIMITER //
CREATE PROCEDURE upd_Msouko (
     IN _i_soukoCD         integer(6),
     IN _i_soukoNM         varchar(40),
     IN _i_soukoRNM        varchar(20),
     IN _i_soukoKNM        varchar(20),
     IN _i_postalCD        varchar(8),
     IN _i_address1        varchar(40),
     IN _i_address2        varchar(40),
     IN _i_tel1            varchar(20),
     IN _i_tel2            varchar(20),
     IN _i_fax             varchar(20),
     IN _i_soukoKBN        tinyint(1),
     IN _i_jigyosyoCD      tinyint(2),
     IN _i_jisyaKBN        tinyint(1),
     IN _i_insertdate      datetime,
     IN _i_insertTantosya  integer(6),
     IN _i_updatedate      datetime,
     IN _i_updateTantosya  integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Msouko where soukoCD = _i_soukoCD;
    if _counter = 0 then
        set _o_ErrorMsg = 'マスタに存在しないコードです。';
    else
        -- データ更新
        update Msouko 
            set
            soukoNM          = _i_soukoNM         ,
            soukoRNM         = _i_soukoRNM        ,
            soukoKNM         = _i_soukoKNM        ,
            postalCD         = _i_postalCD        ,
            address1         = _i_address1        ,
            address2         = _i_address2        ,
            tel1             = _i_tel1            ,
            tel2             = _i_tel2            ,
            fax              = _i_fax             ,
            soukoKBN         = _i_soukoKBN        ,
            jigyosyoCD       = _i_jigyosyoCD      ,
            jisyaKBN         = _i_jisyaKBN        ,
            updatedate       = _i_updatedate      ,
            updateTantosya   = _i_updateTantosya  
        where soukoCD          = _i_soukoCD       ;

        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
