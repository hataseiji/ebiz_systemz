DROP PROCEDURE IF EXISTS ins_Mmaker;
DELIMITER //
CREATE PROCEDURE ins_Mmaker (
     IN _i_makerCD                     integer(6),
     IN _i_makerNM                     varchar(40),
     IN _i_makerRNM                    varchar(20),
     IN _i_makerKNM                    varchar(20),
     IN _i_keisyo                      varchar(8),
     IN _i_postalCD                    varchar(8),
     IN _i_address1                    varchar(40),
     IN _i_address2                    varchar(40),
     IN _i_tel1                        varchar(20),
     IN _i_naisen1                     varchar(10),
     IN _i_tel2                        varchar(20),
     IN _i_naisen2                     varchar(10),
     IN _i_fax                         varchar(20),
     IN _i_maker_tantousyaNM           varchar(40),
     IN _i_maker_tantousyabusyoNM      varchar(20),
     IN _i_maker_tantousyayakusyokuNM  varchar(24),
     IN _i_daihyousyaNM                varchar(40),
     IN _i_daihyousyayakusyokuNM       varchar(40),
     IN _i_tantousyaCD                 varchar(9),
     IN _i_totalization1               varchar(9),
     IN _i_totalization2               varchar(9),
     IN _i_totalization3               varchar(9),
     IN _i_totalization4               varchar(9),
     IN _i_totalization5               varchar(9),
     IN _i_insertdate                  datetime,
     IN _i_insertTantosya              integer(6),
     IN _i_updatedate                  datetime,
     IN _i_updateTantosya              integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Mmaker where makerCD = _i_makerCD;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Mmaker (
            makerCD                     ,
            makerNM                     ,
            makerRNM                    ,
            makerKNM                    ,
            keisyo                      ,
            postalCD                    ,
            address1                    ,
            address2                    ,
            tel1                        ,
            naisen1                     ,
            tel2                        ,
            naisen2                     ,
            fax                         ,
            maker_tantousyaNM           ,
            maker_tantousyabusyoNM      ,
            maker_tantousyayakusyokuNM  ,
            daihyousyaNM                ,
            daihyousyayakusyokuNM       ,
            tantousyaCD                 ,
            totalization1               ,
            totalization2               ,
            totalization3               ,
            totalization4               ,
            totalization5               ,
            insertdate                  ,
            insertTantosya              ,
            updatedate                  ,
            updateTantosya              
        )
        values
        (
            _i_makerCD                     ,
            _i_makerNM                     ,
            _i_makerRNM                    ,
            _i_makerKNM                    ,
            _i_keisyo                      ,
            _i_postalCD                    ,
            _i_address1                    ,
            _i_address2                    ,
            _i_tel1                        ,
            _i_naisen1                     ,
            _i_tel2                        ,
            _i_naisen2                     ,
            _i_fax                         ,
            _i_maker_tantousyaNM           ,
            _i_maker_tantousyabusyoNM      ,
            _i_maker_tantousyayakusyokuNM  ,
            _i_daihyousyaNM                ,
            _i_daihyousyayakusyokuNM       ,
            _i_tantousyaCD                 ,
            _i_totalization1               ,
            _i_totalization2               ,
            _i_totalization3               ,
            _i_totalization4               ,
            _i_totalization5               ,
            _i_insertdate                  ,
            _i_insertTantosya              ,
            _i_insertdate                  ,
            _i_insertTantosya              
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
