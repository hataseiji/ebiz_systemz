DROP PROCEDURE IF EXISTS GetujiKakuteiUrikakezan;
DELIMITER //
CREATE PROCEDURE GetujiKakuteiUrikakezan(
    IN  _I_date         date,
    IN  _I_Tantosya     integer(6),
    OUT _o_ErrorMsg      varchar(256),
    OUT _o_Result        Boolean
)
BEGIN
/*
    月次更新
    売掛データの繰り越しを行います。
*/
    DECLARE _counter                  integer;
    DECLARE _kaikei_yyyymm            integer; /* 処理年月 */
    DECLARE _yoku_kaikei_yyyymm       integer; /* 処理年月の翌月 */
    DECLARE _keika_tukisuu            tinyint(2) DEFAULT 0;
    DECLARE _kaikei_nendo             integer(4) DEFAULT 0;
    DECLARE _wDate                    date;

    DECLARE _tokuisakiCD              integer(6) DEFAULT 0;
    DECLARE _keijoutukisuu            tinyint(2);
    DECLARE _keijounengetu            integer(6) DEFAULT 0;
    DECLARE _kaikeiNendo              integer(4) DEFAULT 0;

    DECLARE _yoku                     decimal(12,0) DEFAULT 0;
    DECLARE _yosan                    decimal(12,0) DEFAULT 0;
    DECLARE _zan                      decimal(12,0) DEFAULT 0;
    DECLARE _uriagegaku               decimal(12,0) DEFAULT 0;
    DECLARE _hennpinngaku             decimal(12,0) DEFAULT 0;
    DECLARE _nebikigaku               decimal(12,0) DEFAULT 0;
    DECLARE _nyuukinngaku             decimal(12,0) DEFAULT 0;
    DECLARE _syouhizeigaku            decimal(12,0) DEFAULT 0;
    DECLARE done                      INT DEFAULT 0;

    DECLARE curUri CURSOR FOR
        select
            tokuisakiCD,
            keijoutukisuu,
            kaikeiNendo,
            yosan,
            zan,
            uriagegaku,
            hennpinngaku,
            nebikigaku,
            nyuukinngaku,
            syouhizeigaku
        from Durikakezan
        where   Durikakezan.keijounengetu = _kaikei_yyyymm;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    /* 処理年月の取得 */
    select kaikei_yyyymm,keikatu_kisuu,kaikei_nendo into _kaikei_yyyymm,_keika_tukisuu,_kaikei_nendo from Mkanri where kanriCD = 1;
    if _kaikei_yyyymm is NULL then
        set _kaikei_yyyymm = 200104;
    end if;
    set _keika_tukisuu = _keika_tukisuu + 1;
    if _keika_tukisuu > 11 then
        set _keika_tukisuu = 0;
        SET _kaikei_nendo = _kaikei_nendo + 1;
    end if;

    /* 翌月の処理年月算出 */
    SET _wDate = _kaikei_yyyymm * 100 + 01;
    SET _yoku_kaikei_yyyymm = EXTRACT(YEAR_MONTH FROM _wDate + INTERVAL 1 MONTH);

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    OPEN curUri;

    REPEAT
    FETCH curUri
    INTO
        _tokuisakiCD,
        _keijoutukisuu,
        _kaikeiNendo,
        _yosan,
        _zan,
        _uriagegaku,
        _hennpinngaku,
        _nebikigaku,
        _nyuukinngaku,
        _syouhizeigaku;

    IF done = 0 THEN

        /* 翌月繰越額算出 */
        set _yoku =
                    _zan
                +   _uriagegaku
                -   _hennpinngaku
                -   _nebikigaku
                -   _nyuukinngaku
                +   _syouhizeigaku
                ;

        select count(*) INTO _counter from Durikakezan where Durikakezan.tokuisakiCD = _tokuisakiCD and Durikakezan.keijounengetu = _yoku_kaikei_yyyymm;
        if _counter = 0 then

            INSERT INTO Durikakezan
            (
                tokuisakiCD,
                keijounengetu,
                keijoutukisuu,
                kaikeiNendo,
                yosan,
                zan,
                uriagegaku,
                hennpinngaku,
                nebikigaku,
                nyuukinngaku,
                syouhizeigaku,
                insertdate,
                insertTantosya,
                updatedate,
                updateTantosya
            )
            values
            (
                _tokuisakiCD,
                _yoku_kaikei_yyyymm,
                _keika_tukisuu,
                _kaikei_nendo,
                0,
                _yoku,
                0,
                0,
                0,
                0,
                0,
                _I_date,
                _I_Tantosya,
                _I_date,
                _I_Tantosya
            );
        else
            update Durikakezan set
                zan              =    _yoku,
                updatedate       =    _I_date,
                updateTantosya   =    _I_Tantosya
            where
                    tokuisakiCD      =    _tokuisakiCD
                and keijounengetu    =    _yoku_kaikei_yyyymm;
        end if;

    END IF;
    UNTIL done END REPEAT;
    CLOSE curUri;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
