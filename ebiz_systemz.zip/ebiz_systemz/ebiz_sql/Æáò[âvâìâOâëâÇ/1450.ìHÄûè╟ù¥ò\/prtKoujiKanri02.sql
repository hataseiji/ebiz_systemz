DROP PROCEDURE IF EXISTS prtKoujiKanri02;
DELIMITER //
CREATE PROCEDURE prtKoujiKanri02(
    IN _i_kaikeiNendo       integer(4),
    IN _i_denpyouNO         integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg 		varchar(256);
    DECLARE _Result 		Boolean;
    DECLARE _counter 		integer;
    DECLARE _LineCounter 	integer;
	DECLARE _aa				tinyint;
    DECLARE done            INT DEFAULT 0;

    DECLARE _jutyuuNO                   varchar(11);
    DECLARE _kaikeiNendo                integer(4) DEFAULT 0;
    DECLARE _denpyouNO                  integer(6) DEFAULT 0;
    DECLARE _ankenkaikeiNendo           integer(4) DEFAULT 0;
    DECLARE _ankendenpyouNO             integer(6) DEFAULT 0;
    DECLARE _jutyuudate                 date;
    /* =========================================================================
         受注履歴作成処理開始
     ========================================================================= */
    DECLARE _kingaku                    decimal(10) DEFAULT 0;
    DECLARE _syouhizei                  decimal(10) DEFAULT 0;
    DECLARE _jutyuudate1                date;
    DECLARE _jutyuuNO1                  varchar(11);
    DECLARE _jutyuukaikeiNendo1         integer(4) DEFAULT 0;
    DECLARE _jutyuuDenpyouNO1           integer(6) DEFAULT 0;
    DECLARE _jutyuuKingaku1             decimal(10) DEFAULT 0;
    DECLARE _jutyuuSyouhizei1           decimal(10) DEFAULT 0;
    DECLARE _zeiJutyuuKingaku1          decimal(10) DEFAULT 0;
    DECLARE _jutyuudate2                date;
    DECLARE _jutyuuNO2                  varchar(11);
    DECLARE _jutyuukaikeiNendo2         integer(4) DEFAULT 0;
    DECLARE _jutyuuDenpyouNO2           integer(6) DEFAULT 0;
    DECLARE _jutyuuKingaku2             decimal(10) DEFAULT 0;
    DECLARE _jutyuuSyouhizei2           decimal(10) DEFAULT 0;
    DECLARE _zeiJutyuuKingaku2          decimal(10) DEFAULT 0;
    DECLARE _jutyuudate3                date;
    DECLARE _jutyuuNO3                  varchar(11);
    DECLARE _jutyuukaikeiNendo3         integer(4) DEFAULT 0;
    DECLARE _jutyuuDenpyouNO3           integer(6) DEFAULT 0;
    DECLARE _jutyuuKingaku3             decimal(10) DEFAULT 0;
    DECLARE _jutyuuSyouhizei3           decimal(10) DEFAULT 0;
    DECLARE _zeiJutyuuKingaku3          decimal(10) DEFAULT 0;
    DECLARE _jutyuudate4                date;
    DECLARE _jutyuuNO4                  varchar(11);
    DECLARE _jutyuukaikeiNendo4         integer(4) DEFAULT 0;
    DECLARE _jutyuuDenpyouNO4           integer(6) DEFAULT 0;
    DECLARE _jutyuuKingaku4             decimal(10) DEFAULT 0;
    DECLARE _jutyuuSyouhizei4           decimal(10) DEFAULT 0;
    DECLARE _zeiJutyuuKingaku4          decimal(10) DEFAULT 0;
    DECLARE _jutyuudate5                date;
    DECLARE _jutyuuNO5                  varchar(11);
    DECLARE _jutyuukaikeiNendo5         integer(4) DEFAULT 0;
    DECLARE _jutyuuDenpyouNO5           integer(6) DEFAULT 0;
    DECLARE _jutyuuKingaku5             decimal(10) DEFAULT 0;
    DECLARE _jutyuuSyouhizei5           decimal(10) DEFAULT 0;
    DECLARE _zeiJutyuuKingaku5          decimal(10) DEFAULT 0;
    DECLARE _simebi1                    tinyint DEFAULT 0;
    DECLARE _kaisyuu_mm1                tinyint DEFAULT 0;
    DECLARE _kaisyuu_dd1                tinyint DEFAULT 0;

    /* 受注履歴データを作成 */
    DECLARE curJutyuuRireki CURSOR FOR
        select
            concat_ws('-', Djutyuu.kaikeiNendo ,lpad(Djutyuu.denpyouNO,6,'0')) as jutyuuNO,
            CONCAT(year(Djutyuu.jutyuudate) , '/',lpad(month(Djutyuu.jutyuudate),2,'0'), '/',lpad(day(Djutyuu.jutyuudate),2,'0'), '' ) as jutyuudate ,
            Djutyuu.kaikeiNendo,
            Djutyuu.denpyouNO,
            Djutyuu.ankenKaikeiNendo,
            Djutyuu.ankenjutyuuNO,
            sum(Djutyuu.kingaku) as kingaku,
            sum(Djutyuu.kaikei_syouhizei) as kaikei_syouhizei,
            SSEI.simebi1,
            SSEI.kaisyuu_mm1,
            SSEI.kaisyuu_dd1
        from Djutyuu
        left outer join Mtokuisaki as MTOK
        on  MTOK.tokuisakiCD = Djutyuu.tokuisakiCD
        inner join STokuisaki as SSEI  -- 請求先
        on SSEI.seikyuusakiCD = MTOK.seikyuusakiCD
        where ankenKaikeiNendo = _i_kaikeiNendo
        and ankenjutyuuNO = _i_denpyouNO
        group by kaikeiNendo, denpyouNO
        ;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    /* =========================================================================
         受注履歴作成処理開始
     ========================================================================= */
    SET _LineCounter = 0;
    SET _aa = 0;
    OPEN curJutyuuRireki;

    REPEAT
    FETCH curJutyuuRireki
    INTO    _jutyuuNO,
            _jutyuudate,
            _kaikeiNendo,
            _denpyouNO,
            _ankenkaikeiNendo,
            _ankendenpyouNO,
            _kingaku,
            _syouhizei,
            _simebi1,
            _kaisyuu_mm1,
            _kaisyuu_dd1
            ;
        IF done = 0 THEN
            SET _aa = 1;
            SET _LineCounter = _LineCounter + 1;
            IF      _LineCounter = 1 then
                SET _jutyuudate1         = _jutyuudate;
                SET _jutyuuNO1           = _jutyuuNO;
                SET _jutyuukaikeiNendo1  = _kaikeiNendo;
                SET _jutyuuDenpyouNO1    = _denpyouNO;
                SET _jutyuuKingaku1      = _kingaku;
                SET _jutyuuSyouhizei1    = _syouhizei;
                SET _zeiJutyuuKingaku1   = _kingaku + _syouhizei;
            ELSEIF  _LineCounter = 2 then
                SET _jutyuudate2         = _jutyuudate;
                SET _jutyuuNO2           = _jutyuuNO;
                SET _jutyuukaikeiNendo2  = _kaikeiNendo;
                SET _jutyuuDenpyouNO2    = _denpyouNO;
                SET _jutyuuKingaku2      = _kingaku;
                SET _jutyuuSyouhizei2    = _syouhizei;
                SET _zeiJutyuuKingaku2   = _kingaku + _syouhizei;
            ELSEIF  _LineCounter = 3 then
                SET _jutyuudate3         = _jutyuudate;
                SET _jutyuuNO3           = _jutyuuNO;
                SET _jutyuukaikeiNendo3  = _kaikeiNendo;
                SET _jutyuuDenpyouNO3    = _denpyouNO;
                SET _jutyuuKingaku3      = _kingaku;
                SET _jutyuuSyouhizei3    = _syouhizei;
                SET _zeiJutyuuKingaku3   = _kingaku + _syouhizei;
            ELSE
                SET _jutyuudate4         = _jutyuudate;
                SET _jutyuuNO4           = _jutyuuNO;
                SET _jutyuukaikeiNendo4  = _kaikeiNendo;
                SET _jutyuuDenpyouNO4    = _denpyouNO;
                SET _jutyuuKingaku4      = _kingaku;
                SET _jutyuuSyouhizei4    = _syouhizei;
                SET _zeiJutyuuKingaku4   = _kingaku + _syouhizei;
            END IF;
            -- 合計部
            SET _jutyuudate5         = _jutyuudate;
            SET _jutyuuNO5           = _jutyuuNO;
            SET _jutyuukaikeiNendo5  = _kaikeiNendo;
            SET _jutyuuDenpyouNO5    = _denpyouNO;
            SET _jutyuuKingaku5      = _jutyuuKingaku5 + _kingaku;
            SET _jutyuuSyouhizei5    = _jutyuuSyouhizei5 + _syouhizei;
            SET _zeiJutyuuKingaku5   = _zeiJutyuuKingaku5 + _kingaku + _syouhizei;
        END IF;
    UNTIL done END REPEAT;

    CLOSE curJutyuuRireki;

    update SKoujikanri
        SET
            jutyuudate1         =   _jutyuudate1,
            jutyuuNO1           =   _jutyuuNO1,
            jutyuukaikeiNendo1  =   _jutyuukaikeiNendo1,
            jutyuuDenpyouNO1    =   _jutyuuDenpyouNO1,
            jutyuuKingaku1      =   _jutyuuKingaku1,
            jutyuuSyouhizei1    =   _jutyuuSyouhizei1,
            zeiJutyuuKingaku1   =   _zeiJutyuuKingaku1,
            jutyuudate2         =   _jutyuudate2,
            jutyuuNO2           =   _jutyuuNO2,
            jutyuukaikeiNendo2  =   _jutyuukaikeiNendo2,
            jutyuuDenpyouNO2    =   _jutyuuDenpyouNO2,
            jutyuuKingaku2      =   _jutyuuKingaku2,
            jutyuuSyouhizei2    =   _jutyuuSyouhizei2,
            zeiJutyuuKingaku2   =   _zeiJutyuuKingaku2,
            jutyuudate3         =   _jutyuudate3,
            jutyuuNO3           =   _jutyuuNO3,
            jutyuukaikeiNendo3  =   _jutyuukaikeiNendo3,
            jutyuuDenpyouNO3    =   _jutyuuDenpyouNO3,
            jutyuuKingaku3      =   _jutyuuKingaku3,
            jutyuuSyouhizei3    =   _jutyuuSyouhizei3,
            zeiJutyuuKingaku3   =   _zeiJutyuuKingaku3,
            jutyuuNO4           =   _jutyuuNO4,
            jutyuukaikeiNendo4  =   _jutyuukaikeiNendo4,
            jutyuuDenpyouNO4    =   _jutyuuDenpyouNO4,
            jutyuuKingaku4      =   _jutyuuKingaku4,
            jutyuuSyouhizei4    =   _jutyuuSyouhizei4,
            zeiJutyuuKingaku4   =   _zeiJutyuuKingaku4,
            /*
            jutyuuNO5           =   _jutyuuNO5,
            jutyuukaikeiNendo5  =   _jutyuukaikeiNendo5,
            jutyuuDenpyouNO5    =   _jutyuuDenpyouNO5,
            */
            jutyuuKingaku5      =   _jutyuuKingaku5,
            jutyuuSyouhizei5    =   _jutyuuSyouhizei5,
            zeiJutyuuKingaku5   =   _zeiJutyuuKingaku5
    where   kaikeiNendo = _ankenkaikeiNendo
            and denpyouNO = _ankendenpyouNO
    ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
