DROP PROCEDURE IF EXISTS prtKoujiKanri;
DELIMITER //
CREATE PROCEDURE prtKoujiKanri(
    IN _i_kaikeiNendo       integer(4),
    IN _i_denpyouNO         integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
       工事管理表 表紙作成
     ========================================================================= */

    call prtKoujiKanriCreateTable(
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    call prtKoujiKanri01(
            _i_kaikeiNendo,
            _i_denpyouNO,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    call prtKoujiKanri02(
            _i_kaikeiNendo,
            _i_denpyouNO,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    call prtKoujiKanri03(
            _i_kaikeiNendo,
            _i_denpyouNO,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    call prtKoujiKanri04(
            _i_kaikeiNendo,
            _i_denpyouNO,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    call prtKoujiKanri05(
            _i_kaikeiNendo,
            _i_denpyouNO,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
