DROP PROCEDURE IF EXISTS prtKoujiKanri04;
DELIMITER //
CREATE PROCEDURE prtKoujiKanri04(
    IN _i_kaikeiNendo       integer(4),
    IN _i_denpyouNO         integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg 		varchar(256);
    DECLARE _Result 		Boolean;
    DECLARE _counter 		integer;
    DECLARE _LineCounter 	integer;
    DECLARE _uriageGaku     decimal(10) DEFAULT 0;
	DECLARE _aa				tinyint;
    DECLARE done            INT DEFAULT 0;

    /* =========================================================================
         各原価収支予想・実績作成処理開始
     ========================================================================= */
    DECLARE _zMitumori          decimal(10) DEFAULT 0;
    DECLARE _zJissi             decimal(10) DEFAULT 0;
    DECLARE _rMitumori          decimal(10) DEFAULT 0;
    DECLARE _rJissi             decimal(10) DEFAULT 0;
    DECLARE _gMitumori          decimal(10) DEFAULT 0;
    DECLARE _gJissi             decimal(10) DEFAULT 0;
    DECLARE _kMitumori          decimal(10) DEFAULT 0;
    DECLARE _kJissi             decimal(10) DEFAULT 0;
    DECLARE _tMitumori          decimal(10) DEFAULT 0;
    DECLARE _tJissi             decimal(10) DEFAULT 0;

    /* =========================================================================
         各原価収支予想・実績作成処理開始
     ========================================================================= */
    -- [売上高]
    select sum(Djutyuu.kingaku) into _uriageGaku from Djutyuu
    where Djutyuu.ankenKaikeiNendo = _i_kaikeiNendo and Djutyuu.ankenjutyuuNO = _i_denpyouNO
    group by Djutyuu.ankenKaikeiNendo, Djutyuu.ankenjutyuuNO;

    -- [材料費見積原価]
    select sum(Dhattyuu.kingaku) into _zMitumori from Dhattyuu
    inner join Mkanri on kanriCD = 1
    inner join Msyouhin on Msyouhin.syouhinCD = Dhattyuu.syouhinCD
    where Dhattyuu.ankenKaikeiNendo = _i_kaikeiNendo and Dhattyuu.ankenjutyuuNO = _i_denpyouNO
    and Msyouhin.daibunruiCD > 0
    and Msyouhin.daibunruiCD < 100000
    group by Dhattyuu.ankenKaikeiNendo, Dhattyuu.ankenjutyuuNO;

    -- [材料費実施原価]
    select sum(Dsiire.kingaku) into _zJissi from Dsiire
    inner join Mkanri on kanriCD = 1
    inner join Msyouhin on Msyouhin.syouhinCD = Dsiire.syouhinCD
    where Dsiire.ankenKaikeiNendo = _i_kaikeiNendo and Dsiire.ankenjutyuuNO = _i_denpyouNO
    and Msyouhin.daibunruiCD > 0
    and Msyouhin.daibunruiCD < 100000
    group by Dsiire.ankenKaikeiNendo, Dsiire.ankenjutyuuNO;

    -- [労務費見積原価]
    select sum(Dhattyuu.kingaku) into _rMitumori from Dhattyuu
    inner join Mkanri on kanriCD = 1
    inner join Msyouhin on Msyouhin.syouhinCD = Dhattyuu.syouhinCD
    where Dhattyuu.ankenKaikeiNendo = _i_kaikeiNendo and Dhattyuu.ankenjutyuuNO = _i_denpyouNO
    and Msyouhin.daibunruiCD = 100001
    group by Dhattyuu.ankenKaikeiNendo, Dhattyuu.ankenjutyuuNO;

    -- [労務費実施原価]
    select sum(Dsiire.kingaku) into _rJissi from Dsiire
    inner join Mkanri on kanriCD = 1
    inner join Msyouhin on Msyouhin.syouhinCD = Dsiire.syouhinCD
    where Dsiire.ankenKaikeiNendo = _i_kaikeiNendo and Dsiire.ankenjutyuuNO = _i_denpyouNO
    and Msyouhin.daibunruiCD = 100001
    group by Dsiire.ankenKaikeiNendo, Dsiire.ankenjutyuuNO;

    -- [外注費見積原価]
    select sum(Dhattyuu.kingaku) into _gMitumori from Dhattyuu
    inner join Mkanri on kanriCD = 1
    inner join Msyouhin on Msyouhin.syouhinCD = Dhattyuu.syouhinCD
    where Dhattyuu.ankenKaikeiNendo = _i_kaikeiNendo and Dhattyuu.ankenjutyuuNO = _i_denpyouNO
    and Msyouhin.daibunruiCD = 100002
    group by Dhattyuu.ankenKaikeiNendo, Dhattyuu.ankenjutyuuNO;

    -- [外注費実施原価]
    select sum(Dsiire.kingaku) into _gJissi from Dsiire
    inner join Mkanri on kanriCD = 1
    inner join Msyouhin on Msyouhin.syouhinCD = Dsiire.syouhinCD
    where Dsiire.ankenKaikeiNendo = _i_kaikeiNendo and Dsiire.ankenjutyuuNO = _i_denpyouNO
    and Msyouhin.daibunruiCD = 100002
    group by Dsiire.ankenKaikeiNendo, Dsiire.ankenjutyuuNO;

    -- [経費見積原価]
    select sum(Dhattyuu.kingaku) into _kMitumori from Dhattyuu
    inner join Mkanri on kanriCD = 1
    inner join Msyouhin on Msyouhin.syouhinCD = Dhattyuu.syouhinCD
    where Dhattyuu.ankenKaikeiNendo = _i_kaikeiNendo and Dhattyuu.ankenjutyuuNO = _i_denpyouNO
    and Msyouhin.daibunruiCD = 100003
    group by Dhattyuu.ankenKaikeiNendo, Dhattyuu.ankenjutyuuNO;

    -- [経費実施原価]
    select sum(Dsiire.kingaku) into _kJissi from Dsiire
    inner join Mkanri on kanriCD = 1
    inner join Msyouhin on Msyouhin.syouhinCD = Dsiire.syouhinCD
    where Dsiire.ankenKaikeiNendo = _i_kaikeiNendo and Dsiire.ankenjutyuuNO = _i_denpyouNO
    and Msyouhin.daibunruiCD = 100003
    group by Dsiire.ankenKaikeiNendo, Dsiire.ankenjutyuuNO;

    -- [合計見積原価]
    select sum(Dhattyuu.kingaku) into _tMitumori from Dhattyuu
    inner join Mkanri on kanriCD = 1
    inner join Msyouhin on Msyouhin.syouhinCD = Dhattyuu.syouhinCD
    where Dhattyuu.ankenKaikeiNendo = _i_kaikeiNendo and Dhattyuu.ankenjutyuuNO = _i_denpyouNO
    group by Dhattyuu.ankenKaikeiNendo, Dhattyuu.ankenjutyuuNO;

    -- [合計実施原価]
    select sum(Dsiire.kingaku) into _tJissi from Dsiire
    inner join Mkanri on kanriCD = 1
    inner join Msyouhin on Msyouhin.syouhinCD = Dsiire.syouhinCD
    where Dsiire.ankenKaikeiNendo = _i_kaikeiNendo and Dsiire.ankenjutyuuNO = _i_denpyouNO
    group by Dsiire.ankenKaikeiNendo, Dsiire.ankenjutyuuNO;

    update SKoujikanri
        SET
            zMitumoriGenka  =   _zMitumori,
            zJissiGenka     =   _zJissi,
            zRitu           =   case when truncate(IFNULL(_zJissi / _zMitumori * 100, 0), 3) > 999.999 then 999.999
                                else truncate(IFNULL(_zJissi / _zMitumori * 100, 0), 3) end ,
            zZankin         =   _zMitumori - _zJissi,
            rMitumoriGenka  =   _rMitumori,
            rJissiGenka     =   _rJissi,
            rRitu           =   case when truncate(IFNULL(_rJissi / _rMitumori * 100, 0), 3) > 999.999 then 999.999
                                else truncate(IFNULL(_rJissi / _rMitumori * 100, 0), 3) end ,
            rZankin         =   _rMitumori - _rJissi,
            gMitumoriGenka  =   _gMitumori,
            gJissiGenka     =   _gJissi,
            gRitu           =   case when truncate(IFNULL(_gJissi / _gMitumori * 100, 0), 3) > 999.999 then 999.999
                                else truncate(IFNULL(_gJissi / _gMitumori * 100, 0), 3) end ,
            gZankin         =   _gMitumori - _gJissi,
            kMitumoriGenka  =   _kMitumori,
            kJissiGenka     =   _kJissi,
            kRitu           =   case when truncate(IFNULL(_kJissi / _kMitumori * 100, 0), 3) > 999.999 then 999.999
                                else truncate(IFNULL(_kJissi / _kMitumori * 100, 0), 3) end ,
            kZankin         =   _kMitumori - _kJissi,
            tMitumoriGenka  =   _tMitumori,
            tJissiGenka     =   _tJissi,
            tRitu           =   case when truncate(IFNULL(_tJissi / _tMitumori * 100, 0), 3) > 999.999 then 999.999
                                else truncate(IFNULL(_tJissi / _tMitumori * 100, 0), 3) end ,
            tZankin         =   _tMitumori - _tJissi,
            aMitumoriGenka  =   _uriageGaku - _tMitumori,
            aJissiGenka     =   _uriageGaku - _tJissi
        where   kaikeiNendo   = _i_kaikeiNendo
                and denpyouNO = _i_denpyouNO
    ;


    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
