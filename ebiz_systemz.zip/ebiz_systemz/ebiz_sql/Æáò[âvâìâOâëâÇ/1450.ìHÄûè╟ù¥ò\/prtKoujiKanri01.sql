DROP PROCEDURE IF EXISTS prtKoujiKanri01;
DELIMITER //
CREATE PROCEDURE prtKoujiKanri01(
    IN _i_kaikeiNendo       integer(4),
    IN _i_denpyouNO         integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    /* 請求先を抽出 */
    drop table if exists STokuisaki;
    create temporary table STokuisaki
        select
            seikyuusakiCD,
            simebi1,
            kaisyuu_mm1,
            kaisyuu_dd1
        from Mtokuisaki
        where seikyuusakiCD = tokuisakiCD
        ;

    /* 案件受注を抽出 */
    drop table if exists SJutyuuNeta;
    create temporary table SJutyuuNeta
        select distinct
            kaikeiNendo,
            denpyouNO,
            ankenKaikeiNendo,
            ankenjutyuuNO,
            jutyuudate,
            syukkadate,
            nouki,
            ankenNM,
            tokuisakiCD,
            tokuisakiNM,
            nounyuusakiCD,
            nounyuusakiNM,
            nounyusaki_address1,
            nounyusaki_address2,
            nounyusaki_tantousyaNM,
            0 as zero
        from Djutyuu
        where 1 = 1
        and ankenKaikeiNendo = _i_kaikeiNendo
        and ankenjutyuuNO    = _i_denpyouNO
        and kaikeiNendo      = ankenKaikeiNendo
        and denpyouNO        = ankenjutyuuNO
        ;

    /* 工事管理表ヘッダデータを作成 */
    drop table if exists SJutyuu;
    create temporary table SJutyuu
    select
        concat_ws('-', SJYU.kaikeiNendo ,lpad(SJYU.denpyouNO,6,'0')) as jutyuuNO,
        SJYU.kaikeiNendo,
        SJYU.denpyouNO,
        CONCAT(year(SJYU.jutyuudate) , '年',lpad(month(SJYU.jutyuudate),2,'0'), '月',lpad(day(SJYU.jutyuudate),2,'0'), '日' ) as jutyuudate ,
        CONCAT(year(SJYU.syukkadate) , '年',lpad(month(SJYU.syukkadate),2,'0'), '月',lpad(day(SJYU.syukkadate),2,'0'), '日' ) as syukkadate ,
        CONCAT(year(SJYU.nouki) , '年',lpad(month(SJYU.nouki),2,'0'), '月',lpad(day(SJYU.nouki),2,'0'), '日' ) as nouki ,
        SJYU.ankenNM,
        SJYU.tokuisakiCD,
        -- CONCAT(SJYU.tokuisakiNM, ' ', MTOK.keisyo) as tokuisakiNM,
        SJYU.tokuisakiNM as tokuisakiNM,
        MTOK.address1,
        MTOK.address2,
        MTOK.tel1,
        MTOK.fax,
        SSEI.simebi1,
        SSEI.kaisyuu_mm1,
        SSEI.kaisyuu_dd1,
        SJYU.nounyuusakiCD,
        SJYU.nounyuusakiNM,
        SJYU.nounyusaki_address1,
        SJYU.nounyusaki_address2,
        SJYU.nounyusaki_tantousyaNM,
        MTOK.tantousyaCD as tantosyaCD,
        MTAN.tantosyaNM,
        0 as zero
    from SJutyuuNeta as SJYU
    left outer join Mtokuisaki as MTOK
    on  MTOK.tokuisakiCD = SJYU.tokuisakiCD
    inner join STokuisaki as SSEI  -- 請求先
    on SSEI.seikyuusakiCD = MTOK.seikyuusakiCD
    left outer join Mtantosya as MTAN
    on  MTAN.tantosyaCD = MTOK.tantousyaCD
    where 1 = 1
    and SJYU.ankenKaikeiNendo = _i_kaikeiNendo
    and SJYU.ankenjutyuuNO    = _i_denpyouNO
    and SJYU.kaikeiNendo      = SJYU.ankenKaikeiNendo
    and SJYU.denpyouNO        = SJYU.ankenjutyuuNO
    ;


    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
         工事管理表ヘッダ作成処理開始
     ========================================================================= */
    INSERT ignore INTO SKoujikanri
    (
        jutyuuNO,
        kaikeiNendo,
        denpyouNO,
        ankenNM,
        jutyuudate,
        syukkadate,
        nouki,
        tokuisakiCD,
        tokuisakiNM,
        address1,
        address2,
        tel1,
        fax,
        simebi1,
        kaisyuu_mm1,
        kaisyuu_dd1,
        nounyuusakiCD,
        nounyuusakiNM,
        nounyusaki_address1,
        nounyusaki_address2,
        nounyusaki_tantousyaNM,
        tantosyaCD,
        tantosyaNM
    )
    select
        jutyuuNO,
        kaikeiNendo,
        denpyouNO,
        ankenNM,
        jutyuudate,
        syukkadate,
        nouki,
        tokuisakiCD,
        tokuisakiNM,
        address1,
        address2,
        tel1,
        fax,
        simebi1,
        kaisyuu_mm1,
        kaisyuu_dd1,
        nounyuusakiCD,
        nounyuusakiNM,
        nounyusaki_address1,
        nounyusaki_address2,
        nounyusaki_tantousyaNM,
        tantosyaCD,
        tantosyaNM
    from SJutyuu
    ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
