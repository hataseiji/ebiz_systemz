DROP PROCEDURE IF EXISTS prtKoujiKanri05;
DELIMITER //
CREATE PROCEDURE prtKoujiKanri05(
    IN _i_kaikeiNendo       integer(4),
    IN _i_denpyouNO         integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg 		varchar(256);
    DECLARE _Result 		Boolean;
    DECLARE _counter 		integer;
    DECLARE _LineCounter 	integer;
	DECLARE _aa				tinyint;
    DECLARE done            INT DEFAULT 0;

    DECLARE _jutyuuNO                   varchar(11);
    DECLARE _kaikeiNendo                integer(4) DEFAULT 0;
    DECLARE _denpyouNO                  integer(6) DEFAULT 0;
    DECLARE _jutyuudate                 date;
    DECLARE _kingaku                    decimal(10) DEFAULT 0;
    DECLARE _syouhizei                  decimal(10) DEFAULT 0;
    DECLARE _simebi1                    tinyint DEFAULT 0;
    DECLARE _kaisyuu_mm1                tinyint DEFAULT 0;
    DECLARE _kaisyuu_dd1                tinyint DEFAULT 0;

    /* =========================================================================
         請求情報
     ========================================================================= */
    DECLARE _seikyuDate1                date        DEFAULT '2000-01-01';
    DECLARE _seikyuuGaku1               decimal(10) DEFAULT 0;
    DECLARE _nyuukinYoteiDate1          date        DEFAULT '2000-01-01';
    DECLARE _seikyuDate2                date        DEFAULT '2000-01-01';
    DECLARE _seikyuuGaku2               decimal(10) DEFAULT 0;
    DECLARE _nyuukinYoteiDate2          date        DEFAULT '2000-01-01';
    DECLARE _seikyuDate3                date        DEFAULT '2000-01-01';
    DECLARE _seikyuuGaku3               decimal(10) DEFAULT 0;
    DECLARE _nyuukinYoteiDate3          date        DEFAULT '2000-01-01';
    DECLARE _seikyuDate4                date        DEFAULT '2000-01-01';
    DECLARE _seikyuuGaku4               decimal(10) DEFAULT 0;
    DECLARE _nyuukinYoteiDate4          date        DEFAULT '2000-01-01';

    /* 受注履歴データを作成 */
    DECLARE curJutyuuRireki CURSOR FOR
        select
            concat_ws('-', Djutyuu.kaikeiNendo ,lpad(Djutyuu.denpyouNO,6,'0')) as jutyuuNO,
            Djutyuu.jutyuudate,
            Djutyuu.kaikeiNendo,
            Djutyuu.denpyouNO,
            sum(Djutyuu.kingaku) as kingaku,
            sum(Djutyuu.inji_syouhizei) as inji_syouhizei,
            SSEI.simebi1,
            SSEI.kaisyuu_mm1,
            SSEI.kaisyuu_dd1
        from Djutyuu
        left outer join Mtokuisaki as MTOK
        on  MTOK.tokuisakiCD = Djutyuu.tokuisakiCD
        inner join STokuisaki as SSEI  -- 請求先
        on SSEI.seikyuusakiCD = MTOK.seikyuusakiCD
        where ankenKaikeiNendo = _i_kaikeiNendo
        and ankenjutyuuNO = _i_denpyouNO
        group by kaikeiNendo, denpyouNO
        ;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    /* =========================================================================
         請求情報
     ========================================================================= */
    SET _LineCounter = 0;
    SET _aa = 0;
    OPEN curJutyuuRireki;

    REPEAT
    FETCH curJutyuuRireki
    INTO    _jutyuuNO,
            _jutyuudate,
            _kaikeiNendo,
            _denpyouNO,
            _kingaku,
            _syouhizei,
            _simebi1,
            _kaisyuu_mm1,
            _kaisyuu_dd1
            ;
        IF done = 0 THEN
            SET _LineCounter = _LineCounter + 1;

            IF _LineCounter = 1 then
                SET _seikyuDate1       = getSeikyuuDate(_jutyuudate, _simebi1);
                SET _seikyuuGaku1      = _kingaku + _syouhizei;
                SET _nyuukinYoteiDate1 = getNyuukinDate(_seikyuDate1, _kaisyuu_mm1, _kaisyuu_dd1);
            ELSEIF _LineCounter = 2 then
                SET _seikyuDate2       = getSeikyuuDate(_jutyuudate, _simebi1);
                SET _seikyuuGaku2      = _kingaku + _syouhizei;
                SET _nyuukinYoteiDate2 = getNyuukinDate(_seikyuDate2, _kaisyuu_mm1, _kaisyuu_dd1);
            ELSEIF _LineCounter = 3 then
                SET _seikyuDate3       = getSeikyuuDate(_jutyuudate, _simebi1);
                SET _seikyuuGaku3      = _kingaku + _syouhizei;
                SET _nyuukinYoteiDate3 = getNyuukinDate(_seikyuDate3, _kaisyuu_mm1, _kaisyuu_dd1);
            ELSE
                SET _seikyuDate4       = getSeikyuuDate(_jutyuudate, _simebi1);
                SET _seikyuuGaku4      = _seikyuuGaku4 + _kingaku + _syouhizei;
                SET _nyuukinYoteiDate4 = getNyuukinDate(_seikyuDate4, _kaisyuu_mm1, _kaisyuu_dd1);
            END IF;
        END IF;
    UNTIL done END REPEAT;

    CLOSE curJutyuuRireki;

    update SKoujikanri
        SET
            seikyuuDate1        =   CONCAT(year(_seikyuDate1) , '/',lpad(month(_seikyuDate1),2,'0'), '/',lpad(day(_seikyuDate1),2,'0'), '' ),
            seikyuuKingaku1     =   _seikyuuGaku1,
            nyuukinYoteiDate1   =   CONCAT(year(_nyuukinYoteiDate1) , '/',lpad(month(_nyuukinYoteiDate1),2,'0'), '/',lpad(day(_nyuukinYoteiDate1),2,'0'), '' ),

            seikyuuDate2        =   CONCAT(year(_seikyuDate2) , '/',lpad(month(_seikyuDate2),2,'0'), '/',lpad(day(_seikyuDate2),2,'0'), '' ),
            seikyuuKingaku2     =   _seikyuuGaku2,
            nyuukinYoteiDate2   =   CONCAT(year(_nyuukinYoteiDate2) , '/',lpad(month(_nyuukinYoteiDate2),2,'0'), '/',lpad(day(_nyuukinYoteiDate2),2,'0'), '' ),

            seikyuuDate3        =   CONCAT(year(_seikyuDate3) , '/',lpad(month(_seikyuDate3),2,'0'), '/',lpad(day(_seikyuDate3),2,'0'), '' ),
            seikyuuKingaku3     =   _seikyuuGaku3,
            nyuukinYoteiDate3   =   CONCAT(year(_nyuukinYoteiDate3) , '/',lpad(month(_nyuukinYoteiDate3),2,'0'), '/',lpad(day(_nyuukinYoteiDate3),2,'0'), '' ),

            seikyuuDate4        =   CONCAT(year(_seikyuDate4) , '/',lpad(month(_seikyuDate4),2,'0'), '/',lpad(day(_seikyuDate4),2,'0'), '' ),
            seikyuuKingaku4     =   _seikyuuGaku4,
            nyuukinYoteiDate4   =   CONCAT(year(_nyuukinYoteiDate4) , '/',lpad(month(_nyuukinYoteiDate4),2,'0'), '/',lpad(day(_nyuukinYoteiDate4),2,'0'), '' )
        where   kaikeiNendo     = _i_kaikeiNendo
                and denpyouNO   = _i_denpyouNO
    ;


    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;