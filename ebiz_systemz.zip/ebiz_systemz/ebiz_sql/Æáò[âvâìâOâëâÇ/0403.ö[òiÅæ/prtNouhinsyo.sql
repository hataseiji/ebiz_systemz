DROP PROCEDURE IF EXISTS prtNouhinsyo;
DELIMITER //
CREATE PROCEDURE prtNouhinsyo(
    IN _i_jigyosyoCDfr       integer(2),
    IN _i_jigyosyoCDto       integer(2),
    IN _i_syukkaDatefr       date,
    IN _i_syukkaDateto       date,
    IN _i_tokuisakiCDfr      integer(6),
    IN _i_tokuisakiCDto      integer(6),
    IN _i_kaikeiNendofr      integer(4),
    IN _i_denpyouNOfr        integer(6),
    IN _i_denpyouNOto        integer(6),
    IN _i_CheckSaihakkou     tinyint,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    DROP table IF EXISTS preDataNouhinsyo;
    create temporary table preDataNouhinsyo
        select
            Dsyukka.*,
            concat_ws('-', Dsyukka.kaikeiNendo ,lpad(Dsyukka.denpyouNO,6,'0')) as syukkaNo,
            Mtani.taniNM as taniNM,
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.tanka
              else Duriage.tanka
            end Ptanka,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtantosyaJ.jigyosyoCD
              else MtantosyaU.jigyosyoCD
            end kanjigyosyoCD,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.jigyosyoNM
              else MjigyosyoU.jigyosyoNM
            end kanjigyosyoNM,
            Mkanri.kaisyaNM as kankaisyaNM,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.postalCD
              else MjigyosyoU.postalCD
            end kanpostalCD,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.address1
              else MjigyosyoU.address1
            end kanaddress1,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.address2
              else MjigyosyoU.address2
            end kanaddress2,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.tel
              else MjigyosyoU.tel
            end kantel,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.fax
              else MjigyosyoU.fax
            end kanfax,
            -- 得意先
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.tokuisakiCD
              else Duriage.tokuisakiCD
            end PTtokuisakiCD,
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.tokuisakiNM
              else Duriage.tokuisakiNM
            end PTtokuisakiNM,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtokuisakiJ.postalCD
              else MtokuisakiU.postalCD
            end PTpostalCD,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtokuisakiJ.address1
              else MtokuisakiU.address1
            end PTaddress1,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtokuisakiJ.address2
              else MtokuisakiU.address2
            end PTaddress2,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtokuisakiJ.tokuisaki_tantousyaNM
              else MtokuisakiU.tokuisaki_tantousyaNM
            end PTtokuisaki_tantousyaNM,
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtokuisakiJ.nouhinsoyKBN
              else MtokuisakiU.nouhinsoyKBN
            end PTnouhinsoyKBN,
            -- 納入先
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.nounyuusakiCD
              else Duriage.nounyuusakiCD
            end PNnounyuusakiCD,
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.nounyuusakiNM
              else Duriage.nounyuusakiNM
            end PNnounyuusakiNM,
            case Dsyukka.uriageKaikeiNendo
              when 0 then  Djutyuu.postalCD
              else Duriage.postalCD
            end PNpostalCD,
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.nounyusaki_address1
              else Duriage.nounyusaki_address1
            end PNnounyusaki_address1,
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.nounyusaki_address2
              else Duriage.nounyusaki_address2
            end PNnounyusaki_address2,
            case Dsyukka.uriageKaikeiNendo
              when 0 then  Djutyuu.nounyusaki_tantousyaNM
              else Duriage.nounyusaki_tantousyaNM
            end PNnounyusaki_tantousyaNM,
            case Dsyukka.uriageKaikeiNendo
              when 0 then  Djutyuu.TtyuumonNo
              else Duriage.TtyuumonNo
            end TtyuumonNo
        from Dsyukka
        left outer join Djutyuu
        on   Djutyuu.kaikeiNendo = Dsyukka.jutyuuKaikeiNendo
        and  Djutyuu.denpyouNO   = Dsyukka.jutyuuNO
        and  Djutyuu.gyouNO      = Dsyukka.jutyuu_gyouNO
        left outer join Duriage
        on   Duriage.kaikeiNendo = Dsyukka.uriageKaikeiNendo
        and  Duriage.denpyouNO   = Dsyukka.uriageNO
        and  Duriage.gyouNO      = Dsyukka.uriage_gyouNO
        left outer join Mtokuisaki as MtokuisakiJ
        on   MtokuisakiJ.tokuisakiCD = Djutyuu.tokuisakiCD
        left outer join Mtokuisaki as MtokuisakiU
        on   MtokuisakiU.tokuisakiCD = Duriage.tokuisakiCD
        left outer join Mtani
        on   Mtani.taniCD = Dsyukka.taniCD
        left outer join Mtantosya as MtantosyaJ
        on   MtantosyaJ.tantosyaCD = MtokuisakiJ.tantousyaCD
        left outer join Mtantosya as MtantosyaU
        on   MtantosyaU.tantosyaCD = MtokuisakiU.tantousyaCD
        left outer join Mjigyosyo as MjigyosyoJ
        on   MjigyosyoJ.jigyosyoCD = MtantosyaJ.jigyosyoCD
        left outer join Mjigyosyo as MjigyosyoU
        on   MjigyosyoU.jigyosyoCD = MtantosyaU.jigyosyoCD
        inner join Mkanri
        on   Mkanri.kanriCD = 1

        where 1 = 1
        and  (_i_syukkaDatefr = "2000-01-01" or Dsyukka.syukkadate >= _i_syukkaDatefr)
        and  (_i_syukkaDateto = "2000-01-01" or Dsyukka.syukkadate <= _i_syukkaDateto)
        and  (_i_kaikeiNendofr = 0 or Dsyukka.kaikeiNendo = _i_kaikeiNendofr)
        and  (_i_denpyouNOfr = 0 or Dsyukka.denpyouNO >= _i_denpyouNOfr)
        and  (_i_denpyouNOto = 0 or Dsyukka.denpyouNO <= _i_denpyouNOto)
        and  (_i_CheckSaihakkou = 1 or Dsyukka.NouhinsyoHakkou = 0)
        order by Dsyukka.kaikeiNendo, Dsyukka.denpyouNO, Dsyukka.gyouNO
        ;
    DROP table IF EXISTS dataNouhinsyo;
    create temporary table dataNouhinsyo
        select
            preDataNouhinsyo.kaikeiNendo,
            preDataNouhinsyo.denpyouNO,
            preDataNouhinsyo.gyouNO,
            preDataNouhinsyo.syukkaNo,
            preDataNouhinsyo.uriageNO,
            preDataNouhinsyo.jutyuuNO,
            preDataNouhinsyo.TtyuumonNo,
            CONCAT(year(preDataNouhinsyo.syukkadate) , '年',lpad(month(preDataNouhinsyo.syukkadate),2,'0'), '月',lpad(day(preDataNouhinsyo.syukkadate),2,'0'), '日' ) as syukkadate,
            case preDataNouhinsyo.PNnounyuusakiNM
              when "" then preDataNouhinsyo.PTpostalCD
              else preDataNouhinsyo.PNpostalCD
            end postalCD,
            case preDataNouhinsyo.PNnounyuusakiNM
              when "" then preDataNouhinsyo.PTaddress1
              else preDataNouhinsyo.PNnounyusaki_address1
            end nounyusaki_address1,
            case preDataNouhinsyo.PNnounyuusakiNM
              when "" then preDataNouhinsyo.PTaddress2
              else preDataNouhinsyo.PNnounyusaki_address2
            end nounyusaki_address2,
            case preDataNouhinsyo.PNnounyuusakiNM
              when "" then preDataNouhinsyo.PTtokuisakiNM
              else preDataNouhinsyo.PNnounyuusakiNM
            end nounyuusakiNM,
            case preDataNouhinsyo.PNnounyuusakiNM
              when "" then preDataNouhinsyo.PTtokuisaki_tantousyaNM
              else preDataNouhinsyo.PNnounyusaki_tantousyaNM
            end nounyusaki_tantousyaNM,
            preDataNouhinsyo.PTtokuisakiCD,
            case preDataNouhinsyo.PNnounyuusakiNM
              when "" then ""
              else preDataNouhinsyo.PTtokuisakiNM
            end tokuisakiNM,
            preDataNouhinsyo.kanjigyosyoCD,
            preDataNouhinsyo.kanjigyosyoNM,
            preDataNouhinsyo.kankaisyaNM,
            preDataNouhinsyo.kanpostalCD,
            preDataNouhinsyo.kanaddress1,
            preDataNouhinsyo.kanaddress2,
            preDataNouhinsyo.kantel,
            preDataNouhinsyo.kanfax,
            preDataNouhinsyo.syouhinCD,
            preDataNouhinsyo.syouhinNM,
            preDataNouhinsyo.suryou,
            preDataNouhinsyo.taniCD,
            preDataNouhinsyo.taniNM,
            preDataNouhinsyo.Ptanka,
            preDataNouhinsyo.suryou * preDataNouhinsyo.Ptanka as Pkingaku
            -- preDataNouhinsyo.kingaku
        from preDataNouhinsyo
        where 1 = 1
        and  (_i_jigyosyoCDfr = 0 or kanjigyosyoCD >= _i_jigyosyoCDfr)
        and  (_i_jigyosyoCDto = 0 or kanjigyosyoCD <= _i_jigyosyoCDto)
        and  (_i_tokuisakiCDfr = 0 or PTtokuisakiCD >= _i_tokuisakiCDfr)
        and  (_i_tokuisakiCDto = 0 or PTtokuisakiCD <= _i_tokuisakiCDto)
        and  PTnouhinsoyKBN = 0
        order by
            preDataNouhinsyo.kaikeiNendo,
            preDataNouhinsyo.denpyouNO,
            preDataNouhinsyo.gyouNO
        ;
    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
