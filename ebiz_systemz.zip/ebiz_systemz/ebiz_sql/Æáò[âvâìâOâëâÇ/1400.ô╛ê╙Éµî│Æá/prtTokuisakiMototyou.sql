DROP PROCEDURE IF EXISTS prtTokuisakiMototyou;
DELIMITER //
CREATE PROCEDURE prtTokuisakiMototyou(
    IN _i_tokuisakiCDfr      integer(6),
    IN _i_tokuisakiCDto      integer(6),
    IN _i_kaikeiNendo          integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    drop table if exists STokuisakiMototyou;
    create temporary table STokuisakiMototyou
    (select
      1 as No ,
      Duriagelog.tokuisakiCD        as tokuisakiCD ,
      Mtokuisaki.tokuisakiNM        as tokuisakiNM ,
      Durikakezan.zan               as ZENZAN ,
      Durikakezan.uriagegaku        as uriagegaku ,
      Durikakezan.hennpinngaku      as hennpinngaku ,
      Durikakezan.nebikigaku        as nebikigaku ,
      Durikakezan.nyuukinngaku      as nyuukinngaku ,
      Durikakezan.syouhizeigaku     as syouhizei ,
      (Durikakezan.zan + Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku - Durikakezan.nyuukinngaku + Durikakezan.syouhizeigaku)
 as jikaikurikosigaku ,

      CONCAT(year(Duriagelog.uriagedate) , '/',lpad(month(Duriagelog.uriagedate),2,'0'), '/',lpad(day(Duriagelog.uriagedate),2,'0'), '' ) as denpyouDate ,
      concat_ws('-', Duriagelog.kaikeiNendo ,lpad(Duriagelog.denpyouNO,6,'0')) as denpyouNo ,
      Duriagelog.gyouNO           as gyouNO ,
      Duriagelog.seq              as seq ,
      Storihiki.torihikiNM        as torihikiNM ,
      Duriagelog.syouhinCD        as syouhinCD ,
      Duriagelog.syouhinNM        as syouhinNM ,
      Duriagelog.suryou           as suryou ,
      Duriagelog.taniCD           as taniCD ,
      Mtani.taniNM                as taniNM ,
      Duriagelog.tanka            as tanka ,
      Duriagelog.kingaku          as kingaku ,
      Duriagelog.hontai_kingaku   as hontai_kingaku ,
      Duriagelog.kaikei_syouhizei as kaikei_syouhizei ,
      0                           as mnyuukinngaku ,
      0 as zandaka ,
      0 as zero
      from Duriagelog
      inner join Durikakezan
        on Durikakezan.tokuisakiCD = Duriagelog.tokuisakiCD
        and Durikakezan.keijounengetu = Duriagelog.keijounengetu
      left outer join Mtokuisaki
        on Mtokuisaki.tokuisakiCD = Durikakezan.tokuisakiCD
      left outer join Mtani
        on Mtani.taniCD = Duriagelog.taniCD
        inner join Storihiki as Storihiki
        on   Storihiki.dataKBN = Duriagelog.dataKBN
        and  Storihiki.torihikiKBN = Duriagelog.torihikiKBN
        inner join Mkanri
        on  Mkanri.kanriCD = 1
      where 1 = 1
      and (_i_tokuisakiCDfr = 0 or Durikakezan.tokuisakiCD >= _i_tokuisakiCDfr)
      and (_i_tokuisakiCDto = 0 or Durikakezan.tokuisakiCD <= _i_tokuisakiCDto)
      and Duriagelog.keijounengetu = _i_kaikeiNendo
      and (Duriagelog.hontai_kingaku <> 0 or Duriagelog.kaikei_syouhizei <> 0)
      )
    UNION ALL
    (select 2 as No ,
      Dnyuukinlog.seikyuusakiCD    as tokuisakiCD ,
      Mtokuisaki.tokuisakiNM       as tokuisakiNM ,
      Durikakezan.zan              as ZENZAN ,
      Durikakezan.uriagegaku       as uriagegaku ,
      Durikakezan.hennpinngaku     as hennpinngaku ,
      Durikakezan.nebikigaku       as nebikigaku ,
      Durikakezan.nyuukinngaku     as nyuukinngaku ,
      Durikakezan.syouhizeigaku    as syouhizei ,
      (Durikakezan.zan + Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku - Durikakezan.nyuukinngaku + Durikakezan.syouhizeigaku)
 as jikaikurikosigaku ,

      CONCAT(year(Dnyuukinlog.nyuukindate) , '/',lpad(month(Dnyuukinlog.nyuukindate),2,'0'), '/',lpad(day(Dnyuukinlog.nyuukindate),2,'0'), '' ) as denpyouDate ,
      concat_ws('-', Dnyuukinlog.kaikeiNendo ,lpad(Dnyuukinlog.denpyouNO,6,'0')) as denpyouNo ,
      Dnyuukinlog.gyouNO           as gyouNO ,
      Dnyuukinlog.seq              as seq ,
      Storihiki.torihikiNM         as torihikiNM,
      ''                           as syouhinCD     ,
      '＊入金'                      as syouhinNM ,
      0                            as suryou ,
      0                            as taniCD ,
      ''                           as taniNM ,
      0                            as tanka  ,
      0                            as kingaku ,
      0                            as hontai_kingaku ,
      0                            as kaikei_syouhizei ,
      Dnyuukinlog.kingaku          as mnyuukinngaku ,
      0                            as zandaka ,
      0 as zero
      from Dnyuukinlog
      inner join Durikakezan
        on Durikakezan.tokuisakiCD = Dnyuukinlog.seikyuusakiCD
        and Durikakezan.keijounengetu = Dnyuukinlog.keijounengetu
      left outer join Mtokuisaki
        on Mtokuisaki.tokuisakiCD = Dnyuukinlog.seikyuusakiCD
      inner join Storihiki as Storihiki
        on   Storihiki.dataKBN = Dnyuukinlog.dataKBN
        and  Storihiki.torihikiKBN = Dnyuukinlog.torihikiKBN
        inner join Mkanri
        on   Mkanri.kanriCD = 1
      where 1 = 1
      and (_i_tokuisakiCDfr = 0 or Dnyuukinlog.seikyuusakiCD >= _i_tokuisakiCDfr)
      and (_i_tokuisakiCDto = 0 or Dnyuukinlog.seikyuusakiCD <= _i_tokuisakiCDto)
      and Dnyuukinlog.keijounengetu = _i_kaikeiNendo
      and Dnyuukinlog.kingaku <> 0
      )
    Order By tokuisakiCD, denpyouDate, denpyouNo, gyouNO, seq ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
