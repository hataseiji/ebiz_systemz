DROP PROCEDURE IF EXISTS KeikeiRenkeiNyuukin;
DELIMITER //
CREATE PROCEDURE KeikeiRenkeiNyuukin(
    IN  _I_kaikeiNengetu integer(6),
    IN  _I_keijouDateFr  date,
    IN  _I_keijouDateTo  date,
    OUT _o_ErrorMsg      varchar(256),
    OUT _o_Result        Boolean
)
BEGIN
/*
    会計連携 (売上データ)
*/
    DECLARE _kaikeiNendo      integer(4);
    DECLARE _denpyouNO        integer(6);
    DECLARE _gyouNO           integer(6);
    DECLARE _akakuro          tinyint(1);
    DECLARE _yuukou           tinyint(1);
    DECLARE _keijounengetu    integer(6);
    DECLARE _dataKBN          integer(3);
    DECLARE _torihikiKBN      integer(3);
    DECLARE _nyuukinKBN       integer(3);
    DECLARE _siwakeCD         integer(6);
    DECLARE _nyuukindate      varchar(10);
    DECLARE _KKCD             varchar(10);
    DECLARE _KKNM             varchar(24);
    DECLARE _KSCD             varchar(10);
    DECLARE _KSNM             varchar(24);
    DECLARE _TKNM             varchar(40);
    DECLARE _HKCD             varchar(10);
    DECLARE _HKNM             varchar(24);
    DECLARE _HSCD             varchar(10);
    DECLARE _HSNM             varchar(24);
    DECLARE _hontai_kingaku   decimal(10,0) DEFAULT 0;
    DECLARE _kaikei_syouhizei decimal(10,0) DEFAULT 0;
    DECLARE _sotoutiKBN       tinyint(1);
    DECLARE _No               tinyint(1);
    DECLARE _ZEIKBN          varchar(24);
    DECLARE done                      INT DEFAULT 0;


    DECLARE curNyuukin CURSOR FOR
        select
            Dnyuukinlog.kaikeiNendo,
            Dnyuukinlog.denpyouNO,
            Dnyuukinlog.gyouNO,
            Dnyuukinlog.akakuro,
            Dnyuukinlog.yuukou,
            Dnyuukinlog.keijounengetu,
            Dnyuukinlog.dataKBN,
            Dnyuukinlog.torihikiKBN,
            Dnyuukinlog.nyuukinKBN,
            0 as                          siwakeCD,
            date(Dnyuukinlog.nyuukindate) as nyuukindate,
            MKKamokuctl.kkKamokuCD        as KKCD,
            MKKanjoukamoku.kanjoukamokuNM as KKNM,
            MKKamokuctl.ksKamokuCD        as KSCD,
            MSKanjoukamoku.kanjoukamokuNM as KSNM,
            Mtokuisaki.tokuisakiNM        as TKNM,
            MHKamokuctl.kkHojoCD          as HKCD,
            MKHojokamoku.hojokamokuNM     as HKNM,
            -- 2013/11/27 start
            -- 補助科目は得意先の情報をセットする
            -- 補助科目コントロールには何も設定がない前提
            -- MHKamokuctl.ksHojoCD          as HSCD,
            -- MSHojokamoku.hojokamokuNM     as HSNM,
            Dnyuukinlog.seikyuusakiCD     as HSCD,
            Mtokuisaki.tokuisakiRNM       as HSNM,
            -- 2013/11/27 end
            Dnyuukinlog.hontai_kingaku    as hontai_kingaku,
            Dnyuukinlog.syouhizei         as kaikei_syouhizei,
            9                             as sotoutiKBN,
            1 as No
        from Dnyuukinlog
        inner join MKKamokuctl
        on  MKKamokuctl.dataKBN      = Dnyuukinlog.dataKBN
        and MKKamokuctl.torihikiKBN  = Dnyuukinlog.torihikiKBN
        and MKKamokuctl.programKBN   = Dnyuukinlog.nyuukinKBN
        and MKKamokuctl.siwakeCD     = 0
        left outer join MHKamokuctl
        on  MHKamokuctl.dataKBN        = Dnyuukinlog.dataKBN
        and MHKamokuctl.torihikiKBN    = Dnyuukinlog.torihikiKBN
        and MHKamokuctl.programKBN     = Dnyuukinlog.nyuukinKBN
        and MHKamokuctl.siwakeCD       = 0
        and MHKamokuctl.torihikisakiCD = Dnyuukinlog.seikyuusakiCD
        inner join MKanjoukamoku as MKKanjoukamoku
        on  MKKanjoukamoku.kanjoukamokuCD = MKKamokuctl.kkKamokuCD
        inner join MKanjoukamoku as MSKanjoukamoku
        on  MSKanjoukamoku.kanjoukamokuCD = MKKamokuctl.ksKamokuCD
        left outer join MHojokamoku as MKHojokamoku
        on  MKHojokamoku.kanjoukamokuCD = MKKamokuctl.kkKamokuCD
        and MKHojokamoku.hojokamokuCD   = MHKamokuctl.kkHojoCD
        left outer join MHojokamoku as MSHojokamoku
        on  MSHojokamoku.kanjoukamokuCD = MKKamokuctl.ksKamokuCD
        and MSHojokamoku.hojokamokuCD   = MHKamokuctl.ksHojoCD
        left outer join Mtokuisaki as Mtokuisaki
        on  Mtokuisaki.tokuisakiCD = Dnyuukinlog.seikyuusakiCD
        where Dnyuukinlog.keijounengetu = _I_kaikeiNengetu
        and  (_I_keijouDateFr = "2000-01-01" or Dnyuukinlog.nyuukindate >= _I_keijouDateFr)
        and  (_I_keijouDateTo = "2000-01-01" or Dnyuukinlog.nyuukindate <= _I_keijouDateTo)
        and  Dnyuukinlog.Krenkeidate IS NULL
        ;


    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    open curNyuukin;

    REPEAT
    FETCH curNyuukin
    INTO
        _kaikeiNendo,
        _denpyouNO,
        _gyouNO,
        _akakuro,
        _yuukou,
        _keijounengetu,
        _dataKBN,
        _torihikiKBN,
        _nyuukinKBN,
        _siwakeCD,
        _nyuukindate,
        _KKCD,
        _KKNM,
        _KSCD,
        _KSNM,
        _TKNM,
        _HKCD,
        _HKNM,
        _HSCD,
        _HSNM,
        _hontai_kingaku,
        _kaikei_syouhizei,
        _sotoutiKBN,
        _No;

    IF done = 0 THEN
        -- 伝票番号取得
        SET @kaikei_yyyy = 0;
        SET @DenpyouNumber = 0;
        call GetDenpyouNumber(
              150
             ,@kaikei_yyyy
             ,@DenpyouNumber);

        IF _sotoutiKBN = 0 then      -- 外税
            SET _ZEIKBN = '課税売上外';
        ELSEIF _sotoutiKBN = 1 then  -- 内税
            SET _ZEIKBN = '課税売上内';
        ELSE                         -- 非課税
            SET _ZEIKBN = '非課税';
        END IF;

        IF _hontai_kingaku >= 0 THEN
            /* 通常仕訳 */
            INSERT INTO Dsiwake
            (
                kaikeiNendo,
                denpyouNO,
                gyouNO,
                SEQ,
                akakuro,
                yuukou,
                keijounengetu,
                dataKBN,
                torihikiKBN,
                siwakeKBN,
                motoKaikeiNendo,
                motoDenpyouNO,
                motoGyouNO,
                sikibetuFLG,
                siwakeDenpyouNO,
                kessan,
                torihikiDate,
                kkKanjouCD,
                kkKanjouNM,
                kkHojoCD,
                kkHojoNM,
                kkBumonNM,
                kkZeiKBN,
                kkKingaku,
                kkZeigaku,
                ksKanjouCD,
                ksKanjouNM,
                ksHojoCD,
                ksHojoNM,
                ksBumonNM,
                ksZeiKBN,
                ksKingaku,
                ksZeigaku,
                tekiyou,
                bangou,
                kijiutu,
                type,
                seiseiMoto,
                siwakeMemo,
                fusen1,
                fusen2,
                tyousei,
                kouzaCD,
                insertdate,
                insertTantosya,
                updatedate,
                updateTantosya
            )
            values
            (
                @kaikei_yyyy,
                @DenpyouNumber,
                1,
                0,
                _akakuro,
                _yuukou,
                _keijounengetu,
                _dataKBN,
                _torihikiKBN,
                _nyuukinKBN,
                _kaikeiNendo,
                _denpyouNO,
                _gyouNO,
                '2000',
                0,
                '',
                _nyuukindate,

                _KKCD,
                _KKNM,
                _HKCD,
                _HKNM,
                '',
                _ZEIKBN,
                _hontai_kingaku,
                _kaikei_syouhizei,

                _KSCD,
                _KSNM,
                _HSCD,
                _HSNM,
                '',
                _ZEIKBN,
                _hontai_kingaku,
                _kaikei_syouhizei,

                '',
                '',
                '',
                0,
                '',
                '',
                0,
                0,
                'no',
                1,
                CURRENT_TIMESTAMP(),
                1,
                CURRENT_TIMESTAMP(),
                1
            );
        ELSE
            /* 逆仕訳 */
            INSERT INTO Dsiwake
            (
                kaikeiNendo,
                denpyouNO,
                gyouNO,
                SEQ,
                akakuro,
                yuukou,
                keijounengetu,
                dataKBN,
                torihikiKBN,
                siwakeKBN,
                motoKaikeiNendo,
                motoDenpyouNO,
                motoGyouNO,
                sikibetuFLG,
                siwakeDenpyouNO,
                kessan,
                torihikiDate,
                kkKanjouCD,
                kkKanjouNM,
                kkHojoCD,
                kkHojoNM,
                kkBumonNM,
                kkZeiKBN,
                kkKingaku,
                kkZeigaku,
                ksKanjouCD,
                ksKanjouNM,
                ksHojoCD,
                ksHojoNM,
                ksBumonNM,
                ksZeiKBN,
                ksKingaku,
                ksZeigaku,
                tekiyou,
                bangou,
                kijiutu,
                type,
                seiseiMoto,
                siwakeMemo,
                fusen1,
                fusen2,
                tyousei,
                kouzaCD,
                insertdate,
                insertTantosya,
                updatedate,
                updateTantosya
            )
            values
            (
                @kaikei_yyyy,
                @DenpyouNumber,
                1,
                0,
                _akakuro,
                _yuukou,
                _keijounengetu,
                _dataKBN,
                _torihikiKBN,
                _nyuukinKBN,
                _kaikeiNendo,
                _denpyouNO,
                _gyouNO,
                '2000',
                0,
                '',
                _nyuukindate,

                _KSCD,
                _KSNM,
                _HSCD,
                _HSNM,
                '',
                _ZEIKBN,
                _hontai_kingaku * -1,
                _kaikei_syouhizei * -1,

                _KKCD,
                _KKNM,
                _HKCD,
                _HKNM,
                '',
                _ZEIKBN,
                _hontai_kingaku * -1,
                _kaikei_syouhizei * -1,

                '',
                '',
                '',
                0,
                '',
                '',
                0,
                0,
                'no',
                1,
                CURRENT_TIMESTAMP(),
                1,
                CURRENT_TIMESTAMP(),
                1
            );
        END IF;

        UPDATE Dnyuukinlog
        SET  Dnyuukinlog.Krenkeidate = now()
        where Dnyuukinlog.keijounengetu = _I_kaikeiNengetu
        and  (_I_keijouDateFr = "2000-01-01" or Dnyuukinlog.nyuukindate >= _I_keijouDateFr)
        and  (_I_keijouDateTo = "2000-01-01" or Dnyuukinlog.nyuukindate <= _I_keijouDateTo)
        and  Dnyuukinlog.Krenkeidate IS NULL;
    END IF;
    UNTIL done END REPEAT;
    CLOSE curNyuukin;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
