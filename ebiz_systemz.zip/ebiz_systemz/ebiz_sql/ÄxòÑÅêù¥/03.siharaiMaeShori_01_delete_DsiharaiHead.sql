DROP PROCEDURE IF EXISTS siharaiMaeShori_01_delete_DsiharaiHead;
DELIMITER //
CREATE PROCEDURE siharaiMaeShori_01_delete_DsiharaiHead(
    IN _i_siharaisakiFrom   integer(6), -- 2014/02/07
    IN _i_siharaisakiTo     integer(6), -- 2014/02/07
    IN _i_siharaisakiCD1     integer(6),
    IN _i_siharaisakiCD2     integer(6),
    IN _i_siharaisakiCD3     integer(6),
    IN _i_siharaisakiCD4     integer(6),
    IN _i_siharaisakiCD5     integer(6),
    IN _i_siharaisakiCD6     integer(6),
    IN _i_siharaisakiCD7     integer(6),
    IN _i_siharaisakiCD8     integer(6),
    IN _i_siharaisakiCD9     integer(6),
    IN _i_siharaisakiCD10    integer(6),
    IN _i_siharainengetu     integer(6),
    IN _i_siharaiDateFrom    date,
    IN _i_siharaiDateTo      date,
    IN _i_simeBi             tinyint,
    IN _i_insertdate         date,
    IN _i_insertTantosya     integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    /* =============================================================================
       支払ヘッダ削除
       今回作成する支払ヘッダだが、過去に支払前処理のみされていて今回再度前処理をかけるものを削除
     =============================================================================== */
    DECLARE _kaikei_nendo integer(4)  DEFAULT 0;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    select kaikei_nendo into _kaikei_nendo from Mkanri where kanriCD = 1;

    delete from DsiharaiHead
    where kaikeiNendo = _kaikei_nendo
    and   siharainengetu = _i_siharainengetu
    and   simebi = _i_simeBi
    and
    (
        (
                _i_siharaisakiCD1 = 0 and _i_siharaisakiCD2 = 0
            and _i_siharaisakiCD3 = 0 and _i_siharaisakiCD4 = 0
            and _i_siharaisakiCD5 = 0 and _i_siharaisakiCD6 = 0
            and _i_siharaisakiCD7 = 0 and _i_siharaisakiCD8 = 0
            and _i_siharaisakiCD9 = 0 and _i_siharaisakiCD10 = 0
        )
        or
        (
        siharaisakiCD in (_i_siharaisakiCD1,_i_siharaisakiCD2,_i_siharaisakiCD3,
                                _i_siharaisakiCD4,_i_siharaisakiCD5,_i_siharaisakiCD6,
                                _i_siharaisakiCD7,_i_siharaisakiCD8,_i_siharaisakiCD9,
                                _i_siharaisakiCD10)
        )
    )
    and (_i_siharaisakiFrom = 0 or siharaisakiCD >= _i_siharaisakiFrom) -- 2014/02/07
    and (_i_siharaisakiTo = 0   or siharaisakiCD <= _i_siharaisakiTo)   -- 2014/02/07
    and   siharaikakuteidate IS NULL; -- 支払確定が終わってないもの

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
