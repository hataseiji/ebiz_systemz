DROP PROCEDURE IF EXISTS siharaiMaeShori;
DELIMITER //
CREATE PROCEDURE siharaiMaeShori(
    IN _i_siharaisakiCD1     integer(6),
    IN _i_siharaisakiCD2     integer(6),
    IN _i_siharaisakiCD3     integer(6),
    IN _i_siharaisakiCD4     integer(6),
    IN _i_siharaisakiCD5     integer(6),
    IN _i_siharaisakiCD6     integer(6),
    IN _i_siharaisakiCD7     integer(6),
    IN _i_siharaisakiCD8     integer(6),
    IN _i_siharaisakiCD9     integer(6),
    IN _i_siharaisakiCD10    integer(6),
    IN _i_siharaisakiFrom    integer(6),
    IN _i_siharaisakiTo      integer(6),
    IN _i_siharainengetu     integer(6),
    IN _i_siharaiDateFrom    date,
    IN _i_siharaiDateTo      date,
    IN _i_simeBi             tinyint,
    IN _i_insertdate         date,
    IN _i_insertTantosya     integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
       支払ヘッダ削除
       今回作成する支払ヘッダだが、過去に支払前処理のみされていて今回再度前処理をかけるものを削除
     ========================================================================= */
     call siharaiMaeShori_01_delete_DsiharaiHead(
            _i_siharaisakiFrom,  -- 2014/02/07
            _i_siharaisakiTo,    -- 2014/02/07
            _i_siharaisakiCD1,
            _i_siharaisakiCD2,
            _i_siharaisakiCD3,
            _i_siharaisakiCD4,
            _i_siharaisakiCD5,
            _i_siharaisakiCD6,
            _i_siharaisakiCD7,
            _i_siharaisakiCD8,
            _i_siharaisakiCD9,
            _i_siharaisakiCD10,
            _i_siharainengetu,
            _i_siharaiDateFrom,
            _i_siharaiDateTo,
            _i_simeBi,
            _i_insertdate,
            _i_insertTantosya,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    /* =========================================================================
       仕入データ内消費税誤差データを削除
       過去に支払前処理のみされていて今回再度前処理をかけるものを削除
    ========================================================================= */
    delete DSIR
    from Dsiire as DSIR
    inner join Ssiire as SSIR  -- 今回支払対象のデータを抽出済み
    on  SSIR.kaikeiNendo = DSIR.kaikeiNendo
    and SSIR.denpyouNO   = DSIR.denpyouNO
    and SSIR.gyouNO      = DSIR.gyouNO
    where DSIR.dataKBN     = 80
    and   DSIR.torihikiKBN = 82
    and   DSIR.siireKBN   = 80; -- 支払単位消費税

    /* =========================================================================
       今回支払・入金データより今回支払分支払ヘッダを作成
    ========================================================================= */
    call siharaiMaeShori_02_insert_DsiharaiHead(
            _i_siharainengetu,
            _i_simeBi,
            _i_insertdate,
            _i_insertTantosya,
            _i_siharaiDateFrom,
            _i_siharaiDateTo,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    /* =========================================================================
       仕入・入金データに支払書番号を更新
     ========================================================================= */
     call siharaiMaeShori_03_update_UriNyuukin(
            _i_siharainengetu,
            _i_simeBi,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    /* =========================================================================
       消費税が支払一括の支払先の消費税差額データを算出する
     ========================================================================= */
     call siharaiMaeShori_04_insert_zeiSagaku(
            _i_siharainengetu,
            _i_simeBi,
            _i_insertdate,
            _i_insertTantosya,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
