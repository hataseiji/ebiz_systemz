-- MySQL dump 10.13  Distrib 5.6.11, for osx10.7 (x86_64)
--
-- Host: localhost    Database: MsData
-- ------------------------------------------------------
-- Server version	5.6.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Dhattyuu`
--

DROP TABLE IF EXISTS `Dhattyuu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dhattyuu` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '発注番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `hattyuuKBN` int(3) DEFAULT NULL COMMENT '発注区分',
  `hattyuudate` date DEFAULT NULL COMMENT '発注日',
  `nyuukoyoteidate` date DEFAULT NULL COMMENT '入庫予定日',
  `ankenKaikeiNendo` int(4) DEFAULT '0' COMMENT '案件受注会計年度',
  `ankenjutyuuNO` int(6) DEFAULT '0' COMMENT '案件受注番号',
  `siiresakiCD` int(6) DEFAULT NULL COMMENT '仕入先CD',
  `siiresakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `nounyuusakiCD` int(6) DEFAULT NULL COMMENT '納入先CD',
  `nounyuusakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先名',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `nounyusaki_address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所1',
  `nounyusaki_address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所2',
  `nounyusaki_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先担当者名',
  `tyuumonNO` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '注文番号',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `mhattyuuKBN` tinyint(2) DEFAULT NULL COMMENT '明細発注区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `kiboudate` date DEFAULT NULL COMMENT '希望納期',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) DEFAULT '0' COMMENT '本体金額',
  `inji_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(印字用)',
  `kaikei_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(会計用)',
  `nyuukaKaikeiNendo` int(4) DEFAULT '0' COMMENT '入荷会計年度',
  `nyuukaNO` int(6) DEFAULT '0' COMMENT '入荷番号',
  `nyuuka_gyouNO` int(3) DEFAULT '0' COMMENT '入荷行番号',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='発注';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dhattyuulog`
--

DROP TABLE IF EXISTS `Dhattyuulog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dhattyuulog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '発注番号',
  `gyouNO` int(3) DEFAULT NULL COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `hattyuuKBN` int(3) DEFAULT NULL COMMENT '発注区分',
  `hattyuudate` date DEFAULT NULL COMMENT '発注日',
  `nyuukoyoteidate` date DEFAULT NULL COMMENT '入庫予定日',
  `ankenKaikeiNendo` int(4) DEFAULT '0' COMMENT '案件受注会計年度',
  `ankenjutyuuNO` int(6) DEFAULT '0' COMMENT '案件受注番号',
  `siiresakiCD` int(6) DEFAULT NULL COMMENT '仕入先CD',
  `siiresakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `nounyuusakiCD` int(6) DEFAULT NULL COMMENT '納入先CD',
  `nounyuusakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先名',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `nounyusaki_address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所1',
  `nounyusaki_address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所2',
  `nounyusaki_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先担当者名',
  `tyuumonNO` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '注文番号',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `mhattyuuKBN` tinyint(2) DEFAULT NULL COMMENT '明細発注区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `kiboudate` date DEFAULT NULL COMMENT '希望納期',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `inji_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(印字用)',
  `kaikei_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(会計用)',
  `nyuukaKaikeiNendo` int(4) DEFAULT '0' COMMENT '入荷会計年度',
  `nyuukaNO` int(6) DEFAULT '0' COMMENT '入荷番号',
  `nyuuka_gyouNO` int(3) DEFAULT '0' COMMENT '入荷行番号',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=956 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='発注ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Didou`
--

DROP TABLE IF EXISTS `Didou`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Didou` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '移動番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `idouKBN` int(3) DEFAULT NULL COMMENT '移動区分',
  `idoudate` date DEFAULT NULL COMMENT '移動日',
  `motosoukoCD` int(6) DEFAULT NULL COMMENT '移動元倉庫CD',
  `sakisoukoCD` int(6) DEFAULT NULL COMMENT '移動左先倉庫CD',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `midouKBN` tinyint(2) DEFAULT NULL COMMENT '明細移動区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `tyoubo` decimal(10,3) DEFAULT '0.000' COMMENT '帳簿在庫数',
  `suryou` decimal(10,3) NOT NULL COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL COMMENT '金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='移動';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Didoulog`
--

DROP TABLE IF EXISTS `Didoulog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Didoulog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '移動番号',
  `gyouNO` int(3) DEFAULT NULL COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `idouKBN` int(3) DEFAULT NULL COMMENT '移動区分',
  `idoudate` date DEFAULT NULL COMMENT '移動日',
  `motosoukoCD` int(6) DEFAULT NULL COMMENT '移動元倉庫CD',
  `sakisoukoCD` int(6) DEFAULT NULL COMMENT '移動左先倉庫CD',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `midouKBN` tinyint(2) DEFAULT NULL COMMENT '明細移動区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `tyoubo` decimal(10,3) DEFAULT '0.000' COMMENT '帳簿在庫数',
  `suryou` decimal(10,3) NOT NULL COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL COMMENT '金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='移動ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Djutyuu`
--

DROP TABLE IF EXISTS `Djutyuu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Djutyuu` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '受注番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` tinyint(2) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` tinyint(2) DEFAULT NULL COMMENT '取引区分',
  `jutyuuKBN` tinyint(2) DEFAULT NULL COMMENT '受注区分',
  `mitumoriKaikeiNendo` int(4) DEFAULT '0' COMMENT '見積会計年度',
  `mitumoriNO` int(6) DEFAULT NULL COMMENT '見積番号',
  `jutyuudate` date DEFAULT NULL COMMENT '受注日',
  `syukkadate` date DEFAULT NULL COMMENT '出荷日',
  `nouki` date DEFAULT NULL COMMENT '納期',
  `ankenKaikeiNendo` int(4) DEFAULT '0' COMMENT '案件受注会計年度',
  `ankenjutyuuNO` int(6) DEFAULT '0' COMMENT '案件受注番号',
  `ankenNM` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '案件名',
  `tokuisakiCD` int(6) DEFAULT NULL COMMENT '得意先CD',
  `tokuisakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `nounyuusakiCD` int(6) DEFAULT NULL COMMENT '納入先CD',
  `nounyuusakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先名',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `nounyusaki_address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所1',
  `nounyusaki_address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所2',
  `nounyusaki_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先担当者名',
  `TtyuumonNo` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先注文番号',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `mjutyuuKBN` tinyint(2) DEFAULT NULL COMMENT '明細受注区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `genka_tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '原価単価',
  `genka_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '原価金額',
  `arari` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '粗利',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `inji_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(印字用)',
  `kaikei_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(会計用)',
  `syukkaKaikeiNendo` int(4) NOT NULL,
  `syukkaNO` int(6) NOT NULL,
  `syukka_gyouNO` int(3) NOT NULL,
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `KakuninSyoHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '受注確認書発行済F',
  `kanryou_flg` tinyint(1) NOT NULL DEFAULT '0' COMMENT '完了フラグ',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='受注';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Djutyuulog`
--

DROP TABLE IF EXISTS `Djutyuulog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Djutyuulog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '受注番号',
  `gyouNO` int(3) DEFAULT NULL COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `jutyuuKBN` int(3) DEFAULT NULL COMMENT '受注区分',
  `mitumoriKaikeiNendo` int(4) DEFAULT '0' COMMENT '見積会計年度',
  `mitumoriNO` int(6) DEFAULT NULL COMMENT '見積番号',
  `jutyuudate` date DEFAULT NULL COMMENT '受注日',
  `syukkadate` date DEFAULT NULL COMMENT '出荷日',
  `nouki` date DEFAULT NULL COMMENT '納期',
  `ankenKaikeiNendo` int(4) DEFAULT '0' COMMENT '案件受注会計年度',
  `ankenjutyuuNO` int(6) DEFAULT '0' COMMENT '案件受注番号',
  `ankenNM` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '案件名',
  `tokuisakiCD` int(6) DEFAULT NULL COMMENT '得意先CD',
  `tokuisakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `nounyuusakiCD` int(6) DEFAULT NULL COMMENT '納入先CD',
  `nounyuusakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先名',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `nounyusaki_address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所1',
  `nounyusaki_address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所2',
  `nounyusaki_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先担当者名',
  `TtyuumonNo` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先注文番号',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `mjutyuuKBN` tinyint(2) DEFAULT NULL COMMENT '明細受注区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `genka_tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '原価単価',
  `genka_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '原価金額',
  `arari` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '粗利',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `inji_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(印字用)',
  `kaikei_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(会計用)',
  `syukkaKaikeiNendo` int(4) NOT NULL,
  `syukkaNO` int(6) NOT NULL,
  `syukka_gyouNO` int(3) NOT NULL,
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `KakuninSyoHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '受注確認書発行済F',
  `kanryou_flg` tinyint(1) NOT NULL DEFAULT '0' COMMENT '完了フラグ',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=2989 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='受注ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dkaikakezan`
--

DROP TABLE IF EXISTS `Dkaikakezan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dkaikakezan` (
  `siiresakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '仕入先CD',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `keijoutukisuu` int(2) NOT NULL DEFAULT '0' COMMENT '計上月数',
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `zan` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '前月末残',
  `yosan` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '予算',
  `siiregaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '仕入額',
  `hennpinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '返品額',
  `nebikigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '値引額',
  `siharaigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '支払額',
  `syouhizeigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '変更日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '変更オペレータCD',
  PRIMARY KEY (`siiresakiCD`,`keijounengetu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='月別買掛残高';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dkaisyuuyotei`
--

DROP TABLE IF EXISTS `Dkaisyuuyotei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dkaisyuuyotei` (
  `seikyuusakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '請求先CD',
  `kaisyuuyoteidate` date NOT NULL COMMENT '回収予定日',
  `nyuukinnsyubetu` tinyint(2) NOT NULL DEFAULT '0' COMMENT '入金種別',
  `simebi` tinyint(2) NOT NULL DEFAULT '0' COMMENT '締日',
  `kaisyuuyoteigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '回収予定額',
  `hontai_kingaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `nyuukin_kesikomigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '入金消込済額',
  `seikyuunengetu` int(6) NOT NULL DEFAULT '0' COMMENT '請求年月',
  `seikyuusyoBangou` int(6) NOT NULL DEFAULT '0' COMMENT '請求書番号',
  `kanryouKBN` tinyint(1) NOT NULL DEFAULT '0' COMMENT '手形種類区分',
  `tegataBangou` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '手形番号',
  `tegataKijitu` date NOT NULL COMMENT '手形期日',
  `tegataFuridasinin` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '手形振出人',
  `insertdate` datetime NOT NULL COMMENT '登録日時',
  `insertTantosya` int(6) NOT NULL DEFAULT '0' COMMENT '登録オペレータCD',
  PRIMARY KEY (`seikyuusakiCD`,`kaisyuuyoteidate`,`nyuukinnsyubetu`,`simebi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='回収予定データ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dmitumori`
--

DROP TABLE IF EXISTS `Dmitumori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dmitumori` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '見積番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `mitumoriKBN` int(3) DEFAULT NULL COMMENT '見積区分',
  `mitumoridate` date DEFAULT NULL COMMENT '見積日',
  `syukkadate` date DEFAULT NULL COMMENT '出荷日',
  `nouki` date DEFAULT NULL COMMENT '納期',
  `tokuisakiCD` int(6) DEFAULT NULL COMMENT '得意先CD',
  `tokuisakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `TtyuumonNo` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先注文番号',
  `mitumriAnken1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '見積案件名1',
  `mitumriAnken2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '見積案件名2',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `mmitumoriKBN` int(3) DEFAULT NULL COMMENT '明細見積区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `genka_tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '原価単価',
  `genka_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '原価金額',
  `arari` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '粗利',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `inji_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(印字用)',
  `kaikei_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(会計用)',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='見積';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dmitumorilog`
--

DROP TABLE IF EXISTS `Dmitumorilog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dmitumorilog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '見積番号',
  `gyouNO` int(3) DEFAULT NULL COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `mitumoriKBN` int(3) DEFAULT NULL COMMENT '見積区分',
  `mitumoridate` date DEFAULT NULL COMMENT '見積日',
  `syukkadate` date DEFAULT NULL COMMENT '出荷日',
  `nouki` date DEFAULT NULL COMMENT '納期',
  `tokuisakiCD` int(6) DEFAULT NULL COMMENT '得意先CD',
  `tokuisakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `TtyuumonNo` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先注文番号',
  `mitumriAnken1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '見積案件名1',
  `mitumriAnken2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '見積案件名2',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `mmitumoriKBN` int(3) DEFAULT NULL COMMENT '明細見積区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `genka_tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '原価単価',
  `genka_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '原価金額',
  `arari` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '粗利',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `inji_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(印字用)',
  `kaikei_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(会計用)',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=2194 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='見積ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dnyuuka`
--

DROP TABLE IF EXISTS `Dnyuuka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dnyuuka` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '入荷番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `nyuukaKBN` int(3) DEFAULT NULL COMMENT '入荷区分',
  `hattyuuKaikeiNendo` int(4) DEFAULT '0' COMMENT '発注会計年度',
  `hattyuuNO` int(6) DEFAULT NULL COMMENT '発注番号',
  `hattyuu_gyouNO` int(3) DEFAULT '0' COMMENT '発注行番号',
  `siireKaikeiNendo` int(4) DEFAULT '0' COMMENT '仕入会計年度',
  `siireNO` int(6) DEFAULT NULL COMMENT '仕入番号',
  `siire_gyouNO` int(3) DEFAULT '0' COMMENT '仕入行番号',
  `nyuukadate` date DEFAULT NULL COMMENT '入荷日',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `siiresakiCD` int(6) DEFAULT NULL COMMENT '仕入先CD',
  `siiresakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先名',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `mnyuukaKBN` tinyint(2) DEFAULT NULL COMMENT '明細入荷区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `hattyuu_suryou` decimal(10,3) DEFAULT '0.000' COMMENT '発注数量',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '入荷数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '入荷単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '入荷金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `updDataKBN` int(3) DEFAULT '0' COMMENT '更新元データ区分',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='入荷';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dnyuukalog`
--

DROP TABLE IF EXISTS `Dnyuukalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dnyuukalog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '入荷番号',
  `gyouNO` int(3) DEFAULT NULL COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `nyuukaKBN` int(3) DEFAULT NULL COMMENT '入荷区分',
  `hattyuuKaikeiNendo` int(4) DEFAULT '0' COMMENT '発注会計年度',
  `hattyuuNO` int(6) DEFAULT NULL COMMENT '発注番号',
  `hattyuu_gyouNO` int(3) DEFAULT '0' COMMENT '発注行番号',
  `siireKaikeiNendo` int(4) DEFAULT '0' COMMENT '仕入会計年度',
  `siireNO` int(6) DEFAULT NULL COMMENT '仕入番号',
  `siire_gyouNO` int(3) DEFAULT '0' COMMENT '仕入行番号',
  `nyuukadate` date DEFAULT NULL COMMENT '入荷日',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `siiresakiCD` int(6) DEFAULT NULL COMMENT '仕入先CD',
  `siiresakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先名',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `mnyuukaKBN` tinyint(2) DEFAULT NULL COMMENT '明細入荷区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `hattyuu_suryou` decimal(10,3) DEFAULT '0.000' COMMENT '発注数量',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '入荷数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '入荷単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '入荷金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `updDataKBN` int(3) DEFAULT '0' COMMENT '更新元データ区分',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=2589 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='入荷ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dnyuukin`
--

DROP TABLE IF EXISTS `Dnyuukin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dnyuukin` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '入金番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `nyuukinKBN` int(3) DEFAULT NULL COMMENT '入金区分',
  `nyuukindate` date DEFAULT NULL COMMENT '入金日',
  `seikyuusakiCD` int(6) DEFAULT NULL COMMENT '請求先CD',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `mnyuukinKBN` tinyint(2) DEFAULT NULL COMMENT '明細入金区分',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '入金金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `seikyuusyoBangou` int(6) DEFAULT NULL COMMENT '請求書番号',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `ginkouNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '銀行名',
  `sitenNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '支店名',
  `tegatadate` date DEFAULT NULL COMMENT '手形期日',
  `tegataNO` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '手形番号',
  `furidasiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '振出人名',
  `Krenkeidate` datetime DEFAULT NULL COMMENT '会計連携日時',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='入金\n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dnyuukinlog`
--

DROP TABLE IF EXISTS `Dnyuukinlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dnyuukinlog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '入金番号',
  `gyouNO` int(3) DEFAULT NULL COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `nyuukinKBN` int(3) DEFAULT NULL COMMENT '入金区分',
  `nyuukindate` date DEFAULT NULL COMMENT '入金日',
  `seikyuusakiCD` int(6) DEFAULT NULL COMMENT '請求先CD',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `mnyuukinKBN` tinyint(2) DEFAULT NULL COMMENT '明細入金区分',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '入金金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `seikyuusyoBangou` int(6) DEFAULT NULL COMMENT '請求書番号',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `ginkouNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '銀行名',
  `sitenNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '支店名',
  `tegatadate` date DEFAULT NULL COMMENT '手形期日',
  `tegataNO` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '手形番号',
  `furidasiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '振出人名',
  `Krenkeidate` datetime DEFAULT NULL COMMENT '会計連携日時',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=278 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='入金ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dnyuusyukko`
--

DROP TABLE IF EXISTS `Dnyuusyukko`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dnyuusyukko` (
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(11) DEFAULT NULL COMMENT '伝票番号',
  `gyouNO` int(11) DEFAULT NULL COMMENT '行番号',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `systemKBN` int(3) DEFAULT NULL COMMENT 'システム区分',
  `nyuusyukkodate` date DEFAULT NULL COMMENT '入出庫日',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=6671 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='入出庫';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DseikyuuHead`
--

DROP TABLE IF EXISTS `DseikyuuHead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DseikyuuHead` (
  `seikyuusakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '請求先CD',
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `seikyuunengetu` int(6) NOT NULL DEFAULT '0' COMMENT '請求年月',
  `simebi` tinyint(2) NOT NULL DEFAULT '0' COMMENT '締日',
  `uriagedateFrom` date DEFAULT NULL COMMENT '開始売上年月日',
  `uriagedateTo` date DEFAULT NULL COMMENT '終了売上年月日',
  `ZENZAN` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '前回繰越額',
  `uriagegaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回売上額\n今回売上額\n今回売上額',
  `hennpinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回返品額',
  `nebikigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回値引額',
  `nyuukinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回入金額',
  `syouhizeigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回消費税額',
  `syouhizeisagaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回消費税差額',
  `gkmn_uriagegaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面売上額',
  `gkmn_hennpinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面返品額',
  `gkmn_nebikigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面値引額',
  `gkmn_nyuukinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面入金額',
  `gkmn_syouhizeigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面消費税額',
  `gkmn_syouhizeisagaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面消費税差額',
  `hakkouKBN` tinyint(1) DEFAULT NULL COMMENT '請求書発行区分',
  `kakuteiKBN` tinyint(1) DEFAULT NULL COMMENT '請求書確定区分',
  `seikyuusyoBangou` int(6) DEFAULT NULL COMMENT '請求書番号',
  `seikyuusyohakkoudate` datetime DEFAULT NULL COMMENT '請求書発行日時',
  `seikyuukakuteidate` datetime DEFAULT NULL COMMENT '請求確定日時',
  `jikaikurikosigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '次回繰越額',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seikyuusakiCD`,`kaikeiNendo`,`seikyuunengetu`,`simebi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='請求ヘッダ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsiharai`
--

DROP TABLE IF EXISTS `Dsiharai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsiharai` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '支払番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `siharaiKBN` int(3) DEFAULT NULL COMMENT '支払区分',
  `siharaidate` date DEFAULT NULL COMMENT '支払日',
  `siharaisakiCD` int(6) DEFAULT NULL COMMENT '支払先CD',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `msiharaiKBN` tinyint(2) DEFAULT NULL COMMENT '明細支払区分',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '支払金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `siharaisyoBangou` int(6) DEFAULT NULL COMMENT '支払書番号',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `ginkouNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '銀行名',
  `sitenNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '支店名',
  `tegatadate` date DEFAULT NULL COMMENT '手形期日',
  `tegataNO` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '手形番号',
  `furidasiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '振出人名',
  `Krenkeidate` datetime DEFAULT NULL COMMENT '会計連携日時',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='支払\n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DsiharaiHead`
--

DROP TABLE IF EXISTS `DsiharaiHead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DsiharaiHead` (
  `siharaisakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '支払先CD',
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `siharainengetu` int(6) NOT NULL DEFAULT '0' COMMENT '支払年月',
  `simebi` tinyint(2) NOT NULL DEFAULT '0' COMMENT '締日',
  `siiredateFrom` date DEFAULT NULL COMMENT '開始仕入年月日',
  `siiredateTo` date DEFAULT NULL COMMENT '終了仕入年月日',
  `ZENZAN` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '前回繰越額',
  `siiregaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回仕入額',
  `hennpinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回返品額',
  `nebikigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回値引額',
  `siharaigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回支払額',
  `syouhizeigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回消費税額',
  `syouhizeisagaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '今回消費税差額',
  `gkmn_siiregaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面仕入額',
  `gkmn_hennpinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面返品額',
  `gkmn_nebikigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面値引額',
  `gkmn_siharaigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面支払額',
  `gkmn_syouhizeigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面消費税額',
  `gkmn_syouhizeisagaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '額面消費税差額',
  `hakkouKBN` tinyint(1) DEFAULT NULL COMMENT '支払案内書発行区分',
  `kakuteiKBN` tinyint(1) DEFAULT NULL COMMENT '支払確定区分',
  `siharaisyoBangou` int(6) DEFAULT NULL COMMENT '支払案内書番号',
  `siharaisyohakkoudate` datetime DEFAULT NULL COMMENT '支払案内書発行日時',
  `siharaikakuteidate` datetime DEFAULT NULL COMMENT '支払確定日時',
  `jikaikurikosigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '次回繰越額',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`siharaisakiCD`,`kaikeiNendo`,`siharainengetu`,`simebi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='支払ヘッダ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsiharailog`
--

DROP TABLE IF EXISTS `Dsiharailog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsiharailog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '支払番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `siharaiKBN` int(3) DEFAULT NULL COMMENT '支払区分',
  `siharaidate` date DEFAULT NULL COMMENT '支払日',
  `siharaisakiCD` int(6) DEFAULT NULL COMMENT '支払先CD',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `msiharaiKBN` tinyint(2) DEFAULT NULL COMMENT '明細支払区分',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '支払金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `siharaisyoBangou` int(6) DEFAULT NULL COMMENT '支払書番号',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `ginkouNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '銀行名',
  `sitenNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '支店名',
  `tegatadate` date DEFAULT NULL COMMENT '手形期日',
  `tegataNO` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '手形番号',
  `furidasiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '振出人名',
  `Krenkeidate` datetime DEFAULT NULL COMMENT '会計連携日時',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=264 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='支払ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsiharaiyotei`
--

DROP TABLE IF EXISTS `Dsiharaiyotei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsiharaiyotei` (
  `siharaisakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '支払先CD',
  `siharaiyoteidate` date NOT NULL COMMENT '支払予定日',
  `siharaisyubetu` tinyint(2) NOT NULL DEFAULT '0' COMMENT '支払種別',
  `simebi` tinyint(2) NOT NULL DEFAULT '0' COMMENT '締日',
  `siharaiyoteigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '支払予定額',
  `hontai_kingaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `siharai_kesikomigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '支払消込済額',
  `siharainengetu` int(6) NOT NULL DEFAULT '0' COMMENT '支払年月',
  `siharaisyoBangou` int(6) NOT NULL DEFAULT '0' COMMENT '支払書番号',
  `kanryouKBN` tinyint(1) NOT NULL DEFAULT '0' COMMENT '手形種類区分',
  `tegataBangou` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '手形番号',
  `tegataKijitu` date NOT NULL COMMENT '手形期日',
  `tegataFuridasinin` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '手形振出人',
  `insertdate` datetime NOT NULL COMMENT '登録日時',
  `insertTantosya` int(6) NOT NULL DEFAULT '0' COMMENT '登録オペレータCD',
  PRIMARY KEY (`siharaisakiCD`,`siharaiyoteidate`,`siharaisyubetu`,`simebi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='支払予定データ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsiire`
--

DROP TABLE IF EXISTS `Dsiire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsiire` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '仕入番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `siireKBN` int(3) DEFAULT NULL COMMENT '仕入区分',
  `hattyuuKaikeiNendo` int(4) DEFAULT '0' COMMENT '発注会計年度',
  `hattyuuNO` int(6) DEFAULT NULL COMMENT '発注番号',
  `hattyuu_gyouNO` int(3) DEFAULT '0' COMMENT '発注行番号',
  `nyuukaKaikeiNendo` int(4) DEFAULT '0' COMMENT '入荷会計年度',
  `nyuukaNO` int(6) DEFAULT NULL COMMENT '入荷番号',
  `nyuuka_gyouNO` int(3) DEFAULT '0' COMMENT '入荷行番号',
  `siiredate` date DEFAULT NULL COMMENT '仕入日',
  `nyuukadate` date DEFAULT NULL COMMENT '入荷日',
  `ankenKaikeiNendo` int(4) DEFAULT '0' COMMENT '案件会計年度',
  `ankenjutyuuNO` int(6) DEFAULT NULL COMMENT '案件受注番号',
  `siiresakiCD` int(6) DEFAULT NULL COMMENT '仕入先CD',
  `siiresakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `msiireKBN` tinyint(2) DEFAULT NULL COMMENT '明細仕入区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `inji_syouhizei` decimal(10,0) NOT NULL COMMENT '消費税額(印字用)',
  `kaikei_syouhizei` decimal(10,0) NOT NULL COMMENT '消費税額(会計用)',
  `siharaisyoBangou` int(6) DEFAULT NULL COMMENT '支払案内書番号',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `Krenkeidate` datetime DEFAULT NULL COMMENT '会計連携日時',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='仕入';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsiirelog`
--

DROP TABLE IF EXISTS `Dsiirelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsiirelog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '仕入番号',
  `gyouNO` int(3) DEFAULT NULL COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `siireKBN` int(3) DEFAULT NULL COMMENT '仕入区分',
  `hattyuuKaikeiNendo` int(4) DEFAULT '0' COMMENT '発注会計年度',
  `hattyuuNO` int(6) DEFAULT NULL COMMENT '発注番号',
  `hattyuu_gyouNO` int(3) DEFAULT '0' COMMENT '発注行番号',
  `nyuukaKaikeiNendo` int(4) DEFAULT '0' COMMENT '入荷会計年度',
  `nyuukaNO` int(6) DEFAULT NULL COMMENT '入荷番号',
  `nyuuka_gyouNO` int(3) DEFAULT '0' COMMENT '入荷行番号',
  `siiredate` date DEFAULT NULL COMMENT '仕入日',
  `nyuukadate` date DEFAULT NULL COMMENT '入荷日',
  `ankenKaikeiNendo` int(4) DEFAULT '0' COMMENT '案件会計年度',
  `ankenjutyuuNO` int(6) DEFAULT NULL COMMENT '案件受注番号',
  `siiresakiCD` int(6) DEFAULT NULL COMMENT '仕入先CD',
  `siiresakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `msiireKBN` tinyint(2) DEFAULT NULL COMMENT '明細仕入区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `inji_syouhizei` decimal(10,0) NOT NULL COMMENT '消費税額(印字用)',
  `kaikei_syouhizei` decimal(10,0) NOT NULL COMMENT '消費税額(会計用)',
  `siharaisyoBangou` int(6) DEFAULT NULL COMMENT '支払案内書番号',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `Krenkeidate` datetime DEFAULT NULL COMMENT '会計連携日時',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=3077 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='仕入ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsiireseigyo`
--

DROP TABLE IF EXISTS `Dsiireseigyo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsiireseigyo` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '売上番号',
  `nyuukaseigyo` tinyint(1) DEFAULT '0' COMMENT '出荷制御区分',
  `yobiKBN1` tinyint(1) DEFAULT '0' COMMENT '予備区分1',
  `yobiKBN2` tinyint(1) DEFAULT '0' COMMENT '予備区分2',
  `yobiKBN3` tinyint(1) DEFAULT '0' COMMENT '予備区分3',
  `yobiKBN4` tinyint(1) DEFAULT '0' COMMENT '予備区分4',
  `yobiKBN5` tinyint(1) DEFAULT '0' COMMENT '予備区分5',
  `yobiSuuti1` int(6) DEFAULT '0' COMMENT '予備数値1',
  `yobiSuuti2` int(6) DEFAULT '0' COMMENT '予備数値2',
  `yobiSuuti3` int(6) DEFAULT '0' COMMENT '予備数値3',
  `yobiSuuti4` int(6) DEFAULT '0' COMMENT '予備数値4',
  `yobiSuuti5` int(6) DEFAULT '0' COMMENT '予備数値1',
  `yobiKingaku1` decimal(13,3) DEFAULT '0.000' COMMENT '予備金額1',
  `yobiKingaku2` decimal(13,3) DEFAULT '0.000' COMMENT '予備金額2',
  `yobiKingaku3` decimal(13,3) DEFAULT '0.000' COMMENT '予備金額3',
  `yobiKingaku4` decimal(13,3) DEFAULT '0.000' COMMENT '予備金額4',
  `yobiKingaku5` decimal(13,3) DEFAULT '0.000' COMMENT '予備金額5',
  `yobiKoumoku1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目1',
  `yobiKoumoku2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目2',
  `yobiKoumoku3` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目3',
  `yobiKoumoku4` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目4',
  `yobiKoumoku5` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目5',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='仕入制御';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsiwake`
--

DROP TABLE IF EXISTS `Dsiwake`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsiwake` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '伝票番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) NOT NULL DEFAULT '0' COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `siwakeKBN` int(3) DEFAULT NULL COMMENT '仕訳区分',
  `motokaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '元会計年度',
  `motodenpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '元伝票番号',
  `motogyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '元行番号',
  `sikibetuFLG` varchar(4) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '識別フラグ',
  `siwakeDenpyouNO` int(6) DEFAULT NULL COMMENT '仕訳伝票番号',
  `kessan` varchar(4) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '決算',
  `torihikiDate` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '取引日付',
  `kkKanjouCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方勘定科目CD',
  `kkKanjouNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方勘定科目名',
  `kkHojoCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方補助科目CD',
  `kkHojoNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方補助科目名',
  `kkBumonNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方部門名',
  `kkZeiKBN` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方税区分',
  `kkKingaku` decimal(11,0) NOT NULL DEFAULT '0' COMMENT '借方金額',
  `kkZeigaku` decimal(11,0) NOT NULL DEFAULT '0' COMMENT '借方税額',
  `ksKanjouCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方勘定科目CD',
  `ksKanjouNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方勘定科目名',
  `ksHojoCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方補助科目CD',
  `ksHojoNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方補助科目名',
  `ksBumonNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方部門名',
  `ksZeiKBN` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方税区分',
  `ksKingaku` decimal(11,0) NOT NULL DEFAULT '0' COMMENT '貸方金額',
  `ksZeigaku` decimal(11,0) NOT NULL DEFAULT '0' COMMENT '貸方税額',
  `tekiyou` varchar(64) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '摘要',
  `bangou` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '番号',
  `kijiutu` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '期日',
  `type` tinyint(1) DEFAULT NULL COMMENT 'タイプ',
  `seiseiMoto` varchar(4) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '生成元',
  `siwakeMemo` varchar(180) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '仕訳メモ',
  `fusen1` tinyint(1) DEFAULT NULL COMMENT '付箋1',
  `fusen2` tinyint(1) DEFAULT NULL COMMENT '付箋2',
  `tyousei` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '調整',
  `kouzaCD` int(6) DEFAULT '0' COMMENT '口座CD',
  `tantosyaCD` int(6) DEFAULT '0' COMMENT '担当者CD',
  `tantosyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '担当者名',
  `kaikeiRenkeiDate` datetime DEFAULT NULL COMMENT '会計連携日時',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='仕訳ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsiwakelog`
--

DROP TABLE IF EXISTS `Dsiwakelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsiwakelog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '伝票番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `siwakeKBN` int(3) DEFAULT NULL COMMENT '仕訳区分',
  `motokaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '元会計年度',
  `motodenpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '元伝票番号',
  `motogyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '元行番号',
  `sikibetuFLG` varchar(4) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '識別フラグ',
  `siwakeDenpyouNO` int(6) DEFAULT NULL COMMENT '仕訳伝票番号',
  `kessan` varchar(4) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '決算',
  `torihikiDate` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '取引日付',
  `kkKanjouCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方勘定科目CD',
  `kkKanjouNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方勘定科目名',
  `kkHojoCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方補助科目CD',
  `kkHojoNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方補助科目名',
  `kkBumonNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方部門名',
  `kkZeiKBN` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方税区分',
  `kkKingaku` decimal(11,0) NOT NULL DEFAULT '0' COMMENT '借方金額',
  `kkZeigaku` decimal(11,0) NOT NULL DEFAULT '0' COMMENT '借方税額',
  `ksKanjouCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方勘定科目CD',
  `ksKanjouNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方勘定科目名',
  `ksHojoCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方補助科目CD',
  `ksHojoNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方補助科目名',
  `ksBumonNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方部門名',
  `ksZeiKBN` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方税区分',
  `ksKingaku` decimal(11,0) NOT NULL DEFAULT '0' COMMENT '貸方金額',
  `ksZeigaku` decimal(11,0) NOT NULL DEFAULT '0' COMMENT '貸方税額',
  `tekiyou` varchar(64) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '摘要',
  `bangou` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '番号',
  `kijiutu` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '期日',
  `type` tinyint(1) DEFAULT NULL COMMENT 'タイプ',
  `seiseiMoto` varchar(4) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '生成元',
  `siwakeMemo` varchar(180) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '仕訳メモ',
  `fusen1` tinyint(1) DEFAULT NULL COMMENT '付箋1',
  `fusen2` tinyint(1) DEFAULT NULL COMMENT '付箋2',
  `tyousei` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '調整',
  `kouzaCD` int(6) DEFAULT '0' COMMENT '口座CD',
  `tantosyaCD` int(6) DEFAULT '0' COMMENT '担当者CD',
  `tantosyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '担当者名',
  `kaikeiRenkeiDate` datetime DEFAULT NULL COMMENT '会計連携日時',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='仕訳ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsyouhinsiire`
--

DROP TABLE IF EXISTS `Dsyouhinsiire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsyouhinsiire` (
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '商品CD',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `keijoutukisuu` int(2) NOT NULL DEFAULT '0' COMMENT '計上月数',
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `siiregaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '仕入額',
  `hennpinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '返品額',
  `nebikigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '値引額',
  `syouhizeigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '変更日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '変更オペレータCD',
  PRIMARY KEY (`syouhinCD`,`keijounengetu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='月別商品仕入実績';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsyouhinuriage`
--

DROP TABLE IF EXISTS `Dsyouhinuriage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsyouhinuriage` (
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '商品CD',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `keijoutukisuu` int(2) NOT NULL DEFAULT '0' COMMENT '計上月数',
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `uriagegaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '売上額',
  `hennpinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '返品額',
  `nebikigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '値引額',
  `syouhizeigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `genka` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '原価',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '変更日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '変更オペレータCD',
  PRIMARY KEY (`syouhinCD`,`keijounengetu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='月別商品売上実績';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsyukka`
--

DROP TABLE IF EXISTS `Dsyukka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsyukka` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '出荷番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `syukkaKBN` int(3) DEFAULT NULL COMMENT '出荷区分',
  `jutyuuKaikeiNendo` int(4) DEFAULT '0' COMMENT '受注会計年度',
  `jutyuuNO` int(6) DEFAULT NULL COMMENT '受注番号',
  `jutyuu_gyouNO` int(3) DEFAULT '0' COMMENT '受注行番号',
  `uriageKaikeiNendo` int(4) DEFAULT '0' COMMENT '売上会計年度',
  `uriageNO` int(6) DEFAULT NULL COMMENT '売上番号',
  `uriage_gyouNO` int(3) DEFAULT '0' COMMENT '売上行番号',
  `syukkadate` date DEFAULT NULL COMMENT '出荷日',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `nouhinsyo_tankaKBN` tinyint(1) DEFAULT NULL COMMENT '納品書単価区分',
  `msyukkaKBN` tinyint(2) DEFAULT NULL COMMENT '明細出荷区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '出荷数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `NouhinsyoHakkou` tinyint(1) DEFAULT '0' COMMENT '納品書発行F',
  `updDataKBN` int(3) DEFAULT '0' COMMENT '更新元データ区分',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='出荷';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsyukkalog`
--

DROP TABLE IF EXISTS `Dsyukkalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsyukkalog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '出荷番号',
  `gyouNO` int(3) DEFAULT NULL COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `syukkaKBN` int(3) DEFAULT NULL COMMENT '出荷区分',
  `jutyuuKaikeiNendo` int(4) DEFAULT '0' COMMENT '受注会計年度',
  `jutyuuNO` int(6) DEFAULT NULL COMMENT '受注番号',
  `jutyuu_gyouNO` int(3) DEFAULT '0' COMMENT '受注行番号',
  `uriageKaikeiNendo` int(4) DEFAULT '0' COMMENT '売上会計年度',
  `uriageNO` int(6) DEFAULT NULL COMMENT '売上番号',
  `uriage_gyouNO` int(3) DEFAULT '0' COMMENT '売上行番号',
  `syukkadate` date DEFAULT NULL COMMENT '出荷日',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `nouhinsyo_tankaKBN` tinyint(1) DEFAULT NULL COMMENT '納品書単価区分',
  `msyukkaKBN` tinyint(2) DEFAULT NULL COMMENT '明細出荷区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '出荷数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '金額',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `NouhinsyoHakkou` tinyint(1) DEFAULT '0' COMMENT '納品書発行F',
  `updDataKBN` int(3) DEFAULT '0' COMMENT '更新元データ区分',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=3934 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='出荷ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsyukkasiji`
--

DROP TABLE IF EXISTS `Dsyukkasiji`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsyukkasiji` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '出荷指示番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `syukkasijiKBN` int(3) DEFAULT NULL COMMENT '出荷指示区分',
  `syukkasijidate` date DEFAULT NULL COMMENT '出荷指示日',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `jutyuuKaikeiNendo` int(4) DEFAULT '0' COMMENT '受注会計年度',
  `jutyuuNO` int(6) DEFAULT NULL COMMENT '受注番号',
  `jutyuu_gyouNO` int(3) DEFAULT NULL COMMENT '受注行番号',
  `msyukkasijiKBN` tinyint(2) DEFAULT NULL COMMENT '明細出荷指示区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '受注数量',
  `sijisuryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '指示数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `nouki` date DEFAULT NULL COMMENT '納期',
  `syukka_flg` tinyint(1) DEFAULT NULL COMMENT '出荷フラグ',
  `syukkaKaikeiNendo` int(4) DEFAULT '0' COMMENT '出荷会計年度',
  `syukkaNO` int(6) DEFAULT '0' COMMENT '出荷番号',
  `syukka_gyouNO` int(3) DEFAULT '0' COMMENT '出荷行番号',
  `tokuisakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先名',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='出荷指示';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dsyukkasijilog`
--

DROP TABLE IF EXISTS `Dsyukkasijilog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dsyukkasijilog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '出荷指示番号',
  `gyouNO` int(3) DEFAULT NULL COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `syukkasijiKBN` int(3) DEFAULT NULL COMMENT '出荷指示区分',
  `syukkasijidate` date DEFAULT NULL COMMENT '出荷指示日',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `jutyuuKaikeiNendo` int(4) DEFAULT '0' COMMENT '受注会計年度',
  `jutyuuNO` int(6) DEFAULT NULL COMMENT '受注番号',
  `jutyuu_gyouNO` int(3) DEFAULT NULL COMMENT '受注行番号',
  `msyukkasijiKBN` tinyint(2) DEFAULT NULL COMMENT '明細出荷指示区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '受注数量',
  `sijisuryou` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '指示数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `nouki` date DEFAULT NULL COMMENT '納期',
  `syukka_flg` tinyint(1) DEFAULT NULL COMMENT '出荷フラグ',
  `syukkaKaikeiNendo` int(4) DEFAULT '0' COMMENT '出荷会計年度',
  `syukkaNO` int(6) DEFAULT '0' COMMENT '出荷番号',
  `syukka_gyouNO` int(3) DEFAULT '0' COMMENT '出荷行番号',
  `tokuisakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先名',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='出荷指示ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Duiageseigyo`
--

DROP TABLE IF EXISTS `Duiageseigyo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Duiageseigyo` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '受注番号',
  `syukkaseigyo` tinyint(1) DEFAULT '0' COMMENT '出荷制御区分',
  `yobiKBN1` tinyint(1) DEFAULT '0' COMMENT '予備区分1',
  `yobiKBN2` tinyint(1) DEFAULT '0' COMMENT '予備区分2',
  `yobiKBN3` tinyint(1) DEFAULT '0' COMMENT '予備区分3',
  `yobiKBN4` tinyint(1) DEFAULT '0' COMMENT '予備区分4',
  `yobiKBN5` tinyint(1) DEFAULT '0' COMMENT '予備区分5',
  `yobiSuuti1` int(6) DEFAULT '0' COMMENT '予備数値1',
  `yobiSuuti2` int(6) DEFAULT '0' COMMENT '予備数値2',
  `yobiSuuti3` int(6) DEFAULT '0' COMMENT '予備数値3',
  `yobiSuuti4` int(6) DEFAULT '0' COMMENT '予備数値4',
  `yobiSuuti5` int(6) DEFAULT '0' COMMENT '予備数値5',
  `yobiKingaku1` decimal(13,0) NOT NULL DEFAULT '0' COMMENT '予備金額1',
  `yobiKingaku2` decimal(13,0) NOT NULL DEFAULT '0' COMMENT '予備金額2',
  `yobiKingaku3` decimal(13,0) NOT NULL DEFAULT '0' COMMENT '予備金額3',
  `yobiKingaku4` decimal(13,0) NOT NULL DEFAULT '0' COMMENT '予備金額4',
  `yobiKingaku5` decimal(13,0) NOT NULL DEFAULT '0' COMMENT '予備金額5',
  `yobiKoumoku1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目1',
  `yobiKoumoku2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目2',
  `yobiKoumoku3` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目3',
  `yobiKoumoku4` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目4',
  `yobiKoumoku5` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目5',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='売上制御';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Duriage`
--

DROP TABLE IF EXISTS `Duriage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Duriage` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '売上番号',
  `gyouNO` int(3) NOT NULL DEFAULT '0' COMMENT '行番号',
  `seq` int(6) DEFAULT NULL COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `uriageKBN` int(3) DEFAULT NULL COMMENT '売上区分',
  `jutyuuKaikeiNendo` int(4) DEFAULT '0' COMMENT '受注会計年度',
  `jutyuuNO` int(6) DEFAULT NULL COMMENT '受注番号',
  `jutyuu_gyouNO` int(3) DEFAULT '0' COMMENT '受注行番号',
  `syukkaKaikeiNendo` int(4) DEFAULT '0' COMMENT '出荷会計年度',
  `syukkaNO` int(6) DEFAULT NULL COMMENT '出荷番号',
  `syukka_gyouNO` int(3) DEFAULT '0' COMMENT '出荷行番号',
  `uriagedate` date DEFAULT NULL COMMENT '売上日',
  `syukkadate` date DEFAULT NULL COMMENT '出荷日',
  `nouki` date DEFAULT NULL COMMENT '納期',
  `ankenKaikeiNendo` int(4) DEFAULT '0' COMMENT '案件受注会計年度',
  `ankenjutyuuNO` int(6) DEFAULT NULL COMMENT '案件受注番号',
  `tokuisakiCD` int(6) DEFAULT NULL COMMENT '得意先CD',
  `tokuisakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `nounyuusakiCD` int(6) DEFAULT NULL COMMENT '納入先CD',
  `nounyuusakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先名',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `nounyusaki_address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所1',
  `nounyusaki_address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所2',
  `nounyusaki_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先担当者名',
  `TtyuumonNo` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先注文番号',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `muriageKBN` tinyint(2) DEFAULT NULL COMMENT '明細売上区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL COMMENT '金額',
  `genka_tanka` decimal(8,0) NOT NULL COMMENT '原価単価',
  `genka_kingaku` decimal(10,0) NOT NULL COMMENT '原価金額',
  `arari` decimal(10,0) NOT NULL COMMENT '粗利',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL COMMENT '本体金額',
  `inji_syouhizei` decimal(10,0) NOT NULL COMMENT '消費税額(印字用)',
  `kaikei_syouhizei` decimal(10,0) NOT NULL COMMENT '消費税額(会計用)',
  `seikyuusyoBangou` int(6) DEFAULT NULL COMMENT '請求書番号',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `tyouhaKBN` tinyint(1) DEFAULT '0' COMMENT '帳端区分',
  `Krenkeidate` datetime DEFAULT NULL COMMENT '会計連携日時',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`,`gyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='売上';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Duriagelog`
--

DROP TABLE IF EXISTS `Duriagelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Duriagelog` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '売上番号',
  `gyouNO` int(3) DEFAULT NULL COMMENT '行番号',
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `uriageKBN` int(3) DEFAULT NULL COMMENT '売上区分',
  `jutyuuKaikeiNendo` int(4) DEFAULT '0' COMMENT '受注会計年度',
  `jutyuuNO` int(6) DEFAULT NULL COMMENT '受注番号',
  `jutyuu_gyouNO` int(3) DEFAULT '0' COMMENT '受注行番号',
  `syukkaKaikeiNendo` int(4) DEFAULT '0' COMMENT '出荷会計年度',
  `syukkaNO` int(6) DEFAULT NULL COMMENT '出荷番号',
  `syukka_gyouNO` int(3) DEFAULT '0' COMMENT '出荷行番号',
  `uriagedate` date DEFAULT NULL COMMENT '売上日',
  `syukkadate` date DEFAULT NULL COMMENT '出荷日',
  `nouki` date DEFAULT NULL COMMENT '納期',
  `ankenKaikeiNendo` int(4) DEFAULT '0' COMMENT '案件受注会計年度',
  `ankenjutyuuNO` int(6) DEFAULT NULL COMMENT '案件受注番号',
  `tokuisakiCD` int(6) DEFAULT NULL COMMENT '得意先CD',
  `tokuisakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `nounyuusakiCD` int(6) DEFAULT NULL COMMENT '納入先CD',
  `nounyuusakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先名',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `nounyusaki_address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所1',
  `nounyusaki_address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所2',
  `nounyusaki_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先担当者名',
  `TtyuumonNo` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先注文番号',
  `denpyou_tekiyou1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要1',
  `denpyou_tekiyou2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票摘要2',
  `muriageKBN` tinyint(2) DEFAULT NULL COMMENT '明細売上区分',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) NOT NULL COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) NOT NULL COMMENT '単価',
  `kingaku` decimal(10,0) NOT NULL COMMENT '金額',
  `genka_tanka` decimal(8,0) NOT NULL COMMENT '原価単価',
  `genka_kingaku` decimal(10,0) NOT NULL COMMENT '原価金額',
  `arari` decimal(10,0) NOT NULL COMMENT '粗利',
  `meisai_tekiyou` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明細摘要',
  `hontai_kingaku` decimal(10,0) NOT NULL COMMENT '本体金額',
  `inji_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(印字用)',
  `kaikei_syouhizei` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '消費税額(会計用)',
  `seikyuusyoBangou` int(6) DEFAULT NULL COMMENT '請求書番号',
  `DenpyouHakkou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '伝票発行済F',
  `tyouhaKBN` tinyint(1) DEFAULT '0' COMMENT '帳端区分',
  `Krenkeidate` datetime DEFAULT NULL COMMENT '会計連携日時',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=4058 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='売上ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Duriageseigyo`
--

DROP TABLE IF EXISTS `Duriageseigyo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Duriageseigyo` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '売上番号',
  `syukkaseigyo` tinyint(1) DEFAULT '0' COMMENT '出荷制御区分',
  `yobiKBN1` tinyint(1) DEFAULT '0' COMMENT '予備区分1',
  `yobiKBN2` tinyint(1) DEFAULT '0' COMMENT '予備区分2',
  `yobiKBN3` tinyint(1) DEFAULT '0' COMMENT '予備区分3',
  `yobiKBN4` tinyint(1) DEFAULT '0' COMMENT '予備区分4',
  `yobiKBN5` tinyint(1) DEFAULT '0' COMMENT '予備区分5',
  `yobiSuuti1` int(6) DEFAULT '0' COMMENT '予備数値1',
  `yobiSuuti2` int(6) DEFAULT '0' COMMENT '予備数値2',
  `yobiSuuti3` int(6) DEFAULT '0' COMMENT '予備数値3',
  `yobiSuuti4` int(6) DEFAULT '0' COMMENT '予備数値4',
  `yobiSuuti5` int(6) DEFAULT '0' COMMENT '予備数値1',
  `yobiKingaku1` decimal(13,3) DEFAULT '0.000' COMMENT '予備金額1',
  `yobiKingaku2` decimal(13,3) DEFAULT '0.000' COMMENT '予備金額2',
  `yobiKingaku3` decimal(13,3) DEFAULT '0.000' COMMENT '予備金額3',
  `yobiKingaku4` decimal(13,3) DEFAULT '0.000' COMMENT '予備金額4',
  `yobiKingaku5` decimal(13,3) DEFAULT '0.000' COMMENT '予備金額5',
  `yobiKoumoku1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目1',
  `yobiKoumoku2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目2',
  `yobiKoumoku3` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目3',
  `yobiKoumoku4` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目4',
  `yobiKoumoku5` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '予備項目5',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`kaikeiNendo`,`denpyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='売上制御';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Durikakezan`
--

DROP TABLE IF EXISTS `Durikakezan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Durikakezan` (
  `tokuisakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '得意先CD',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `keijoutukisuu` int(2) NOT NULL DEFAULT '0' COMMENT '計上月数',
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `zan` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '前月末残',
  `yosan` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '予算',
  `uriagegaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '売上額',
  `hennpinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '返品額',
  `nebikigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '値引額',
  `nyuukinngaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '入金額',
  `syouhizeigaku` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '消費税額',
  `genka` decimal(12,0) NOT NULL DEFAULT '0' COMMENT '原価',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '変更日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '変更オペレータCD',
  PRIMARY KEY (`tokuisakiCD`,`keijounengetu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='月別売掛残高';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dzaiko`
--

DROP TABLE IF EXISTS `Dzaiko`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dzaiko` (
  `soukoCD` int(6) NOT NULL DEFAULT '0' COMMENT '倉庫CD',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '商品CD',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `zengetumatu_zaikosu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '前月末在庫数',
  `tougetu_uriagesu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '当月売上数',
  `tougetu_syukkosu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '当月出庫数',
  `tougetu_sonotasyukkosu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '当月その他出庫',
  `tougetu_tanaorosigen` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '当月棚卸減',
  `tougetu_siiresu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '当月仕入数',
  `tougetu_nyuukosu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '当月入庫数',
  `tougetu_sonotanyuukosu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '当月その他入庫数',
  `tougetu_tanaorosizou` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '当月棚卸増',
  `yokugetu_uriagesu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '翌月売上数',
  `yokugetu_syukkosu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '翌月出庫数',
  `yokugetu_sonotasyukkosu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '翌月その他出庫',
  `yokugetu_tanaorosigen` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '翌月棚卸減',
  `yokugetu_siiresu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '翌月仕入数',
  `yokugetu_nyuukosu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '翌月入庫数',
  `yokugetu_sonotanyuukosu` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '翌月その他入庫数',
  `yokugetu_tanaorosizou` decimal(12,3) NOT NULL DEFAULT '0.000' COMMENT '翌月棚卸増',
  `tanka` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '在庫評価単価',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`soukoCD`,`syouhinCD`,`keijounengetu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='在庫';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MHojokamoku`
--

DROP TABLE IF EXISTS `MHojokamoku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MHojokamoku` (
  `kanjoukamokuCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '勘定科目コード',
  `hojokamokuCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '補助科目コード',
  `hojokamokuNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '補助科目名',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`kanjoukamokuCD`,`hojokamokuCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='補助科目マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MKanjoukamoku`
--

DROP TABLE IF EXISTS `MKanjoukamoku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MKanjoukamoku` (
  `kanjoukamokuCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '勘定科目コード',
  `kanjoukamokuNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '勘定科目名',
  `sotoutiKBN` tinyint(1) DEFAULT NULL COMMENT '外内税区分',
  `genyokinKBN` int(3) DEFAULT '0' COMMENT '現預金区分',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`kanjoukamokuCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='勘定科目マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MPrinterSetting`
--

DROP TABLE IF EXISTS `MPrinterSetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MPrinterSetting` (
  `programID` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'プログラムID',
  `printerSetting` text CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT '設定内容',
  PRIMARY KEY (`programID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSiiresakiStanka`
--

DROP TABLE IF EXISTS `MSiiresakiStanka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MSiiresakiStanka` (
  `siiresakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '仕入先CD',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '商品CD',
  `tekiyoudate` date NOT NULL DEFAULT '0000-00-00' COMMENT '改訂日',
  `tanka` decimal(10,0) DEFAULT '0' COMMENT '仕入単価',
  PRIMARY KEY (`siiresakiCD`,`syouhinCD`,`tekiyoudate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='仕入先別商品仕入単価マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSyouhinStanka`
--

DROP TABLE IF EXISTS `MSyouhinStanka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MSyouhinStanka` (
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '商品CD',
  `tekiyoudate` date NOT NULL DEFAULT '0000-00-00' COMMENT '改訂日',
  `tanka` decimal(10,0) DEFAULT '0' COMMENT '仕入単価',
  PRIMARY KEY (`syouhinCD`,`tekiyoudate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='商品仕入単価マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSyouhinUtanka`
--

DROP TABLE IF EXISTS `MSyouhinUtanka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MSyouhinUtanka` (
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '商品CD',
  `tekiyoudate` date NOT NULL DEFAULT '0000-00-00' COMMENT '改訂日',
  `tanka` decimal(10,0) DEFAULT '0' COMMENT '売上単価',
  PRIMARY KEY (`syouhinCD`,`tekiyoudate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='商品売上単価マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MTokuisakiUtanka`
--

DROP TABLE IF EXISTS `MTokuisakiUtanka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MTokuisakiUtanka` (
  `tokuisakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '得意先CD',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '商品CD',
  `tekiyoudate` date NOT NULL DEFAULT '0000-00-00' COMMENT '改訂日',
  `tanka` decimal(10,0) DEFAULT '0' COMMENT '売上単価',
  PRIMARY KEY (`tokuisakiCD`,`syouhinCD`,`tekiyoudate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='得意先別商品売上単価マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mdaibunrui`
--

DROP TABLE IF EXISTS `Mdaibunrui`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mdaibunrui` (
  `daibunruiCD` int(6) NOT NULL DEFAULT '0' COMMENT '商品大分類CD',
  `daibunruiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品大分類名',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`daibunruiCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='商品大分類マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mhinsyu`
--

DROP TABLE IF EXISTS `Mhinsyu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mhinsyu` (
  `hinsyuCD` int(6) NOT NULL DEFAULT '0' COMMENT '品種CD',
  `hinsyuNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '品種名',
  `hinsyuKNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '品種カナ名',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`hinsyuCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='品種マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mhkamokuctl`
--

DROP TABLE IF EXISTS `Mhkamokuctl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mhkamokuctl` (
  `dataKBN` int(3) NOT NULL DEFAULT '0' COMMENT 'データ区分',
  `torihikiKBN` int(3) NOT NULL DEFAULT '0' COMMENT '取引区分',
  `programKBN` int(3) NOT NULL DEFAULT '0' COMMENT '入力区分',
  `siwakeCD` int(6) NOT NULL DEFAULT '0' COMMENT '仕訳コード',
  `torihikisakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '取引先コード',
  `kkHojoCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方補助科目コード',
  `ksHojoCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方補助科目コード',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`dataKBN`,`torihikiKBN`,`programKBN`,`siwakeCD`,`torihikisakiCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='補助科目コントロールマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mjigyosyo`
--

DROP TABLE IF EXISTS `Mjigyosyo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mjigyosyo` (
  `jigyosyoCD` tinyint(2) NOT NULL DEFAULT '0' COMMENT '事業所CD',
  `jigyosyoNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '事業所名',
  `jigyosyoRNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '事業所略名',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所1',
  `address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所2',
  `tel` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号',
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'FAX番号',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`jigyosyoCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='事業所マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mkanri`
--

DROP TABLE IF EXISTS `Mkanri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mkanri` (
  `kanriCD` tinyint(1) NOT NULL DEFAULT '0' COMMENT '基本情報管理ＣＤ',
  `kaisyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '会社名',
  `kaisyaRNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '会社略名',
  `kaisyaKNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '会社カナ名',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '会社郵便番号',
  `address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '会社住所１',
  `address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '会社住所２',
  `tel` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '会社電話番号',
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '会社ＦＡＸ番号',
  `innjiyou_kaisyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '帳票印字用会社名',
  `kisyudate` date DEFAULT NULL COMMENT '期首年月日',
  `kisyu_yyyymm` int(6) DEFAULT NULL COMMENT '期首年月',
  `kaikei_nendo` int(4) DEFAULT NULL COMMENT '会計年度',
  `kaikei_year` int(4) DEFAULT NULL COMMENT '会計年',
  `kaikei_yyyymm` int(6) DEFAULT NULL COMMENT '会計年月',
  `keikatu_kisuu` tinyint(2) DEFAULT NULL COMMENT '経過月数',
  `kessan_kisu` int(3) DEFAULT NULL COMMENT '決算期数',
  `seirekiwarekiKBN` tinyint(1) DEFAULT NULL COMMENT '西和暦区分',
  `hozontukisuu1` int(3) DEFAULT NULL COMMENT '売上入金データ保存月数',
  `hozontukisuu2` int(3) DEFAULT NULL COMMENT '売上集計データ保存月数',
  `hozontukisuu3` int(3) DEFAULT NULL COMMENT '売上消込データ保存月数',
  `hozontukisuu4` int(3) DEFAULT NULL COMMENT '仕入支払データ保存月数',
  `hozontukisuu5` int(3) DEFAULT NULL COMMENT '仕入集計データ保存月数',
  `hozontukisuu6` int(3) DEFAULT NULL COMMENT '支払消込データ保存月数',
  `hozontukisuu7` int(3) DEFAULT NULL COMMENT '在庫データ保存月数',
  `hozontukisuu8` int(3) DEFAULT NULL COMMENT '受発注データ保存月数',
  `seikyuu_kariFLG` tinyint(1) DEFAULT NULL COMMENT '請求仮処理フラグ',
  `siharai_kariFLG` tinyint(1) DEFAULT NULL COMMENT '支払仮処理フラグ',
  `getuji_kariFLG` tinyint(1) DEFAULT NULL COMMENT '月次仮処理フラグ',
  `zSiwakeCD` int(6) DEFAULT '0' COMMENT '材料費仕訳CD',
  `rSiwakeCD` int(6) DEFAULT '0' COMMENT '労務費仕訳CD',
  `gSiwakeCD` int(6) DEFAULT '0' COMMENT '外注費仕訳CD',
  `kSiwakeCD` int(6) DEFAULT '0' COMMENT '経費仕訳CD',
  PRIMARY KEY (`kanriCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='基本情報管理マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mkkamokuctl`
--

DROP TABLE IF EXISTS `Mkkamokuctl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mkkamokuctl` (
  `dataKBN` int(3) NOT NULL DEFAULT '0' COMMENT 'データ区分',
  `torihikiKBN` int(3) NOT NULL DEFAULT '0' COMMENT '取引区分',
  `programKBN` int(3) NOT NULL DEFAULT '0' COMMENT '入力区分',
  `siwakeCD` int(6) NOT NULL DEFAULT '0' COMMENT '仕訳コード',
  `kkKamokuCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '借方勘定科目コード',
  `ksKamokuCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '貸方勘定科目コード',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`dataKBN`,`torihikiKBN`,`programKBN`,`siwakeCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='勘定科目コントロールマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mkouza`
--

DROP TABLE IF EXISTS `Mkouza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mkouza` (
  `kouzaCD` int(6) NOT NULL DEFAULT '0' COMMENT '口座コード',
  `kouzaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '口座名',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`kouzaCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='口座マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mmaker`
--

DROP TABLE IF EXISTS `Mmaker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mmaker` (
  `makerCD` int(6) NOT NULL DEFAULT '0' COMMENT 'メーカーCD',
  `makerNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'メーカー名',
  `makerRNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'メーカー略名',
  `makerKNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'メーカーカナ名',
  `keisyo` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '敬称',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所1',
  `address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所2',
  `tel1` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号1',
  `naisen1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '内線番号1',
  `tel2` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号2',
  `naisen2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '内線番号2',
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'FAX番号',
  `maker_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'メーカー担当者名',
  `maker_tantousyabusyoNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'メーカー担当者部署名',
  `maker_tantousyayakusyokuNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'メーカー担当者役職名',
  `daihyousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '代表者名',
  `daihyousyayakusyokuNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '代表者役職',
  `tantosyaCD` int(6) NOT NULL DEFAULT '0' COMMENT '担当者CD',
  `totalization1` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD1',
  `totalization2` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD2',
  `totalization3` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD3',
  `totalization4` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD4',
  `totalization5` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD5',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`makerCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='メーカーマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mnounyusaki`
--

DROP TABLE IF EXISTS `Mnounyusaki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mnounyusaki` (
  `nounyusakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '納入先CD',
  `nounyusakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先名',
  `nounyusakiRNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先略名',
  `nounyusakiKNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先カナ名',
  `syokutiKBN` tinyint(1) DEFAULT NULL COMMENT '諸口区分',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所1',
  `address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所2',
  `tel1` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号1',
  `naisen1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '内線番号1',
  `tel2` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号2',
  `naisen2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '内線番号2',
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'FAX番号',
  `nounyusaki_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先担当者名',
  `nounyusaki_tantousyabusyoNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先担当者部署名',
  `nounyusaki_tantousyayakusyokuNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先担当者役職名',
  `totalization1` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD1',
  `totalization2` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD2',
  `totalization3` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD3',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`nounyusakiCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='納入先 マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mset`
--

DROP TABLE IF EXISTS `Mset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mset` (
  `oyaSyouhinCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '親商品コード',
  `koSyouhinCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '子商品コード',
  `kouseiSu` decimal(10,3) DEFAULT '0.000' COMMENT '構成数',
  PRIMARY KEY (`oyaSyouhinCD`,`koSyouhinCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='セット品マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Msiiresaki`
--

DROP TABLE IF EXISTS `Msiiresaki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Msiiresaki` (
  `siiresakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '仕入先CD',
  `siiresakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先名',
  `siiresakiRNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先略名',
  `siiresakiKNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先カナ名',
  `syokutiKBN` tinyint(1) DEFAULT NULL COMMENT '諸口区分',
  `keisyo` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '敬称',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所1',
  `address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所2',
  `tel1` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号1',
  `naisen1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '内線番号1',
  `tel2` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号2',
  `naisen2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '内線番号2',
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'FAX番号',
  `siiresaki_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先担当者名',
  `siiresaki_tantousyabusyoNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先担当者部署名',
  `siiresaki_tantousyayakusyokuNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先担当者役職名',
  `daihyousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '代表者名',
  `daihyousyayakusyokuNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '代表者役職',
  `siharaisakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '支払先CD',
  `simebi1` tinyint(2) DEFAULT '0' COMMENT '締日1',
  `simebi2` tinyint(2) DEFAULT '0' COMMENT '締日2',
  `simebi3` tinyint(2) DEFAULT '0' COMMENT '締日3',
  `kijun_kingaku` decimal(12,0) DEFAULT '0' COMMENT '基準額',
  `siharai_mm1` tinyint(2) DEFAULT '0' COMMENT '支払月1',
  `siharai_dd1` tinyint(2) DEFAULT '0' COMMENT '支払日1',
  `siharai_mm2` tinyint(2) DEFAULT '0' COMMENT '支払月2',
  `siharai_dd2` tinyint(2) DEFAULT '0' COMMENT '支払日2',
  `siharaisyubetu1` tinyint(2) DEFAULT '0' COMMENT '支払種別1',
  `siharaisyubetu2` tinyint(2) DEFAULT '0' COMMENT '支払種別2',
  `tantosyaCD` int(6) DEFAULT '0' COMMENT '担当者CD',
  `jigyosyoCD` tinyint(2) DEFAULT NULL COMMENT '事業所CD',
  `totalization1` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD1',
  `totalization2` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD2',
  `totalization3` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD3',
  `totalization4` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD4',
  `totalization5` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD5',
  `hasuuKBN` tinyint(1) DEFAULT NULL COMMENT '端数区分',
  `zeisansyutuKBN` tinyint(1) DEFAULT NULL COMMENT '消費税算出区分',
  `zeihasuuKBN` tinyint(1) DEFAULT NULL COMMENT '消費税端数区分',
  `siharaiannaiKBN` tinyint(1) DEFAULT NULL COMMENT '支払案内書不要区分',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`siiresakiCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='仕入先マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Msouko`
--

DROP TABLE IF EXISTS `Msouko`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Msouko` (
  `soukoCD` int(6) NOT NULL DEFAULT '0' COMMENT '倉庫ＣＤ',
  `soukoNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '倉庫名',
  `soukoRNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '倉庫略名',
  `soukoKNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '倉庫カナ名',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所１',
  `address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所２',
  `tel1` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号１',
  `tel2` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号２',
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ＦＡＸ番号',
  `soukoKBN` tinyint(1) DEFAULT NULL COMMENT '倉庫区分',
  `jigyosyoCD` tinyint(2) DEFAULT NULL COMMENT '事業所ＣＤ',
  `jisyaKBN` tinyint(1) DEFAULT NULL COMMENT '自社区分',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`soukoCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='倉庫マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Msyouhin`
--

DROP TABLE IF EXISTS `Msyouhin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Msyouhin` (
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `syouhinRNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品カナ名',
  `kikaku` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '規格',
  `kataban` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '型番',
  `serialNO` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'シリアルNO',
  `lotNO` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ロットNO',
  `syokutiKBN` tinyint(1) DEFAULT NULL COMMENT '諸口区分',
  `hinsyuCD` int(6) DEFAULT NULL COMMENT '品種CD',
  `daibunruiCD` int(6) DEFAULT NULL COMMENT '商品大分類CD',
  `tyuubunruiCD` int(6) DEFAULT NULL COMMENT '商品中分類CD',
  `makerCD` int(6) DEFAULT NULL COMMENT 'メーカーCD',
  `siiresakiCD` int(6) DEFAULT NULL COMMENT '主要仕入先CD',
  `totalization1` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD1',
  `totalization2` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD2',
  `totalization3` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD3',
  `totalization4` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD4',
  `totalization5` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD5',
  `taniCD` tinyint(2) DEFAULT NULL COMMENT '単位CD',
  `pictbarCD` blob COMMENT 'バーコード画像',
  `janCD` varchar(13) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'JANCD',
  `barCD1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'バーCD1',
  `barCD2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'バーCD2',
  `barCD3` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'バーCD3',
  `iriSUU` decimal(10,3) DEFAULT NULL COMMENT '入数',
  `zaikokanriKBN` tinyint(1) DEFAULT NULL COMMENT '在庫管理区分',
  `sethinKBN` tinyint(1) DEFAULT NULL COMMENT 'セット品区分',
  `sotoutiKBN` tinyint(1) DEFAULT NULL COMMENT '外内税区分',
  `hyoujunzaikoTNK` decimal(10,0) DEFAULT NULL COMMENT '標準在庫評価単価',
  `zeisyohinKBN` tinyint(1) DEFAULT NULL COMMENT '消費税商品区分',
  `zeirituKBN` tinyint(1) DEFAULT '0' COMMENT '消費税率区分',
  `juryou` decimal(11,4) DEFAULT NULL COMMENT '商品重量',
  `size` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品サイズ',
  `soukoCD` int(6) DEFAULT NULL COMMENT '主要倉庫CD',
  `picturePASS` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '画像ファイル登録パス',
  `yukoudate` date DEFAULT NULL COMMENT '有効期限',
  `siwakeCD` int(6) DEFAULT '0' COMMENT '仕訳CD',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`syouhinCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='商品マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mtani`
--

DROP TABLE IF EXISTS `Mtani`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mtani` (
  `taniCD` tinyint(2) NOT NULL DEFAULT '0' COMMENT '単位CD',
  `taniNM` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '単位名',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`taniCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='単位マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mtantosya`
--

DROP TABLE IF EXISTS `Mtantosya`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mtantosya` (
  `tantosyaCD` int(6) NOT NULL DEFAULT '0' COMMENT '担当者CD',
  `tantosyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '担当者名',
  `jigyosyoCD` tinyint(2) DEFAULT NULL COMMENT '事業所CD',
  `bumonCD` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '部門CD',
  `mobilePhone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '携帯電話番号',
  `totalization1` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD1',
  `totalization2` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD2',
  `totalization3` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD3',
  `totalization4` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD4',
  `totalization5` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD5',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`tantosyaCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='担当者マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mtokuisaki`
--

DROP TABLE IF EXISTS `Mtokuisaki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mtokuisaki` (
  `tokuisakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '得意先CD',
  `tokuisakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先名',
  `tokuisakiRNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先略名',
  `tokuisakiKNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先カナ名',
  `syokutiKBN` tinyint(1) DEFAULT NULL COMMENT '諸口区分',
  `keisyo` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '敬称',
  `postalCD` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '郵便番号',
  `address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所1',
  `address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所2',
  `tel1` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号1',
  `naisen1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '内線番号1',
  `tel2` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号2',
  `naisen2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '内線番号2',
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'FAX番号',
  `tokuisaki_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先担当者名',
  `tokuisaki_tantousyabusyoNM` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先担当者部署名',
  `tokuisaki_tantousyayakusyokuNM` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先担当者役職名',
  `daihyousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '代表者名',
  `daihyousyayakusyokuNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '代表者役職',
  `seikyuusakiCD` int(6) NOT NULL DEFAULT '0' COMMENT '請求先CD',
  `simebi1` tinyint(2) DEFAULT '0' COMMENT '締日1',
  `simebi2` tinyint(2) DEFAULT '0' COMMENT '締日2',
  `simebi3` tinyint(2) DEFAULT '0' COMMENT '締日3',
  `kijun_kingaku` decimal(12,0) DEFAULT NULL COMMENT '基準額',
  `kaisyuu_mm1` tinyint(2) DEFAULT '0' COMMENT '回収月1',
  `kaisyuu_dd1` tinyint(2) DEFAULT '0' COMMENT '回収日1',
  `kaisyuu_mm2` tinyint(2) DEFAULT '0' COMMENT '回収月2',
  `kaisyuu_dd2` tinyint(2) DEFAULT '0' COMMENT '回収日2',
  `nyuukinnsyubetu1` tinyint(2) DEFAULT '0' COMMENT '入金種別1',
  `nyuukinnsyubetu2` tinyint(2) DEFAULT '0' COMMENT '入金種別2',
  `tantousyaCD` int(6) DEFAULT '0' COMMENT '担当者CD',
  `jigyosyoCD` tinyint(2) DEFAULT NULL COMMENT '事業所CD',
  `totalization1` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD1',
  `totalization2` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD2',
  `totalization3` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD3',
  `totalization4` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD4',
  `totalization5` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '集計CD5',
  `yosingendogaku` decimal(12,0) DEFAULT NULL COMMENT '与信限度額',
  `jutyuukakuninsyoKBN` tinyint(1) DEFAULT NULL COMMENT '受注確認書発行有無区分',
  `dmKBN` tinyint(1) DEFAULT NULL COMMENT 'DM発行有無区分',
  `nouhinsoyKBN` tinyint(1) DEFAULT NULL COMMENT '納品書発行有無区分',
  `hasuuKBN` tinyint(1) DEFAULT NULL COMMENT '端数区分',
  `zeisansyutuKBN` tinyint(1) DEFAULT NULL COMMENT '消費税算出区分',
  `zeihasuuKBN` tinyint(1) DEFAULT NULL COMMENT '消費税端数区分',
  `seikyuusyoKBN` tinyint(1) DEFAULT NULL COMMENT '請求書不要区分',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`tokuisakiCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='得意先マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mtyubunrui`
--

DROP TABLE IF EXISTS `Mtyubunrui`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mtyubunrui` (
  `daibunruiCD` int(6) NOT NULL DEFAULT '0' COMMENT '商品大分類CD',
  `tyuubunruiCD` int(6) NOT NULL DEFAULT '0' COMMENT '商品中分類CD',
  `tyuubunruiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品中分類名',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  `updatedate` datetime DEFAULT NULL COMMENT '更新日時',
  `updateTantosya` int(6) DEFAULT NULL COMMENT '更新オペレータCD',
  PRIMARY KEY (`daibunruiCD`,`tyuubunruiCD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='商品中分類マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SSiiresakiMototyou`
--

DROP TABLE IF EXISTS `SSiiresakiMototyou`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SSiiresakiMototyou` (
  `No` bigint(20) NOT NULL DEFAULT '0',
  `siiresakiCD` int(11) DEFAULT NULL,
  `siiresakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ZENZAN` decimal(12,0) NOT NULL DEFAULT '0',
  `siiregaku` decimal(12,0) NOT NULL DEFAULT '0',
  `hennpinngaku` decimal(12,0) NOT NULL DEFAULT '0',
  `nebikigaku` decimal(12,0) NOT NULL DEFAULT '0',
  `siharaigaku` decimal(12,0) NOT NULL DEFAULT '0',
  `syouhizei` decimal(12,0) NOT NULL DEFAULT '0',
  `jikaikurikosigaku` decimal(17,0) NOT NULL DEFAULT '0',
  `denpyouDate` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `denpyouNo` varchar(18) CHARACTER SET utf8 DEFAULT NULL,
  `gyouNO` int(11) DEFAULT NULL,
  `seq` int(11) NOT NULL DEFAULT '0',
  `torihikiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suryou` decimal(18,3) NOT NULL DEFAULT '0.000',
  `taniCD` bigint(20) DEFAULT NULL,
  `taniNM` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tanka` decimal(19,0) NOT NULL DEFAULT '0',
  `kingaku` decimal(19,0) NOT NULL DEFAULT '0',
  `hontai_kingaku` decimal(19,0) NOT NULL DEFAULT '0',
  `kaikei_syouhizei` decimal(19,0) NOT NULL DEFAULT '0',
  `msiharaigaku` decimal(10,0) NOT NULL DEFAULT '0',
  `zandaka` bigint(20) NOT NULL DEFAULT '0',
  `zero` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SZaikoWare`
--

DROP TABLE IF EXISTS `SZaikoWare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SZaikoWare` (
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `soukoNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '倉庫名',
  `pnouki` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `pjutyuudate` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `pjutyuuNo` varchar(18) CHARACTER SET utf8 DEFAULT NULL,
  `jutyuuSuu` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `taniNM` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '単位名',
  `syukkaZumiSuu` decimal(32,3) NOT NULL DEFAULT '0.000',
  `miSyukkaZanSuu` decimal(33,3) NOT NULL DEFAULT '0.000',
  `genzaiZaiko` decimal(28,3) NOT NULL DEFAULT '0.000',
  `jutyuuKei` decimal(32,3) DEFAULT NULL,
  `syukkaZumiKei` decimal(54,3) DEFAULT NULL,
  `miSyukkaZanKei` decimal(55,3) DEFAULT NULL,
  `hojuuSuu` decimal(56,3) DEFAULT NULL,
  `zero` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SZaikoWareNeta`
--

DROP TABLE IF EXISTS `SZaikoWareNeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SZaikoWareNeta` (
  `jutyuudate` date DEFAULT NULL COMMENT '受注日',
  `nouki` date DEFAULT NULL COMMENT '納期',
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '受注番号',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `soukoNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '倉庫名',
  `jutyuuSuu` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `taniNM` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '単位名',
  `syukkaZumiSuu` decimal(32,3) NOT NULL DEFAULT '0.000',
  `miSyukkaZanSuu` decimal(33,3) NOT NULL DEFAULT '0.000',
  `genzaiZaiko` decimal(28,3) NOT NULL DEFAULT '0.000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SdenpyouHaita`
--

DROP TABLE IF EXISTS `SdenpyouHaita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SdenpyouHaita` (
  `dataKBN` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'データ区分',
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(6) NOT NULL DEFAULT '0' COMMENT '伝票番号',
  `programID` varchar(128) COLLATE utf8_unicode_ci NOT NULL COMMENT 'プログラム名',
  `tantosyaCD` int(6) NOT NULL DEFAULT '0' COMMENT '担当者CD',
  `insertDate` datetime NOT NULL COMMENT '追加日時',
  PRIMARY KEY (`dataKBN`,`kaikeiNendo`,`denpyouNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='伝票番号排他テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Sdenpyouno`
--

DROP TABLE IF EXISTS `Sdenpyouno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sdenpyouno` (
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `dataKBN` int(3) NOT NULL DEFAULT '0' COMMENT 'データ区分',
  `denpyouNO` int(6) DEFAULT NULL COMMENT '伝票番号',
  PRIMARY KEY (`kaikeiNendo`,`dataKBN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='伝票番号管理マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Sjikkoujoutai`
--

DROP TABLE IF EXISTS `Sjikkoujoutai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sjikkoujoutai` (
  `seq` int(5) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `programID` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'プログラム名',
  `tanmatuID` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '端末ID',
  `insertDate` datetime DEFAULT NULL COMMENT '追加日時',
  `updateDate` datetime DEFAULT NULL COMMENT '変更日時',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='実行状態制御マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Storihiki`
--

DROP TABLE IF EXISTS `Storihiki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storihiki` (
  `dataKBN` int(3) NOT NULL DEFAULT '0' COMMENT 'データ区分',
  `torihikiKBN` int(3) NOT NULL DEFAULT '0' COMMENT 'ユーザー取引区分',
  `systemKBN` int(3) DEFAULT '0' COMMENT 'システム取引区分',
  `torihikiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '取引区分名',
  `karikataCD` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '借方コード',
  `kasikataCD` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '貸方コード',
  `dspUMU` tinyint(1) DEFAULT '0' COMMENT '表示有無区分',
  `displyOrder` int(3) DEFAULT '0' COMMENT '表示順',
  PRIMARY KEY (`dataKBN`,`torihikiKBN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='取引区分マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Szei`
--

DROP TABLE IF EXISTS `Szei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Szei` (
  `zeirituKBN` tinyint(1) NOT NULL DEFAULT '0' COMMENT '消費税率区分',
  `tekiyoudate` date NOT NULL DEFAULT '0000-00-00' COMMENT '新税率適用日',
  `oldzeiritu` decimal(4,3) DEFAULT NULL COMMENT '旧消費税率',
  `newzeiritu` decimal(4,3) DEFAULT NULL COMMENT '新消費税率',
  PRIMARY KEY (`zeirituKBN`,`tekiyoudate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='消費税率管理マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `YokuDnyuusyukko`
--

DROP TABLE IF EXISTS `YokuDnyuusyukko`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `YokuDnyuusyukko` (
  `seq` int(6) NOT NULL AUTO_INCREMENT COMMENT 'SEQ',
  `kaikeiNendo` int(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
  `denpyouNO` int(11) DEFAULT NULL COMMENT '伝票番号',
  `gyouNO` int(11) DEFAULT NULL COMMENT '行番号',
  `akakuro` tinyint(1) DEFAULT NULL COMMENT '赤黒区分',
  `yuukou` tinyint(1) DEFAULT NULL COMMENT '有効区分',
  `keijounengetu` int(6) NOT NULL DEFAULT '0' COMMENT '計上年月',
  `dataKBN` int(3) DEFAULT NULL COMMENT 'データ区分',
  `torihikiKBN` int(3) DEFAULT NULL COMMENT '取引区分',
  `systemKBN` int(3) DEFAULT NULL COMMENT 'システム区分',
  `nyuusyukkodate` date DEFAULT NULL COMMENT '入出庫日',
  `soukoCD` int(6) DEFAULT NULL COMMENT '倉庫CD',
  `syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
  `syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
  `suryou` decimal(10,3) DEFAULT '0.000' COMMENT '数量',
  `taniCD` tinyint(2) DEFAULT '0' COMMENT '単位CD',
  `tanka` decimal(8,0) DEFAULT '0' COMMENT '単価',
  `kingaku` decimal(10,0) DEFAULT '0' COMMENT '金額',
  `hontai_kingaku` decimal(10,0) DEFAULT '0' COMMENT '本体金額',
  `syouhizei` decimal(10,0) DEFAULT '0' COMMENT '消費税額',
  `insertdate` datetime DEFAULT NULL COMMENT '登録日時',
  `insertTantosya` int(6) DEFAULT NULL COMMENT '登録オペレータCD',
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=6166 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='入出庫';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dump`
--

DROP TABLE IF EXISTS `dump`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dump` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8,
  `value` text CHARACTER SET utf8,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4909 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webUriage`
--

DROP TABLE IF EXISTS `webUriage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webUriage` (
  `ID` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'ID',
  `TyuumonNo` varchar(10) CHARACTER SET sjis DEFAULT '' COMMENT '注文番号',
  `TyuumonDate` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '注文日',
  `kaiinnNo` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '会員番号',
  `tokuisakiNM` varchar(40) CHARACTER SET sjis DEFAULT '' COMMENT '氏名',
  `haisouHouhou` varchar(40) CHARACTER SET sjis DEFAULT '' COMMENT '配送方法',
  `haisouDate` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '配送日',
  `souhinCD` varchar(40) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '商品CD',
  `skuCD` varchar(40) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'SKU CD',
  `souhinNM` varchar(40) CHARACTER SET sjis DEFAULT '' COMMENT '商品名',
  `skuNM` varchar(40) CHARACTER SET sjis DEFAULT '' COMMENT 'SKU表示名',
  `syouhinOpt` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '商品オプション',
  `suuryou` decimal(10,3) DEFAULT '0.000' COMMENT '数量',
  `tanka` decimal(8,0) DEFAULT '0' COMMENT '単価',
  `tani` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '単位'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-03-05 15:37:19
