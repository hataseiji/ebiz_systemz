DROP PROCEDURE IF EXISTS seikyuuMaeShori_01_delete_DseikyuuHead;
DELIMITER //
CREATE PROCEDURE seikyuuMaeShori_01_delete_DseikyuuHead(
    IN  _i_seikyuusakiFrom   integer(6), -- 2014/02/07
    IN  _i_seikyuusakiTo     integer(6), -- 2014/02/07
    IN _i_seikyuusakiCD1     integer(6),
    IN _i_seikyuusakiCD2     integer(6),
    IN _i_seikyuusakiCD3     integer(6),
    IN _i_seikyuusakiCD4     integer(6),
    IN _i_seikyuusakiCD5     integer(6),
    IN _i_seikyuusakiCD6     integer(6),
    IN _i_seikyuusakiCD7     integer(6),
    IN _i_seikyuusakiCD8     integer(6),
    IN _i_seikyuusakiCD9     integer(6),
    IN _i_seikyuusakiCD10    integer(6),
    IN _i_seikyuunengetu     integer(6),
    IN _i_seikyuuDateFrom    date,
    IN _i_seikyuuDateTo      date,
    IN _i_simeBi             tinyint,
    IN _i_insertdate         date,
    IN _i_insertTantosya     integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    /* =============================================================================
       請求ヘッダ削除
       今回作成する請求ヘッダだが、過去に請求前処理のみされていて今回再度前処理をかけるものを削除
     =============================================================================== */
    DECLARE _kaikei_nendo integer(4)  DEFAULT 0;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    select kaikei_nendo into _kaikei_nendo from Mkanri where kanriCD = 1;

    delete from DseikyuuHead
    where kaikeiNendo = _kaikei_nendo
    and   seikyuunengetu = _i_seikyuunengetu
    and   simebi = _i_simeBi
    and
    (
        (
                _i_seikyuusakiCD1 = 0 and _i_seikyuusakiCD2 = 0
            and _i_seikyuusakiCD3 = 0 and _i_seikyuusakiCD4 = 0
            and _i_seikyuusakiCD5 = 0 and _i_seikyuusakiCD6 = 0
            and _i_seikyuusakiCD7 = 0 and _i_seikyuusakiCD8 = 0
            and _i_seikyuusakiCD9 = 0 and _i_seikyuusakiCD10 = 0
        )
        or
        (
        seikyuusakiCD in (_i_seikyuusakiCD1,_i_seikyuusakiCD2,_i_seikyuusakiCD3,
                                _i_seikyuusakiCD4,_i_seikyuusakiCD5,_i_seikyuusakiCD6,
                                _i_seikyuusakiCD7,_i_seikyuusakiCD8,_i_seikyuusakiCD9,
                                _i_seikyuusakiCD10)
        )
    )
    and (_i_seikyuusakiFrom = 0 or seikyuusakiCD >= _i_seikyuusakiFrom) -- 2014/02/07
    and (_i_seikyuusakiTo = 0   or seikyuusakiCD <= _i_seikyuusakiTo)   -- 2014/02/07
    and   seikyuukakuteidate IS NULL; -- 請求確定が終わってないもの

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
