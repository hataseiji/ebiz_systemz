drop trigger IF EXISTS tri_ins_Dsyukkasiji;
delimiter ;;
CREATE TRIGGER `tri_ins_Dsyukkasiji` AFTER INSERT ON `Dsyukkasiji` FOR EACH ROW BEGIN
    INSERT INTO Dsyukkasijilog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        syukkasijiKBN,
        syukkasijidate,
        soukoCD,
        jutyuuKaikeiNendo,
        jutyuuNO,
        jutyuu_gyouNO,
        msyukkasijiKBN,
        syouhinCD,
        syouhinNM,
        suryou,
        sijisuryou,
        taniCD,
        nouki,
        syukka_flg,
        syukkaKaikeiNendo,
        syukkaNO,
        syukka_gyouNO,
        tokuisakiNM,
        insertdate,
        insertTantosya
    )
    values
    (
        NEW.kaikeiNendo,
        NEW.denpyouNO,
        NEW.gyouNO,
        0,
        0,

        cal_KeijouDate(NEW.syukkasijidate),
        NEW.dataKBN,
        NEW.torihikiKBN,
        NEW.syukkasijiKBN,
        NEW.syukkasijidate,
        NEW.soukoCD,
        NEW.jutyuuKaikeiNendo,
        NEW.jutyuuNO,
        NEW.jutyuu_gyouNO,
        NEW.msyukkasijiKBN,
        NEW.syouhinCD,
        NEW.syouhinNM,
        NEW.suryou,
        NEW.sijisuryou * -1,
        NEW.taniCD,
        NEW.nouki,
        NEW.syukka_flg,
        NEW.syukkaKaikeiNendo,
        NEW.syukkaNO,
        NEW.syukka_gyouNO,
        NEW.tokuisakiNM,
        NEW.insertdate,
        NEW.insertTantosya
    );
END;
 ;;
delimiter ;
