drop trigger IF EXISTS tri_ins_Dsiharai;
delimiter ;;
CREATE TRIGGER `tri_ins_Dsiharai` AFTER INSERT ON `Dsiharai` FOR EACH ROW BEGIN
    /* 黒処理 */
    INSERT INTO Dsiharailog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        siharaiKBN,
        siharaidate,
        siharaisakiCD,
        denpyou_tekiyou1,
        denpyou_tekiyou2,
        msiharaiKBN,
        kingaku,
        meisai_tekiyou,
        hontai_kingaku,
        syouhizei,
        siharaisyoBangou,
        DenpyouHakkou,
        ginkouNM,
        sitenNM,
        tegatadate,
        tegataNO,
        furidasiNM,
        Krenkeidate,  -- 2013/10/13
        insertdate,
        insertTantosya
    )
    values
    (
        NEW.kaikeiNendo,
        NEW.denpyouNO,
        NEW.gyouNO,
        0, /* 黒 */
        0, /* 有効 */
        cal_KeijouDate(NEW.siharaidate),
        NEW.dataKBN,
        NEW.torihikiKBN,
        NEW.siharaiKBN,
        NEW.siharaidate,
        NEW.siharaisakiCD,
        NEW.denpyou_tekiyou1,
        NEW.denpyou_tekiyou2,
        NEW.msiharaiKBN,
        NEW.kingaku,
        NEW.meisai_tekiyou,
        NEW.hontai_kingaku,
        NEW.siharaisyoBangou,
        NEW.syouhizei,
        NEW.DenpyouHakkou,
        NEW.ginkouNM,
        NEW.sitenNM,
        NEW.tegatadate,
        NEW.tegataNO,
        NEW.furidasiNM,
        NEW.Krenkeidate,  -- 2013/10/13
        CURRENT_TIMESTAMP(),
        NEW.insertTantosya
    );
END;
 ;;
delimiter ;
