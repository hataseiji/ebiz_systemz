drop trigger IF EXISTS tri_NyuukinToUrikake;
delimiter ;;
CREATE TRIGGER `tri_NyuukinToUrikake` AFTER INSERT ON `Dnyuukinlog` FOR EACH ROW BEGIN
    DECLARE _int_counter        integer;       /* insert可否 (明細の有無) */
    DECLARE _keijoutukisuu      tinyint(2);    /* 計上月数 (期首年月からの経過月数) */
    DECLARE _kisyu_yyyymm       integer(6);    /* 期首年月 */
    DECLARE _kaikei_nendo       integer(4);    /* 会計年度 */

    /* 管理マスタ.期首年月取得 */
    select kisyu_yyyymm, kaikei_nendo into _kisyu_yyyymm, _kaikei_nendo from Mkanri where kanriCD=1;

    /* 計上月数算出 */
    SET _keijoutukisuu = NEW.keijounengetu - _kisyu_yyyymm;
    if _keijoutukisuu >= 97 then
        SET _keijoutukisuu = _keijoutukisuu - 88;
    end if;

    /* 得意先別月別売掛ファイル更新 */
    select count(*) INTO _int_counter from Durikakezan DUZN where DUZN.tokuisakiCD = NEW.seikyuusakiCD and DUZN.keijounengetu = NEW.keijounengetu;
    if _int_counter = 0 then

        INSERT INTO Durikakezan
        (
            tokuisakiCD,
            keijounengetu,
            keijoutukisuu,
            kaikeinendo,
            yosan,
            zan,
            uriagegaku,
            hennpinngaku,
            nebikigaku,
            nyuukinngaku,
            syouhizeigaku,
            insertdate,
            insertTantosya,
            updatedate,
            updateTantosya
        )
        values
        (
            NEW.seikyuusakiCD,
            NEW.keijounengetu,
            _keijoutukisuu,
            _kaikei_nendo,
            0,
            0,
            0,
            0,
            0,
            NEW.kingaku,
            0,
            NEW.insertdate,
            NEW.insertTantosya,
            NEW.insertdate,
            NEW.insertTantosya
        );
    else
        update Durikakezan set
            keijoutukisuu  = _keijoutukisuu,
            kaikeinendo    = _kaikei_nendo,
            nyuukinngaku   = nyuukinngaku  + NEW.kingaku,
            updatedate    = NEW.insertdate,
            updateTantosya = NEW.insertTantosya
        where
                tokuisakiCD    = NEW.seikyuusakiCD
            and keijounengetu  = NEW.keijounengetu;
    end if;
END;
 ;;
delimiter ;
