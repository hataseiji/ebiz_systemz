drop trigger IF EXISTS tri_ins_Dnyuusyukko_fromS;
delimiter ;;
CREATE TRIGGER `tri_ins_Dnyuusyukko_fromS` AFTER INSERT ON `Dsyukkalog` FOR EACH ROW BEGIN

    DECLARE done                       INT DEFAULT 0;
    DECLARE _oyaSyouhinCD              varchar(10);
    DECLARE _koSyouhinCD               varchar(10);
    DECLARE _kouseiSu                  decimal(10,3);
    DECLARE _suryou                    decimal(10,3);
    DECLARE _taniCD                    tinyint;
    DECLARE _soukoCD                   integer(6);
    DECLARE _setKBN                    tinyint;

    DECLARE curSet CURSOR FOR
        select
             MSet.oyaSyouhinCD
            ,MSet.koSyouhinCD
            ,MSet.kouseiSu
            ,Msyouhin.taniCD
            ,Msyouhin.soukoCD
        from MSet
        left outer join Msyouhin
        on  MSet.koSyouhinCD = Msyouhin.syouhinCD
        where MSet.oyaSyouhinCD = NEW.syouhinCD
        Order by MSet.oyaSyouhinCD, MSet.koSyouhinCD
        ;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    select sethinKBN into _setKBN from Msyouhin where syouhinCD = NEW.syouhinCD;

    IF _setKBN = 0 THEN
    /* 通常品 */
        INSERT INTO Dnyuusyukko
        (
            kaikeiNendo,
            denpyouNO,
            gyouNO,
            akakuro,
            yuukou,
            keijounengetu,
            dataKBN,
            torihikiKBN,
            systemKBN,
            nyuusyukkodate,
            soukoCD,
            syouhinCD,
            syouhinNM,
            suryou,
            taniCD,
            tanka,
            kingaku,
            hontai_kingaku,
            syouhizei,
            insertdate,
            insertTantosya
        )
        values
        (
            NEW.kaikeiNendo,
            NEW.denpyouNO,
            NEW.gyouNO,
            NEW.akakuro,
            NEW.yuukou,
            NEW.keijounengetu,
            NEW.dataKBN,
            NEW.torihikiKBN,
            NEW.syukkaKBN,
            NEW.syukkadate,
            NEW.soukoCD,
            NEW.syouhinCD,
            NEW.syouhinNM,
            NEW.suryou,
            NEW.taniCD,
            NEW.tanka,
            NEW.kingaku,
            NEW.hontai_kingaku,
            NEW.syouhizei,
            CURRENT_TIMESTAMP(),
            NEW.insertTantosya
        );
    ELSE
    /* セット品 */
        OPEN curSet;

        REPEAT
        FETCH curSet
        INTO _oyaSyouhinCD, _koSyouhinCD, _kouseiSu, _taniCD, _soukoCD;
        IF done = 0 THEN
            SET _suryou = NEW.suryou * _kouseiSu;

            INSERT INTO Dnyuusyukko
            (
                kaikeiNendo,
                denpyouNO,
                gyouNO,
                akakuro,
                yuukou,
                keijounengetu,
                dataKBN,
                torihikiKBN,
                systemKBN,
                nyuusyukkodate,
                soukoCD,
                syouhinCD,
                syouhinNM,
                suryou,
                taniCD,
                tanka,
                kingaku,
                hontai_kingaku,
                syouhizei,
                insertdate,
                insertTantosya
            )
            values
            (
                NEW.kaikeiNendo,
                NEW.denpyouNO,
                NEW.gyouNO,
                NEW.akakuro,
                NEW.yuukou,
                NEW.keijounengetu,
                NEW.dataKBN,
                NEW.torihikiKBN,
                NEW.syukkaKBN,
                NEW.syukkadate,
                _soukoCD,
                _koSyouhinCD,
                NEW.syouhinNM,
                _suryou,
                _taniCD,
                0,
                0,
                0,
                0,
                CURRENT_TIMESTAMP(),
                NEW.insertTantosya
            );
        END IF;
        UNTIL done END REPEAT;

        CLOSE curSet;
    END IF;

END;
 ;;
delimiter ;
