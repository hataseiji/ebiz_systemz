DROP PROCEDURE IF EXISTS GetujiKakuteiZaiko;
DELIMITER //
CREATE PROCEDURE GetujiKakuteiZaiko(
    IN  _I_date         date,
    IN  _I_Tantosya     integer(6),
    OUT _o_ErrorMsg      varchar(256),
    OUT _o_Result        Boolean
)
BEGIN
/*
    月次更新
    在庫データの繰り越しを行います。
*/
    DECLARE _counter                  integer;
    DECLARE _kaikei_yyyymm            integer; /* 処理年月 */
    DECLARE _yoku_kaikei_yyyymm       integer; /* 処理年月の翌月 */
    DECLARE _soukoCD                  integer(6) DEFAULT 0;
    DECLARE _syouhinCD                varchar(10);
    DECLARE _tanka                    decimal(8,0) DEFAULT 0;
    DECLARE _keijounengetu            integer(6) DEFAULT 0;
    DECLARE _zengetumatu_zaikosu      decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_uriagesu         decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_syukkosu         decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_sonotasyukkosu   decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_tanaorosigen     decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_siiresu          decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_nyuukosu         decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_sonotanyuukosu   decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_tanaorosizou     decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_uriagesu        decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_syukkosu        decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_sonotasyukkosu  decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_tanaorosigen    decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_siiresu         decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_nyuukosu        decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_sonotanyuukosu  decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_tanaorosizou    decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_zaikosu         decimal(12,3) DEFAULT 0;
    DECLARE _wDate                    date;
    DECLARE done                      INT DEFAULT 0;

    DECLARE curZaiko CURSOR FOR
        select
            soukoCD,
            syouhinCD,
            keijounengetu,
            zengetumatu_zaikosu,
            tougetu_uriagesu,
            tougetu_syukkosu,
            tougetu_sonotasyukkosu,
            tougetu_tanaorosigen,
            tougetu_siiresu,
            tougetu_nyuukosu,
            tougetu_sonotanyuukosu,
            tougetu_tanaorosizou,
            yokugetu_uriagesu,
            yokugetu_syukkosu,
            yokugetu_sonotasyukkosu,
            yokugetu_tanaorosigen,
            yokugetu_siiresu,
            yokugetu_nyuukosu,
            yokugetu_sonotanyuukosu,
            yokugetu_tanaorosizou,
            tanka
        from Dzaiko
        where   Dzaiko.keijounengetu = _kaikei_yyyymm;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    /* 処理年月の取得 */
    select kaikei_yyyymm into _kaikei_yyyymm from Mkanri where kanriCD=1;
    if _kaikei_yyyymm is NULL then
        set _kaikei_yyyymm=200104;
    end if;

    /* 翌月の処理年月算出 */
    SET _wDate = _kaikei_yyyymm * 100 + 01;
    SET _yoku_kaikei_yyyymm = EXTRACT(YEAR_MONTH FROM _wDate + INTERVAL 1 MONTH);

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    OPEN curZaiko;

    REPEAT
    FETCH curZaiko
    INTO
            _soukoCD,
            _syouhinCD,
            _keijounengetu,
            _zengetumatu_zaikosu,
            _tougetu_uriagesu,
            _tougetu_syukkosu,
            _tougetu_sonotasyukkosu,
            _tougetu_tanaorosigen,
            _tougetu_siiresu,
            _tougetu_nyuukosu,
            _tougetu_sonotanyuukosu,
            _tougetu_tanaorosizou,
            _yokugetu_uriagesu,
            _yokugetu_syukkosu,
            _yokugetu_sonotasyukkosu,
            _yokugetu_tanaorosigen,
            _yokugetu_siiresu,
            _yokugetu_nyuukosu,
            _yokugetu_sonotanyuukosu,
            _yokugetu_tanaorosizou,
            _tanka;

    IF done = 0 THEN

        /* 翌月繰越在庫数算出 */
        set _yokugetu_zaikosu =
                    _zengetumatu_zaikosu
                -   _tougetu_uriagesu
                -   _tougetu_syukkosu
                -   _tougetu_sonotasyukkosu
                -   _tougetu_tanaorosigen
                +   _tougetu_siiresu
                +   _tougetu_nyuukosu
                +   _tougetu_sonotanyuukosu
                +   _tougetu_tanaorosizou
                ;

        select count(*) INTO _counter from Dzaiko where Dzaiko.soukoCD = _soukoCD and Dzaiko.syouhinCD = _syouhinCD and Dzaiko.keijounengetu = _yoku_kaikei_yyyymm;
        if _counter = 0 then

            INSERT INTO Dzaiko
            (
                soukoCD,
                syouhinCD,
                keijounengetu,
                zengetumatu_zaikosu,
                tougetu_uriagesu,
                tougetu_syukkosu,
                tougetu_sonotasyukkosu,
                tougetu_tanaorosigen,
                tougetu_siiresu,
                tougetu_nyuukosu,
                tougetu_sonotanyuukosu,
                tougetu_tanaorosizou,
                yokugetu_uriagesu,
                yokugetu_syukkosu,
                yokugetu_sonotasyukkosu,
                yokugetu_tanaorosigen,
                yokugetu_siiresu,
                yokugetu_nyuukosu,
                yokugetu_sonotanyuukosu,
                yokugetu_tanaorosizou,
                tanka,
                insertdate,
                insertTantosya,
                updatedate,
                updateTantosya
            )
            values
            (
                _soukoCD,
                _syouhinCD,
                _yoku_kaikei_yyyymm,
                _yokugetu_zaikosu,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                _tanka,
                _I_date,
                _I_Tantosya,
                _I_date,
                _I_Tantosya
            );
        else
            /* システム的に翌月分の在庫データは発生しないので update は無い。 */
            update Dzaiko set
                zengetumatu_zaikosu     =    _yokugetu_zaikosu,
                updatedate              =    _I_date,
                updateTantosya          =    _I_Tantosya
            where
                    soukoCD              =    _soukoCD
                and syouhinCD            =    _syouhinCD
                and keijounengetu        =    _yoku_kaikei_yyyymm;
        end if;

    END IF;
    UNTIL done END REPEAT;
    CLOSE curZaiko;

/* 翌月エリアの更新
    「翌月エリアは入出庫データより再度集計する。」
    翌月以降の入出庫データを新テーブルYokuDnyuusyukkoにinsertする。
    YokuDnyuusyukkoのinsertのトリガーで在庫へ更新。
    トリガーはtri_Zaikoをほぼコピーで対応する。
*/
    truncate table YokuDnyuusyukko;

    insert into YokuDnyuusyukko
        select * from Dnyuusyukko
        where keijounengetu >= _yoku_kaikei_yyyymm;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
