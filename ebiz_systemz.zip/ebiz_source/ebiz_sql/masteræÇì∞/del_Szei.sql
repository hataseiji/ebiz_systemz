DROP PROCEDURE IF EXISTS del_Szei;
DELIMITER //
CREATE PROCEDURE del_Szei (
     IN _i_zeirituKBN      tinyint(1),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Szei where _i_zeirituKBN = zeirituKBN;
    if _counter = 0 then
        set _o_ErrorMsg = 'マスタに存在しないコードです。';
    else
        -- データ更新
        delete from Szei where _i_zeirituKBN = zeirituKBN;
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
