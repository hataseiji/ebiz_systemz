DROP PROCEDURE IF EXISTS ins_Msiiresaki;
DELIMITER //
CREATE PROCEDURE ins_Msiiresaki (
     IN _i_siiresakiCD                     integer(6),
     IN _i_siiresakiNM                     varchar(40),
     IN _i_siiresakiRNM                    varchar(20),
     IN _i_siiresakiKNM                    varchar(20),
     IN _i_syokutiKBN                      tinyint(1),
     IN _i_keisyo                          varchar(8),
     IN _i_postalCD                        varchar(8),
     IN _i_address1                        varchar(40),
     IN _i_address2                        varchar(40),
     IN _i_tel1                            varchar(20),
     IN _i_naisen1                         varchar(10),
     IN _i_tel2                            varchar(20),
     IN _i_naisen2                         varchar(10),
     IN _i_fax                             varchar(20),
     IN _i_siiresaki_tantousyaNM           varchar(40),
     IN _i_siiresaki_tantousyabusyoNM      varchar(20),
     IN _i_siiresaki_tantousyayakusyokuNM  varchar(24),
     IN _i_daihyousyaNM                    varchar(40),
     IN _i_daihyousyayakusyokuNM           varchar(40),
     IN _i_siharaisakiCD                   integer(6),
     IN _i_simebi1                         tinyint(2),
     IN _i_simebi2                         tinyint(2),
     IN _i_simebi3                         tinyint(2),
     IN _i_tantosyaCD                      varchar(9),
     IN _i_jigyosyoCD                      tinyint(2),
     IN _i_totalization1                   varchar(9),
     IN _i_totalization2                   varchar(9),
     IN _i_totalization3                   varchar(9),
     IN _i_totalization4                   varchar(9),
     IN _i_totalization5                   varchar(9),
     IN _i_hasuuKBN                        tinyint(1),
     IN _i_zeisansyutuKBN                  tinyint(1),
     IN _i_zeihasuuKBN                     tinyint(1),
     IN _i_siharaiannaiKBN                 tinyint(1),
     IN _i_insertdate                      datetime,
     IN _i_insertTantosya                  integer(6),
     IN _i_updatedate                      datetime,
     IN _i_updateTantosya                  integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Msiiresaki where siiresakiCD = _i_siiresakiCD;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Msiiresaki (
            siiresakiCD                     ,
            siiresakiNM                     ,
            siiresakiRNM                    ,
            siiresakiKNM                    ,
            syokutiKBN                      ,
            keisyo                          ,
            postalCD                        ,
            address1                        ,
            address2                        ,
            tel1                            ,
            naisen1                         ,
            tel2                            ,
            naisen2                         ,
            fax                             ,
            siiresaki_tantousyaNM           ,
            siiresaki_tantousyabusyoNM      ,
            siiresaki_tantousyayakusyokuNM  ,
            daihyousyaNM                    ,
            daihyousyayakusyokuNM           ,
            siharaisakiCD                   ,
            simebi1                         ,
            simebi2                         ,
            simebi3                         ,
            tantosyaCD                      ,
            jigyosyoCD                      ,
            totalization1                   ,
            totalization2                   ,
            totalization3                   ,
            totalization4                   ,
            totalization5                   ,
            hasuuKBN                        ,
            zeisansyutuKBN                  ,
            zeihasuuKBN                     ,
            siharaiannaiKBN                 ,
            insertdate                      ,
            insertTantosya                  ,
            updatedate                      ,
            updateTantosya                  
        )
        values
        (
            _i_siiresakiCD                     ,
            _i_siiresakiNM                     ,
            _i_siiresakiRNM                    ,
            _i_siiresakiKNM                    ,
            _i_syokutiKBN                      ,
            _i_keisyo                          ,
            _i_postalCD                        ,
            _i_address1                        ,
            _i_address2                        ,
            _i_tel1                            ,
            _i_naisen1                         ,
            _i_tel2                            ,
            _i_naisen2                         ,
            _i_fax                             ,
            _i_siiresaki_tantousyaNM           ,
            _i_siiresaki_tantousyabusyoNM      ,
            _i_siiresaki_tantousyayakusyokuNM  ,
            _i_daihyousyaNM                    ,
            _i_daihyousyayakusyokuNM           ,
            _i_siharaisakiCD                   ,
            _i_simebi1                         ,
            _i_simebi2                         ,
            _i_simebi3                         ,
            _i_tantosyaCD                      ,
            _i_jigyosyoCD                      ,
            _i_totalization1                   ,
            _i_totalization2                   ,
            _i_totalization3                   ,
            _i_totalization4                   ,
            _i_totalization5                   ,
            _i_hasuuKBN                        ,
            _i_zeisansyutuKBN                  ,
            _i_zeihasuuKBN                     ,
            _i_siharaiannaiKBN                 ,
            _i_insertdate                      ,
            _i_insertTantosya                  ,
            _i_updatedate                      ,
            _i_updateTantosya                  
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
