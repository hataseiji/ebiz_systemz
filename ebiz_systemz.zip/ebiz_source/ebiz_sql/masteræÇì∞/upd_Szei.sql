DROP PROCEDURE IF EXISTS upd_Szei;
DELIMITER //
CREATE PROCEDURE upd_Szei (
     IN _i_zeirituKBN  tinyint(1),
     IN _i_tekiyoudate date,
     IN _i_oldzeidate  decimal(4,3),
     IN _i_newzeidate  decimal(4,3),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Szei where _i_zeirituKBN = zeirituKBN;
    if _counter = 0 then
        set _o_ErrorMsg = 'マスタに存在しないコードです。';
    else
        -- データ更新
        update Szei 
        set
            tekiyoudate  = _i_tekiyoudate ,
            oldzeidate   = _i_oldzeidate  ,
            newzeidate   = _i_newzeidate  
        where zeirituKBN   = _i_zeirituKBN; 

        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
