DROP PROCEDURE IF EXISTS ins_Mhinsyu;
DELIMITER //
CREATE PROCEDURE ins_Mhinsyu (
     IN _i_hinsyuCD        integer(6),
     IN _i_hinsyuNM        varchar(40),
     IN _i_hinsyuKNM       varchar(40),
     IN _i_insertdate      datetime,
     IN _i_insertTantosya  integer(6),
     IN _i_updatedate      datetime,
     IN _i_updateTantosya  integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Mhinsyu where makerCD = _i_makerCD;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Mhinsyu (
            hinsyuCD        ,
            hinsyuNM        ,
            hinsyuKNM       ,
            insertdate      ,
            insertTantosya  ,
            updatedate      ,
            updateTantosya  
        )
        values
        (
            _i_hinsyuCD        ,
            _i_hinsyuNM        ,
            _i_hinsyuKNM       ,
            _i_insertdate      ,
            _i_insertTantosya  ,
            _i_insertdate      ,
            _i_insertTantosya  
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
