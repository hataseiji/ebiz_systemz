DROP PROCEDURE IF EXISTS GetBeforeDsiharaiHead;
DELIMITER //
CREATE PROCEDURE GetBeforeDsiharaiHead(
    IN  _I_siharaisakiCD            integer(6),
    OUT _O_siharaisakiCD           integer(6),
    OUT _O_kaikeinendo             integer(4),
    OUT _O_siharainengetu          integer(6),
    OUT _O_simeBi                  tinyint,
    OUT _O_siiredateFrom          date,
    OUT _O_siiredateTo            date,
    OUT _O_ZENZAN                  decimal(12),
    OUT _O_siiregaku              decimal(12),
    OUT _O_hennpinngaku            decimal(12),
    OUT _O_nebikigaku              decimal(12),
    OUT _O_siharaigaku            decimal(12),
    OUT _O_syouhizeigaku           decimal(12),
    OUT _O_syouhizeisagaku         decimal(12),
    OUT _O_hakkouKBN               tinyint,
    OUT _O_kakuteiKBN              tinyint,
    OUT _O_siharaisyoBangou        integer(6),
    OUT _O_siharaisyohakkoudate    datetime,
    OUT _O_siharaikakuteidate      datetime,
    OUT _O_jikaikurikosigaku       decimal(12)
)
BEGIN
/*
	前回の支払情報を取得します
*/
    select
         SHRH.siharaisakiCD
        ,SHRH.kaikeiNendo
        ,SHRH.siharainengetu
        ,SHRH.simebi
        ,SHRH.siiredateFrom
        ,SHRH.siiredateTo
        ,SHRH.ZENZAN
        ,SHRH.siiregaku
        ,SHRH.hennpinngaku
        ,SHRH.nebikigaku
        ,SHRH.siharaigaku
        ,SHRH.syouhizeigaku
        ,SHRH.syouhizeisagaku
        ,SHRH.hakkouKBN
        ,SHRH.kakuteiKBN
        ,SHRH.siharaisyoBangou
        ,SHRH.siharaisyohakkoudate
        ,SHRH.siharaikakuteidate
        ,SHRH.jikaikurikosigaku
        into
         _O_siharaisakiCD
        ,_O_kaikeinendo
        ,_O_siharainengetu
        ,_O_simeBi
        ,_O_siiredateFrom
        ,_O_siiredateTo
        ,_O_ZENZAN
        ,_O_siiregaku
        ,_O_hennpinngaku
        ,_O_nebikigaku
        ,_O_siharaigaku
        ,_O_syouhizeigaku
        ,_O_syouhizeisagaku
        ,_O_hakkouKBN
        ,_O_kakuteiKBN
        ,_O_siharaisyoBangou
        ,_O_siharaisyohakkoudate
        ,_O_siharaikakuteidate
        ,_O_jikaikurikosigaku
    from DsiharaiHead as SHRH
    inner join (
        select
             SHRH1.siharaisakiCD
            ,MAX(SHRH1.kaikeiNendo) as kaikeiNendo
        from DsiharaiHead as SHRH1
        group by
             SHRH1.siharaisakiCD
    ) as KKND  -- 会計年度最大値
    on KKND.siharaisakiCD = SHRH.siharaisakiCD
    inner join (
        select
             SHRH2.siharaisakiCD
            ,SHRH2.kaikeiNendo
            ,MAX(SHRH2.siharainengetu) as siharainengetu
        from DsiharaiHead as SHRH2
        group by
             SHRH2.siharaisakiCD
            ,SHRH2.kaikeiNendo
    ) as SHYM  -- 支払年月最大値
    on  SHYM.siharaisakiCD = KKND.siharaisakiCD
    and SHYM.kaikeiNendo   = KKND.kaikeiNendo
    inner join (
        select
             SHRH3.siharaisakiCD
            ,SHRH3.kaikeiNendo
            ,SHRH3.siharainengetu
            ,MAX(SHRH3.simebi) as simebi
        from DsiharaiHead as SHRH3
        group by
             SHRH3.siharaisakiCD
            ,SHRH3.kaikeiNendo
            ,SHRH3.siharainengetu
    ) as SMBI  -- 締日最大値
    on  SMBI.siharaisakiCD    = SHYM.siharaisakiCD
    and SMBI.kaikeiNendo      = SHYM.kaikeiNendo
    and SMBI.siharainengetu   = SHYM.siharainengetu
    and SMBI.simebi           = SHRH.simebi

    where SHRH.siharaisakiCD = _I_siharaisakiCD
    and SHRH.siharaisakiCD   = SMBI.siharaisakiCD
    and SHRH.kaikeiNendo     = SMBI.kaikeiNendo
    and SHRH.siharainengetu  = SMBI.siharainengetu
    and SHRH.simebi          = SMBI.simebi    ;

    IF _O_siharaisakiCD IS NULL THEN
        SET _O_siharaisakiCD = 0;
    END IF;
    IF _O_kaikeinendo IS NULL THEN
        SET _O_kaikeinendo = 0;
    END IF;
    IF _O_siharainengetu IS NULL THEN
        SET _O_siharainengetu = 0;
    END IF;
    IF _O_simeBi IS NULL THEN
        SET _O_simeBi = 0;
    END IF;
    IF _O_siiredateFrom IS NULL THEN
        SET _O_siiredateFrom = 0;
    END IF;
    IF _O_siiredateTo IS NULL THEN
        SET _O_siiredateTo = 0;
    END IF;
    IF _O_ZENZAN IS NULL THEN
        SET _O_ZENZAN = 0;
    END IF;
    IF _O_siiregaku IS NULL THEN
        SET _O_siiregaku = 0;
    END IF;
    IF _O_hennpinngaku IS NULL THEN
        SET _O_hennpinngaku = 0;
    END IF;
    IF _O_nebikigaku IS NULL THEN
        SET _O_nebikigaku = 0;
    END IF;
    IF _O_siharaigaku IS NULL THEN
        SET _O_siharaigaku = 0;
    END IF;
    IF _O_syouhizeigaku IS NULL THEN
        SET _O_syouhizeigaku = 0;
    END IF;
    IF _O_syouhizeisagaku IS NULL THEN
        SET _O_syouhizeisagaku = 0;
    END IF;
    IF _O_hakkouKBN IS NULL THEN
        SET _O_hakkouKBN = 0;
    END IF;
    IF _O_kakuteiKBN IS NULL THEN
        SET _O_kakuteiKBN = 0;
    END IF;
    IF _O_siharaisyoBangou IS NULL THEN
        SET _O_siharaisyoBangou = 0;
    END IF;
    IF _O_siharaisyohakkoudate IS NULL THEN
        SET _O_siharaisyohakkoudate = 0;
    END IF;
    IF _O_siharaikakuteidate IS NULL THEN
        SET _O_siharaikakuteidate = 0;
    END IF;
    IF _O_jikaikurikosigaku IS NULL THEN
        SET _O_jikaikurikosigaku = 0;
    END IF;

    SET _O_jikaikurikosigaku = _O_ZENZAN
                                + _O_siiregaku
                                + _O_hennpinngaku
                                + _O_nebikigaku
                                - _O_siharaigaku
                                + _O_syouhizeigaku
                                + _O_syouhizeisagaku;

    /* 前回支払情報の次回繰越額更新 */
    UPDATE DsiharaiHead SET jikaikurikosigaku = _O_jikaikurikosigaku
    where
                siharaisakiCD   = _O_siharaisakiCD
            and kaikeiNendo     = _O_kaikeinendo
            and siharainengetu  = _O_siharainengetu
            and simebi          = _O_simeBi;

END;
//
DELIMITER ;
