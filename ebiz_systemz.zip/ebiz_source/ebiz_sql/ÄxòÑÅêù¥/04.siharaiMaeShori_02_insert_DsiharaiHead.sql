DROP PROCEDURE IF EXISTS siharaiMaeShori_02_insert_DsiharaiHead;
DELIMITER //
CREATE PROCEDURE siharaiMaeShori_02_insert_DsiharaiHead(
    IN _i_siharainengetu     integer(6),
    IN _i_simeBi             tinyint,
    IN _i_insertdate         date,
    IN _i_insertTantosya     integer(6),
    IN _i_siharaiDateFrom    date,
    IN _i_siharaiDateTo      date,
    OUT _o_ErrorMsg        varchar(256),
    OUT _o_Result        Boolean
)
BEGIN
    /* =========================================================================
       今回支払・入金データより今回支払分支払ヘッダを作成
    ========================================================================= */
    -- カーソルから転送される項目
    DECLARE _siharaisakiCD             integer(6) DEFAULT 0;
    DECLARE _dataKBN                   tinyint DEFAULT 0;
    DECLARE _torihikiKBN               tinyint DEFAULT 0;
    DECLARE _hontai_kingaku            decimal(10) DEFAULT 0;
    DECLARE _kingaku                   decimal(10) DEFAULT 0;
    DECLARE _syouhizei                 decimal(10) DEFAULT 0;
    DECLARE _sotoutiKBN                tinyint DEFAULT 0;

    -- ブレイク判定用/更新用項目
    DECLARE _break_siharaisakiCD           integer(6) DEFAULT 0;
    DECLARE _break_siiregaku              decimal(12);
    DECLARE _break_hennpinngaku            decimal(12);
    DECLARE _break_nebikigaku              decimal(12);
    DECLARE _break_siharaigaku            decimal(12);
    DECLARE _break_syouhizeigaku           decimal(12);
    DECLARE _break_syouhizeisagaku         decimal(12);

    DECLARE _break_gkmn_siiregaku              decimal(12);
    DECLARE _break_gkmn_hennpinngaku            decimal(12);
    DECLARE _break_gkmn_nebikigaku              decimal(12);
    DECLARE _break_gkmn_siharaigaku            decimal(12);
    DECLARE _break_gkmn_syouhizeigaku           decimal(12);
    DECLARE _break_gkmn_syouhizeisagaku         decimal(12);

    DECLARE _break_siharaisyoBangou        integer(6);
    -- 前回支払情報取得時に使用
    DECLARE _O_siharaisakiCD           integer(6);
    DECLARE _O_kaikeinendo             integer(4);
    DECLARE _O_siharainengetu          integer(6);
    DECLARE _O_simeBi                  tinyint;
    DECLARE _O_siiredateFrom          date;
    DECLARE _O_siiredateTo            date;
    DECLARE _O_ZENZAN                  decimal(12);
    DECLARE _O_siiregaku              decimal(12);
    DECLARE _O_hennpinngaku            decimal(12);
    DECLARE _O_nebikigaku              decimal(12);
    DECLARE _O_siharaigaku            decimal(12);
    DECLARE _O_syouhizeigaku           decimal(12);
    DECLARE _O_syouhizeisagaku         decimal(12);
    DECLARE _O_hakkouKBN               tinyint;
    DECLARE _O_kakuteiKBN              tinyint;
    DECLARE _O_siharaisyoBangou        integer(6);
    DECLARE _O_siharaisyohakkoudate    datetime;
    DECLARE _O_siharaikakuteidate      datetime;
    DECLARE _O_jikaikurikosigaku       decimal(12);

    DECLARE _aa                        tinyint DEFAULT 0;
    DECLARE done                       INT DEFAULT 0;

    DECLARE cursiharai CURSOR FOR
        (
            select
                 MTOK.siharaisakiCD  AS siharaisakiCD
                ,SURI.dataKBN        AS dataKBN
                ,SURI.torihikiKBN    AS torihikiKBN
                ,SURI.hontai_kingaku AS hontai_kingaku
                ,SURI.kingaku        AS kingaku
                ,SURI.kaikei_syouhizei      AS syouhizei
                ,MSYO.sotoutiKBN      AS sotoutiKBN
            from Ssiire SURI
            inner join Msiiresaki as MTOK -- 仕入先
            on MTOK.siiresakiCD   = SURI.siiresakiCD
            inner join Msyouhin   as MSYO -- 商品
            on MSYO.syouhinCD     = SURI.syouhinCD
            where  SURI.torihikiKBN < 82  -- 2014/03/01

        )
        UNION ALL
        (
            select
                 SNYU.siharaisakiCD  AS siharaisakiCD
                ,SNYU.dataKBN        AS dataKBN
                ,SNYU.torihikiKBN    AS torihikiKBN
                ,SNYU.hontai_kingaku AS hontai_kingaku
                ,SNYU.kingaku        AS kingaku
                ,SNYU.syouhizei      AS syouhizei
                ,2                   AS sotoutiKBN
            from SSiharai SNYU
        )
        ORDER by
                 siharaisakiCD
                ,dataKBN
                ,torihikiKBN;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    SET _break_siiregaku           = 0;
    SET _break_hennpinngaku         = 0;
    SET _break_nebikigaku           = 0;
    SET _break_siharaigaku         = 0;
    SET _break_syouhizeigaku        = 0;
    SET _break_syouhizeisagaku      = 0;
    SET _break_gkmn_siiregaku           = 0;
    SET _break_gkmn_hennpinngaku         = 0;
    SET _break_gkmn_nebikigaku           = 0;
    SET _break_gkmn_siharaigaku         = 0;
    SET _break_gkmn_syouhizeigaku        = 0;
    SET _break_gkmn_syouhizeisagaku      = 0;
    -- 支払ヘッダ作成処理開始
    OPEN cursiharai;

    REPEAT
    FETCH cursiharai
    INTO _siharaisakiCD, _dataKBN, _torihikiKBN, _hontai_kingaku, _kingaku, _syouhizei, _sotoutiKBN;
    IF done = 0 THEN
        IF _aa <> 0 and _siharaisakiCD <> _break_siharaisakiCD THEN
        -- ブレイク処理

            -- 前回支払情報を取得し今回への繰越額を取得する。
            call GetBeforeDsiharaiHead(
                 _break_siharaisakiCD
                ,_O_siharaisakiCD
                ,_O_kaikeinendo
                ,_O_siharainengetu
                ,_O_simeBi
                ,_O_siiredateFrom
                ,_O_siiredateTo
                ,_O_ZENZAN
                ,_O_siiregaku
                ,_O_hennpinngaku
                ,_O_nebikigaku
                ,_O_siharaigaku
                ,_O_syouhizeigaku
                ,_O_syouhizeisagaku
                ,_O_hakkouKBN
                ,_O_kakuteiKBN
                ,_O_siharaisyoBangou
                ,_O_siharaisyohakkoudate
                ,_O_siharaikakuteidate
                ,_O_jikaikurikosigaku
            );

            -- 支払書番号の取得
            SET @kaikei_yyyy = 0;
            SET @DenpyouNumber = 0;
            call GetDenpyouNumber(
                  130
                 ,@kaikei_yyyy
                 ,@DenpyouNumber);

            -- 支払ヘッダの追加
            insert into DsiharaiHead (
                 siharaisakiCD
                ,kaikeiNendo
                ,siharainengetu
                ,simebi
                ,siiredateFrom
                ,siiredateTo
                ,ZENZAN
                ,siiregaku
                ,hennpinngaku
                ,nebikigaku
                ,siharaigaku
                ,syouhizeigaku
                ,syouhizeisagaku
                ,gkmn_siiregaku
                ,gkmn_hennpinngaku
                ,gkmn_nebikigaku
                ,gkmn_siharaigaku
                ,gkmn_syouhizeigaku
                ,gkmn_syouhizeisagaku
                ,hakkouKBN
                ,kakuteiKBN
                ,siharaisyoBangou
                ,siharaisyohakkoudate
                ,siharaikakuteidate
                ,jikaikurikosigaku
                ,insertdate
                ,insertTantosya
            ) values (
                 _break_siharaisakiCD
                ,@kaikei_yyyy
                ,_i_siharainengetu       -- 受け渡されたパラメータ
                ,_i_simeBi               -- 受け渡されたパラメータ
                ,_i_siharaiDateFrom
                ,_i_siharaiDateTo
                ,_O_jikaikurikosigaku  -- ↓ 前残は上記GetBeforeDsiharaiHeadで取得したものをセットする
                ,_break_siiregaku
                ,_break_hennpinngaku
                ,_break_nebikigaku
                ,_break_siharaigaku
                ,_break_syouhizeigaku
                ,_break_syouhizeisagaku
                ,_break_gkmn_siiregaku
                ,_break_gkmn_hennpinngaku
                ,_break_gkmn_nebikigaku
                ,_break_gkmn_siharaigaku
                ,_break_gkmn_syouhizeigaku
                ,_break_gkmn_syouhizeisagaku
                ,0
                ,0
                ,@DenpyouNumber
                ,NULL
                ,NULL
                ,_O_jikaikurikosigaku + _break_siiregaku + _break_hennpinngaku + _break_nebikigaku - _break_siharaigaku + _break_syouhizeigaku + _break_syouhizeisagaku
                ,_i_insertdate
                ,_i_insertTantosya
            );
            SET _break_siiregaku           = 0;
            SET _break_hennpinngaku         = 0;
            SET _break_nebikigaku           = 0;
            SET _break_siharaigaku         = 0;
            SET _break_syouhizeigaku        = 0;
            SET _break_syouhizeisagaku      = 0;
            SET _break_gkmn_siiregaku           = 0;
            SET _break_gkmn_hennpinngaku         = 0;
            SET _break_gkmn_nebikigaku           = 0;
            SET _break_gkmn_siharaigaku         = 0;
            SET _break_gkmn_syouhizeigaku        = 0;
            SET _break_gkmn_syouhizeisagaku      = 0;
        END IF;


        -- ブレイク判定用
        SET _break_siharaisakiCD   = _siharaisakiCD;
        -- 取引区分により異なる集計先に集計 (仕入・入金データより)
        IF _dataKBN = 80 and (_torihikiKBN = 10 or _torihikiKBN = 11) THEN
        -- 仕入
            SET _break_siiregaku = _break_siiregaku + _hontai_kingaku;
            SET _break_gkmn_siiregaku = _break_gkmn_siiregaku + _kingaku;
            SET _break_syouhizeigaku  = _break_syouhizeigaku + _syouhizei;
            IF _sotoutiKBN <> 1 THEN
                SET _break_gkmn_syouhizeigaku  = _break_gkmn_syouhizeigaku + _syouhizei;
            END IF;
        ELSEIF _dataKBN = 80 and _torihikiKBN = 20 THEN
        -- 返品
            SET _break_hennpinngaku = _break_hennpinngaku + _hontai_kingaku;
            SET _break_syouhizeigaku    = _break_syouhizeigaku + _syouhizei;
            SET _break_gkmn_hennpinngaku = _break_gkmn_hennpinngaku + _kingaku;
            IF _sotoutiKBN <> 1 THEN
                SET _break_gkmn_syouhizeigaku  = _break_gkmn_syouhizeigaku + _syouhizei;
            END IF;
        ELSEIF _dataKBN = 80 and _torihikiKBN = 30 THEN
        -- 値引
            SET _break_nebikigaku = _break_nebikigaku + _hontai_kingaku;
            SET _break_syouhizeigaku  = _break_syouhizeigaku + _syouhizei;
            SET _break_gkmn_nebikigaku = _break_gkmn_nebikigaku + _kingaku;
            IF _sotoutiKBN <> 1 THEN
                SET _break_gkmn_syouhizeigaku  = _break_gkmn_syouhizeigaku + _syouhizei;
            END IF;
        ELSEIF _dataKBN = 80 and (_torihikiKBN = 81 or _torihikiKBN = 82) THEN
        -- 消費税調整
            SET _break_syouhizeisagaku  = _break_syouhizeisagaku + _syouhizei;
            IF _sotoutiKBN <> 1 THEN
                SET _break_gkmn_syouhizeisagaku  = _break_gkmn_syouhizeisagaku + _syouhizei;
            END IF;
        ELSEIF _dataKBN = 100 THEN
        -- 入金
            SET _break_siharaigaku = _break_siharaigaku + _kingaku;
            SET _break_gkmn_siharaigaku = _break_gkmn_siharaigaku + _kingaku;
        END IF;

        SET _aa = 1;

    END IF;
    UNTIL done END REPEAT;

    IF _aa <> 0 THEN
    -- ブレイク処理

        -- 前回支払情報を取得し今回への繰越額を取得する。
        call GetBeforeDsiharaiHead(
             _break_siharaisakiCD
            ,_O_siharaisakiCD
            ,_O_kaikeinendo
            ,_O_siharainengetu
            ,_O_simeBi
            ,_O_siiredateFrom
            ,_O_siiredateTo
            ,_O_ZENZAN
            ,_O_siiregaku
            ,_O_hennpinngaku
            ,_O_nebikigaku
            ,_O_siharaigaku
            ,_O_syouhizeigaku
            ,_O_syouhizeisagaku
            ,_O_hakkouKBN
            ,_O_kakuteiKBN
            ,_O_siharaisyoBangou
            ,_O_siharaisyohakkoudate
            ,_O_siharaikakuteidate
            ,_O_jikaikurikosigaku
        );

        -- 支払書番号の取得
        SET @kaikei_yyyy = 0;
        SET @DenpyouNumber = 0;
        call GetDenpyouNumber(
              130
             ,@kaikei_yyyy
             ,@DenpyouNumber);

        -- 支払ヘッダの追加
        insert into DsiharaiHead (
             siharaisakiCD
            ,kaikeiNendo
            ,siharainengetu
            ,simebi
            ,siiredateFrom
            ,siiredateTo
            ,ZENZAN
            ,siiregaku
            ,hennpinngaku
            ,nebikigaku
            ,siharaigaku
            ,syouhizeigaku
            ,syouhizeisagaku
            ,gkmn_siiregaku
            ,gkmn_hennpinngaku
            ,gkmn_nebikigaku
            ,gkmn_siharaigaku
            ,gkmn_syouhizeigaku
            ,gkmn_syouhizeisagaku
            ,hakkouKBN
            ,kakuteiKBN
            ,siharaisyoBangou
            ,siharaisyohakkoudate
            ,siharaikakuteidate
            ,jikaikurikosigaku
            ,insertdate
            ,insertTantosya
        ) values (
             _break_siharaisakiCD
            ,@kaikei_yyyy
            ,_i_siharainengetu       -- 受け渡されたパラメータ
            ,_i_simeBi               -- 受け渡されたパラメータ
            ,_i_siharaiDateFrom
            ,_i_siharaiDateTo
            ,_O_jikaikurikosigaku  -- ↓ 前残は上記GetBeforeDsiharaiHeadで取得したものをセットする
            ,_break_siiregaku
            ,_break_hennpinngaku
            ,_break_nebikigaku
            ,_break_siharaigaku
            ,_break_syouhizeigaku
            ,_break_syouhizeisagaku
            ,_break_gkmn_siiregaku
            ,_break_gkmn_hennpinngaku
            ,_break_gkmn_nebikigaku
            ,_break_gkmn_siharaigaku
            ,_break_gkmn_syouhizeigaku
            ,_break_gkmn_syouhizeisagaku
            ,0
            ,0
            ,@DenpyouNumber
            ,NULL
            ,NULL
            ,_O_jikaikurikosigaku + _break_siiregaku + _break_hennpinngaku + _break_nebikigaku - _break_siharaigaku + _break_syouhizeigaku + _break_syouhizeisagaku
            ,_i_insertdate
            ,_i_insertTantosya
        );
    END IF;
    CLOSE cursiharai;
    -- 支払ヘッダ作成処理終了

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
