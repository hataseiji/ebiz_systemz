DROP PROCEDURE IF EXISTS seikyuuMaeShori_04_insert_zeiSagaku;
DELIMITER //
CREATE PROCEDURE seikyuuMaeShori_04_insert_zeiSagaku(
    IN _i_seikyuunengetu     integer(6),
    IN _i_simeBi             tinyint,
    IN _i_insertdate         date,
    IN _i_insertTantosya     integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    /* =============================
       売上データに消費税差額データを追加
     ============================ */
    DECLARE _seikyuusakiCD           integer(6) DEFAULT 0;
    DECLARE _kaikeinendo             integer(4);
    DECLARE _uriagedate              date;
    DECLARE _denpyouNumber           integer(6);  -- 伝票番号取得時にも使用
    DECLARE _gyouNO                  integer(3);
    DECLARE _kingaku                 decimal(10);
    DECLARE _hontai_kingaku          decimal(10);
    DECLARE _syouhizei               decimal(10);
    DECLARE _seikyuusyoBangou        integer(6);
    DECLARE _syouhinCD               varchar(10);
    DECLARE _syouhinNM               varchar(40);
    DECLARE _O_utiZeinukigaku        decimal(10);
    DECLARE _O_sotoZei               decimal(10);
    DECLARE _O_utiZei                decimal(10);
    DECLARE _sum_hontai_kingaku      decimal(10) DEFAULT 0;
    DECLARE _sum_syouhizei           decimal(10) DEFAULT 0;
    DECLARE _break_seikyuusakiCD     integer(6) DEFAULT 0;
    DECLARE _break_kaikeinendo       integer(4);
    DECLARE _break_uriagedate        date;
    DECLARE _break_denpyouNumber     integer(6);  -- 伝票番号取得時にも使用
    DECLARE _break_gyouNO            integer(3);
    DECLARE _break_seikyuusyoBangou  integer(6);
    -- DECLARE _kaikei_nendo            integer(4)  DEFAULT 0;
    DECLARE _aa                      tinyint DEFAULT 0;
    DECLARE done                     INT DEFAULT 0;
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    DECLARE curZeiSagaku CURSOR FOR
        select
             MTOK.seikyuusakiCD
            ,DURI.kaikeiNendo
            ,DURI.uriagedate
            ,DURI.denpyouNO
            ,DURI.gyouNO
            ,DURI.hontai_kingaku
            -- ,DURI.syouhizei
            ,DURI.kaikei_syouhizei
            ,DURI.seikyuusyoBangou
        from DUriage as DURI
        inner join SUriage as SURI     -- 今回請求対象のデータを抽出済み
        on  SURI.kaikeiNendo = DURI.kaikeiNendo
        and SURI.denpyouNO   = DURI.denpyouNO
        and SURI.gyouNO      = DURI.gyouNO
        inner join Mtokuisaki as MTOK  -- 得意先
        on MTOK.tokuisakiCD   = DURI.tokuisakiCD
        left outer join Msyouhin as MSYO
        on MSYO.syouhinCD     = DURI.syouhinCD
        where DURI.dataKBN        = 50 -- 売上
        and   MTOK.zeisansyutuKBN = 2  -- 請求時一括
        and   MSYO.sotoutiKBN     = 0  -- 外税
        ORDER by
             MTOK.seikyuusakiCD
            ,DURI.kaikeiNendo
            ,DURI.denpyouNO
            ,DURI.gyouNO;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

  select min(syouhinCD) , min(syouhinNM) into _syouhinCD, _syouhinNM from Msyouhin where zeisyohinKBN       = 1;

    -- 消費税差額データ作成処理開始
    OPEN curZeiSagaku;

    SET _aa = 0;
    REPEAT
    FETCH curZeiSagaku
    INTO _seikyuusakiCD, _kaikeinendo, _uriagedate, _denpyouNumber, _gyouNO, _hontai_kingaku, _syouhizei, _seikyuusyoBangou;
    IF NOT done THEN
        IF _aa <> 0 and _seikyuusakiCD <> _break_seikyuusakiCD THEN
            -- ブレイク処理
            -- 消費税算出
            call GetZei(
                 50
                ,_break_uriagedate
                ,_break_seikyuusakiCD
                ,0
                ,_sum_hontai_kingaku
                ,_O_utiZeinukigaku
                ,_O_sotoZei
                ,_O_utiZei
            );
            /*
                _I_dataKBN          50:売上入金/80:仕入支払
                _I_date             消費税算出基準日(売上計上日)
                _I_torihikisakiCD   請求先CDまたは支払先CD
                _I_zeikomiKingaku   これから内税を算出
                _I_zeinukiKingaku   これから外税を算出
                _O_utiZeinukigaku   内税の税抜額が返される
                _O_sotoZei          外税の消費税額が返される
                _O_utiZei           内税の消費税額が返される
                _zeisansyutuKBN     0:明細単位 1:伝票単位 2:請求時一括 3:計算しない
                _zeihasuuKBN        0:四捨五入 1:切捨て 2:切上げ
                内税の算出方法         内税額 = 税込額 - (税込額 / 1.05)
            */
            IF _O_sotoZei <> _sum_syouhizei THEN
            -- 伝票番号取得
            SET @kaikei_yyyy = 0;
            SET @DenpyouNumber = 0;
            call GetDenpyouNumber(
                  50
                 ,@kaikei_yyyy
                 ,@DenpyouNumber);
                -- 消費税差額データinsert
                call ins_Duriage(
                     @kaikei_yyyy
                    ,@DenpyouNumber
                    ,1
                    ,1
                    ,0
                    ,0
                    ,_break_uriagedate
                    ,50
                    ,82
                    ,80
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,_break_uriagedate
                    ,_break_uriagedate
                    ,_break_uriagedate
                    ,0
                    ,0
                    ,_break_seikyuusakiCD
                    ,''
                    ,999999
                    ,999999
                    ,''
                    ,''
                    ,''
                    ,''
                    ,''
                    ,''
                    ,''
                    ,''
                    ,80
                    ,_syouhinCD
                    ,_syouhinNM
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,''
                    ,0
                    ,_O_sotoZei                     -- 印字用消費税
                    ,_O_sotoZei - _sum_syouhizei    -- 会計用消費税
                    ,_break_seikyuusyoBangou
                    ,_i_insertdate
                    ,_i_insertTantosya
                    ,_ErrorMsg
                    ,_Result
                    );                -- 請求ヘッダに反映
                update DseikyuuHead
                    SET syouhizeisagaku = syouhizeisagaku + _O_sotoZei - _sum_syouhizei
                        ,gkmn_syouhizeisagaku = gkmn_syouhizeisagaku + _O_sotoZei - _sum_syouhizei
                        ,jikaikurikosigaku = jikaikurikosigaku + _O_sotoZei - _sum_syouhizei
                where seikyuusakiCD  = _break_seikyuusakiCD
                and   kaikeiNendo    = _break_kaikeinendo
                and   seikyuunengetu = _i_seikyuunengetu
                and   simebi         = _i_simeBi;

            END IF;

            SET _sum_hontai_kingaku = 0;
            SET _sum_syouhizei      = 0;

        END IF;

        SET _break_seikyuusakiCD    = _seikyuusakiCD;
        SET _break_kaikeinendo      = _kaikeinendo;
        SET _break_uriagedate       = _uriagedate;
        -- SET _break_denpyouNumber    = _denpyouNumber;
        SET _break_gyouNO           = _gyouNO;
        SET _break_seikyuusyoBangou = _seikyuusyoBangou;
        SET _sum_hontai_kingaku     = _sum_hontai_kingaku + _hontai_kingaku;
        SET _sum_syouhizei          = _sum_syouhizei      + _syouhizei;
        SET _aa = 1;

    END IF;
    UNTIL done END REPEAT;

    IF _aa <> 0 THEN
    -- ブレイク処理
        -- 消費税算出
        call GetZei(
             50
            ,_break_uriagedate
            ,_break_seikyuusakiCD
            ,0
            ,_sum_hontai_kingaku
            ,_O_utiZeinukigaku
            ,_O_sotoZei
            ,_O_utiZei
        );
        /*
            _I_dataKBN          50:売上入金/80:仕入支払
            _I_date             消費税算出基準日(売上計上日)
            _I_torihikisakiCD   請求先CDまたは支払先CD
            _I_zeikomiKingaku   これから内税を算出
            _I_zeinukiKingaku   これから外税を算出
            _O_utiZeinukigaku   内税の税抜額が返される
            _O_sotoZei          外税の消費税額が返される
            _O_utiZei           内税の消費税額が返される
            _zeisansyutuKBN     0:明細単位 1:伝票単位 2:請求時一括 3:計算しない
            _zeihasuuKBN        0:四捨五入 1:切捨て 2:切上げ
            内税の算出方法         内税額 = 税込額 - (税込額 / 1.05)
        */
        IF _O_sotoZei <> _sum_syouhizei THEN
            -- 伝票番号取得
            SET @kaikei_yyyy = 0;
            SET @DenpyouNumber = 0;
            call GetDenpyouNumber(
                  50
                 ,@kaikei_yyyy
                 ,@DenpyouNumber);
            -- 消費税差額データinsert
            call ins_Duriage(
                     @kaikei_yyyy
                    ,@DenpyouNumber
                    ,1
                    ,1
                    ,0
                    ,0
                    ,_break_uriagedate
                    ,50
                    ,82
                    ,80
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,_break_uriagedate
                    ,_break_uriagedate
                    ,_break_uriagedate
                    ,0
                    ,0
                    ,_break_seikyuusakiCD
                    ,''
                    ,999999
                    ,999999
                    ,''
                    ,''
                    ,''
                    ,''
                    ,''
                    ,''
                    ,''
                    ,''
                    ,80
                    ,_syouhinCD
                    ,_syouhinNM
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,''
                    ,0
                    ,_O_sotoZei                     -- 印字用消費税
                    ,_O_sotoZei - _sum_syouhizei    -- 会計用消費税
                    ,_break_seikyuusyoBangou
                    ,_i_insertdate
                    ,_i_insertTantosya
                    ,_ErrorMsg
                    ,_Result
                    );                -- 請求ヘッダに反映

                -- 請求ヘッダに反映
                update DseikyuuHead
                    SET syouhizeisagaku = syouhizeisagaku + _O_sotoZei - _sum_syouhizei
                        ,gkmn_syouhizeisagaku = gkmn_syouhizeisagaku + _O_sotoZei - _sum_syouhizei
                        ,jikaikurikosigaku = jikaikurikosigaku + _O_sotoZei - _sum_syouhizei
                where seikyuusakiCD  = _break_seikyuusakiCD
                and   kaikeiNendo    = _break_kaikeinendo
                and   seikyuunengetu = _i_seikyuunengetu
                and   simebi         = _i_simeBi;
        END IF;
    END IF;

    CLOSE curZeiSagaku;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
