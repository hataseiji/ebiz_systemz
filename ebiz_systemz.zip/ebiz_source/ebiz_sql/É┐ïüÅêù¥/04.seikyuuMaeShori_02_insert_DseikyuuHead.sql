DROP PROCEDURE IF EXISTS seikyuuMaeShori_02_insert_DseikyuuHead;
DELIMITER //
CREATE PROCEDURE seikyuuMaeShori_02_insert_DseikyuuHead(
    IN _i_seikyuunengetu     integer(6),
    IN _i_simeBi             tinyint,
    IN _i_insertdate         date,
    IN _i_insertTantosya     integer(6),
    IN _i_seikyuuDateFrom    date,
    IN _i_seikyuuDateTo      date,
    OUT _o_ErrorMsg        varchar(256),
    OUT _o_Result        Boolean
)
BEGIN
    /* =========================================================================
       今回請求・入金データより今回請求分請求ヘッダを作成
    ========================================================================= */
    -- カーソルから転送される項目
    DECLARE _seikyuusakiCD             integer(6) DEFAULT 0;
    DECLARE _dataKBN                   tinyint DEFAULT 0;
    DECLARE _torihikiKBN               tinyint DEFAULT 0;
    DECLARE _hontai_kingaku            decimal(10) DEFAULT 0;
    DECLARE _kingaku                   decimal(10) DEFAULT 0;
    DECLARE _syouhizei                 decimal(10) DEFAULT 0;
    DECLARE _sotoutiKBN                tinyint DEFAULT 0;

    -- ブレイク判定用/更新用項目
    DECLARE _break_seikyuusakiCD           integer(6) DEFAULT 0;
    DECLARE _break_uriagegaku              decimal(12);
    DECLARE _break_hennpinngaku            decimal(12);
    DECLARE _break_nebikigaku              decimal(12);
    DECLARE _break_nyuukinngaku            decimal(12);
    DECLARE _break_syouhizeigaku           decimal(12);
    DECLARE _break_syouhizeisagaku         decimal(12);

    DECLARE _break_gkmn_uriagegaku              decimal(12);
    DECLARE _break_gkmn_hennpinngaku            decimal(12);
    DECLARE _break_gkmn_nebikigaku              decimal(12);
    DECLARE _break_gkmn_nyuukinngaku            decimal(12);
    DECLARE _break_gkmn_syouhizeigaku           decimal(12);
    DECLARE _break_gkmn_syouhizeisagaku         decimal(12);

    DECLARE _break_seikyuusyoBangou        integer(6);
    -- 前回請求情報取得時に使用
    DECLARE _O_seikyuusakiCD           integer(6);
    DECLARE _O_kaikeinendo             integer(4);
    DECLARE _O_seikyuunengetu          integer(6);
    DECLARE _O_simeBi                  tinyint;
    DECLARE _O_uriagedateFrom          date;
    DECLARE _O_uriagedateTo            date;
    DECLARE _O_ZENZAN                  decimal(12);
    DECLARE _O_uriagegaku              decimal(12);
    DECLARE _O_hennpinngaku            decimal(12);
    DECLARE _O_nebikigaku              decimal(12);
    DECLARE _O_nyuukinngaku            decimal(12);
    DECLARE _O_syouhizeigaku           decimal(12);
    DECLARE _O_syouhizeisagaku         decimal(12);
    DECLARE _O_hakkouKBN               tinyint;
    DECLARE _O_kakuteiKBN              tinyint;
    DECLARE _O_seikyuusyoBangou        integer(6);
    DECLARE _O_seikyuusyohakkoudate    datetime;
    DECLARE _O_seikyuukakuteidate      datetime;
    DECLARE _O_jikaikurikosigaku       decimal(12);

    DECLARE _aa                        tinyint DEFAULT 0;
    DECLARE done                       INT DEFAULT 0;

    DECLARE curSeikyuu CURSOR FOR
        (
            select
                 MTOK.seikyuusakiCD  AS seikyuusakiCD
                ,SURI.dataKBN        AS dataKBN
                ,SURI.torihikiKBN    AS torihikiKBN
                ,SURI.hontai_kingaku AS hontai_kingaku
                ,SURI.kingaku        AS kingaku
                ,SURI.kaikei_syouhizei      AS syouhizei
                ,MSYO.sotoutiKBN      AS sotoutiKBN
            from SUriage SURI
            inner join Mtokuisaki as MTOK -- 得意先
            on MTOK.tokuisakiCD   = SURI.tokuisakiCD
            inner join Msyouhin   as MSYO -- 商品
            on MSYO.syouhinCD     = SURI.syouhinCD
            -- inner join Mtokuisaki as MSEI -- 請求先
            -- on MSEI.seikyuusakiCD = MTOK.seikyuusakiCD
            where  SURI.torihikiKBN < 82  -- 2014/03/01
        )
        UNION ALL
        (
            select
                 SNYU.seikyuusakiCD  AS seikyuusakiCD
                ,SNYU.dataKBN        AS dataKBN
                ,SNYU.torihikiKBN    AS torihikiKBN
                ,SNYU.hontai_kingaku AS hontai_kingaku
                ,SNYU.kingaku        AS kingaku
                ,SNYU.syouhizei      AS syouhizei
                ,2                   AS sotoutiKBN
            from SNyuukinn SNYU
        )
        ORDER by
                 seikyuusakiCD
                ,dataKBN
                ,torihikiKBN;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    SET _break_uriagegaku           = 0;
    SET _break_hennpinngaku         = 0;
    SET _break_nebikigaku           = 0;
    SET _break_nyuukinngaku         = 0;
    SET _break_syouhizeigaku        = 0;
    SET _break_syouhizeisagaku      = 0;
    SET _break_gkmn_uriagegaku           = 0;
    SET _break_gkmn_hennpinngaku         = 0;
    SET _break_gkmn_nebikigaku           = 0;
    SET _break_gkmn_nyuukinngaku         = 0;
    SET _break_gkmn_syouhizeigaku        = 0;
    SET _break_gkmn_syouhizeisagaku      = 0;
    -- 請求ヘッダ作成処理開始
    OPEN curSeikyuu;

    REPEAT
    FETCH curSeikyuu
    INTO _seikyuusakiCD, _dataKBN, _torihikiKBN, _hontai_kingaku, _kingaku, _syouhizei, _sotoutiKBN;
    IF done = 0 THEN
        IF _aa <> 0 and _seikyuusakiCD <> _break_seikyuusakiCD THEN
        -- ブレイク処理

            -- 前回請求情報を取得し今回への繰越額を取得する。
            call GetBeforeDseikyuuHead(
                 _break_seikyuusakiCD
                ,_O_seikyuusakiCD
                ,_O_kaikeinendo
                ,_O_seikyuunengetu
                ,_O_simeBi
                ,_O_uriagedateFrom
                ,_O_uriagedateTo
                ,_O_ZENZAN
                ,_O_uriagegaku
                ,_O_hennpinngaku
                ,_O_nebikigaku
                ,_O_nyuukinngaku
                ,_O_syouhizeigaku
                ,_O_syouhizeisagaku
                ,_O_hakkouKBN
                ,_O_kakuteiKBN
                ,_O_seikyuusyoBangou
                ,_O_seikyuusyohakkoudate
                ,_O_seikyuukakuteidate
                ,_O_jikaikurikosigaku
            );

            -- 請求書番号の取得
            SET @kaikei_yyyy = 0;
            SET @DenpyouNumber = 0;
            call GetDenpyouNumber(
                  120
                 ,@kaikei_yyyy
                 ,@DenpyouNumber);

            -- 請求ヘッダの追加
            insert into DseikyuuHead (
                 seikyuusakiCD
                ,kaikeiNendo
                ,seikyuunengetu
                ,simebi
                ,uriagedateFrom
                ,uriagedateTo
                ,ZENZAN
                ,uriagegaku
                ,hennpinngaku
                ,nebikigaku
                ,nyuukinngaku
                ,syouhizeigaku
                ,syouhizeisagaku
                ,gkmn_uriagegaku
                ,gkmn_hennpinngaku
                ,gkmn_nebikigaku
                ,gkmn_nyuukinngaku
                ,gkmn_syouhizeigaku
                ,gkmn_syouhizeisagaku
                ,hakkouKBN
                ,kakuteiKBN
                ,seikyuusyoBangou
                ,seikyuusyohakkoudate
                ,seikyuukakuteidate
                ,jikaikurikosigaku
                ,insertdate
                ,insertTantosya
            ) values (
                 _break_seikyuusakiCD
                ,@kaikei_yyyy
                ,_i_seikyuunengetu       -- 受け渡されたパラメータ
                ,_i_simeBi               -- 受け渡されたパラメータ
                ,_i_seikyuuDateFrom
                ,_i_seikyuuDateTo
                ,_O_jikaikurikosigaku  -- ↓ 前残は上記GetBeforeDseikyuuHeadで取得したものをセットする
                ,_break_uriagegaku
                ,_break_hennpinngaku
                ,_break_nebikigaku
                ,_break_nyuukinngaku
                ,_break_syouhizeigaku
                ,_break_syouhizeisagaku
                ,_break_gkmn_uriagegaku
                ,_break_gkmn_hennpinngaku
                ,_break_gkmn_nebikigaku
                ,_break_gkmn_nyuukinngaku
                ,_break_gkmn_syouhizeigaku
                ,_break_gkmn_syouhizeisagaku
                ,0
                ,0
                ,@DenpyouNumber
                ,NULL
                ,NULL
                ,_O_jikaikurikosigaku + _break_uriagegaku + _break_hennpinngaku + _break_nebikigaku - _break_nyuukinngaku + _break_syouhizeigaku + _break_syouhizeisagaku
                ,_i_insertdate
                ,_i_insertTantosya
            );
            SET _break_uriagegaku           = 0;
            SET _break_hennpinngaku         = 0;
            SET _break_nebikigaku           = 0;
            SET _break_nyuukinngaku         = 0;
            SET _break_syouhizeigaku        = 0;
            SET _break_syouhizeisagaku      = 0;
            SET _break_gkmn_uriagegaku           = 0;
            SET _break_gkmn_hennpinngaku         = 0;
            SET _break_gkmn_nebikigaku           = 0;
            SET _break_gkmn_nyuukinngaku         = 0;
            SET _break_gkmn_syouhizeigaku        = 0;
            SET _break_gkmn_syouhizeisagaku      = 0;
        END IF;


        -- ブレイク判定用
        SET _break_seikyuusakiCD   = _seikyuusakiCD;
        -- 取引区分により異なる集計先に集計 (売上・入金データより)
        IF _dataKBN = 50 and (_torihikiKBN = 10 or _torihikiKBN = 11) THEN
        -- 売上
            SET _break_uriagegaku = _break_uriagegaku + _hontai_kingaku;
            SET _break_gkmn_uriagegaku = _break_gkmn_uriagegaku + _kingaku;
            SET _break_syouhizeigaku  = _break_syouhizeigaku + _syouhizei;
            IF _sotoutiKBN <> 1 THEN
                SET _break_gkmn_syouhizeigaku  = _break_gkmn_syouhizeigaku + _syouhizei;
            END IF;
        ELSEIF _dataKBN = 50 and _torihikiKBN = 20 THEN
        -- 返品
            SET _break_hennpinngaku = _break_hennpinngaku + _hontai_kingaku;
            SET _break_syouhizeigaku    = _break_syouhizeigaku + _syouhizei;
            SET _break_gkmn_hennpinngaku = _break_gkmn_hennpinngaku + _kingaku;
            IF _sotoutiKBN <> 1 THEN
                SET _break_gkmn_syouhizeigaku  = _break_gkmn_syouhizeigaku + _syouhizei;
            END IF;
        ELSEIF _dataKBN = 50 and _torihikiKBN = 30 THEN
        -- 値引
            SET _break_nebikigaku = _break_nebikigaku + _hontai_kingaku;
            SET _break_syouhizeigaku  = _break_syouhizeigaku + _syouhizei;
            SET _break_gkmn_nebikigaku = _break_gkmn_nebikigaku + _kingaku;
            IF _sotoutiKBN <> 1 THEN
                SET _break_gkmn_syouhizeigaku  = _break_gkmn_syouhizeigaku + _syouhizei;
            END IF;
        ELSEIF _dataKBN = 50 and (_torihikiKBN = 81 or _torihikiKBN = 82) THEN
        -- 消費税調整
            SET _break_syouhizeisagaku  = _break_syouhizeisagaku + _syouhizei;
            IF _sotoutiKBN <> 1 THEN
                SET _break_gkmn_syouhizeisagaku  = _break_gkmn_syouhizeisagaku + _syouhizei;
            END IF;
        ELSEIF _dataKBN = 90 THEN
        -- 入金
            SET _break_nyuukinngaku = _break_nyuukinngaku + _kingaku;
            SET _break_gkmn_nyuukinngaku = _break_gkmn_nyuukinngaku + _kingaku;
        END IF;

        SET _aa = 1;

    END IF;
    UNTIL done END REPEAT;

    IF _aa <> 0 THEN
    -- ブレイク処理

        -- 前回請求情報を取得し今回への繰越額を取得する。
        call GetBeforeDseikyuuHead(
             _break_seikyuusakiCD
            ,_O_seikyuusakiCD
            ,_O_kaikeinendo
            ,_O_seikyuunengetu
            ,_O_simeBi
            ,_O_uriagedateFrom
            ,_O_uriagedateTo
            ,_O_ZENZAN
            ,_O_uriagegaku
            ,_O_hennpinngaku
            ,_O_nebikigaku
            ,_O_nyuukinngaku
            ,_O_syouhizeigaku
            ,_O_syouhizeisagaku
            ,_O_hakkouKBN
            ,_O_kakuteiKBN
            ,_O_seikyuusyoBangou
            ,_O_seikyuusyohakkoudate
            ,_O_seikyuukakuteidate
            ,_O_jikaikurikosigaku
        );

        -- 請求書番号の取得
        SET @kaikei_yyyy = 0;
        SET @DenpyouNumber = 0;
        call GetDenpyouNumber(
              120
             ,@kaikei_yyyy
             ,@DenpyouNumber);

        -- 請求ヘッダの追加
        insert into DseikyuuHead (
             seikyuusakiCD
            ,kaikeiNendo
            ,seikyuunengetu
            ,simebi
            ,uriagedateFrom
            ,uriagedateTo
            ,ZENZAN
            ,uriagegaku
            ,hennpinngaku
            ,nebikigaku
            ,nyuukinngaku
            ,syouhizeigaku
            ,syouhizeisagaku
            ,gkmn_uriagegaku
            ,gkmn_hennpinngaku
            ,gkmn_nebikigaku
            ,gkmn_nyuukinngaku
            ,gkmn_syouhizeigaku
            ,gkmn_syouhizeisagaku
            ,hakkouKBN
            ,kakuteiKBN
            ,seikyuusyoBangou
            ,seikyuusyohakkoudate
            ,seikyuukakuteidate
            ,jikaikurikosigaku
            ,insertdate
            ,insertTantosya
        ) values (
             _break_seikyuusakiCD
            ,@kaikei_yyyy
            ,_i_seikyuunengetu       -- 受け渡されたパラメータ
            ,_i_simeBi               -- 受け渡されたパラメータ
            ,_i_seikyuuDateFrom
            ,_i_seikyuuDateTo
            ,_O_jikaikurikosigaku  -- ↓ 前残は上記GetBeforeDseikyuuHeadで取得したものをセットする
            ,_break_uriagegaku
            ,_break_hennpinngaku
            ,_break_nebikigaku
            ,_break_nyuukinngaku
            ,_break_syouhizeigaku
            ,_break_syouhizeisagaku
            ,_break_gkmn_uriagegaku
            ,_break_gkmn_hennpinngaku
            ,_break_gkmn_nebikigaku
            ,_break_gkmn_nyuukinngaku
            ,_break_gkmn_syouhizeigaku
            ,_break_gkmn_syouhizeisagaku
            ,0
            ,0
            ,@DenpyouNumber
            ,NULL
            ,NULL
            ,_O_jikaikurikosigaku + _break_uriagegaku + _break_hennpinngaku + _break_nebikigaku - _break_nyuukinngaku + _break_syouhizeigaku + _break_syouhizeisagaku
            ,_i_insertdate
            ,_i_insertTantosya
        );
    END IF;
    CLOSE curSeikyuu;
    -- 請求ヘッダ作成処理終了

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
