DROP PROCEDURE IF EXISTS seikyuuMaeShori_03_update_UriNyuukin;
DELIMITER //
CREATE PROCEDURE seikyuuMaeShori_03_update_UriNyuukin(
    IN _i_seikyuunengetu     integer(6),
    IN _i_simeBi             tinyint,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    /* =============================
       売上・入金データに請求書番号を更新
     ============================ */
    DECLARE _seikyuusakiCD           integer(6) DEFAULT 0;
    DECLARE _kaikei_nendo            integer(4);
    DECLARE _kaikeinendo             integer(4);
    DECLARE _denpyouNO               integer(6);  -- 伝票番号取得時にも使用
    DECLARE _gyouNO                  integer(3);
    DECLARE _dataKBN                   tinyint DEFAULT 0;
    DECLARE _torihikiKBN               tinyint DEFAULT 0;
    DECLARE _seikyuusyoBangou          integer(6) DEFAULT 0;
    DECLARE _aa                        tinyint DEFAULT 0;
    DECLARE done                       INT DEFAULT 0;

    DECLARE curUriNyuukin CURSOR FOR
        (
            select
                 SURI.kaikeiNendo      AS kaikeiNendo
                ,SURI.denpyouNO        AS denpyouNO
                ,SURI.gyouNO           AS gyouNO
                ,MTOK.seikyuusakiCD    AS seikyuusakiCD
                ,SURI.dataKBN          AS dataKBN
                ,SURI.torihikiKBN      AS torihikiKBN
                ,DSHD.seikyuusyoBangou AS seikyuusyoBangou
            from SUriage SURI
            inner join Mtokuisaki as MTOK -- 得意先
            on MTOK.tokuisakiCD   = SURI.tokuisakiCD
            inner join DseikyuuHead as DSHD
            on  DSHD.seikyuusakiCD  = MTOK.seikyuusakiCD
            and DSHD.kaikeiNendo    = _kaikei_nendo
            and DSHD.seikyuunengetu = _i_seikyuunengetu
            and DSHD.simebi         = _i_simeBi
        )
        UNION ALL
        (
            select
                 SNYU.kaikeiNendo      AS kaikeiNendo
                ,SNYU.denpyouNO        AS denpyouNO
                ,SNYU.gyouNO           AS gyouNO
                ,SNYU.seikyuusakiCD    AS seikyuusakiCD
                ,SNYU.dataKBN          AS dataKBN
                ,SNYU.torihikiKBN      AS torihikiKBN
                ,DSHD.seikyuusyoBangou AS seikyuusyoBangou
            from SNyuukinn SNYU
            inner join DseikyuuHead as DSHD
            on  DSHD.seikyuusakiCD  = SNYU.seikyuusakiCD
            and DSHD.kaikeiNendo    = _kaikei_nendo
            and DSHD.seikyuunengetu = _i_seikyuunengetu
            and DSHD.simebi         = _i_simeBi
        )
        ORDER by
                 kaikeiNendo
                ,denpyouNO
                ,gyouNO;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* 管理マスタより会計年度を取得 */
    select kaikei_nendo into _kaikei_nendo from MKanri where kanriCD = 1;

    -- 売上・入金データ更新開始
    OPEN curUriNyuukin;

    REPEAT
    FETCH curUriNyuukin
    INTO _kaikeiNendo, _denpyouNO, _gyouNO, _seikyuusakiCD, _dataKBN, _torihikiKBN, _seikyuusyoBangou;
    IF done = 0 THEN
        IF _dataKBN = 50 THEN
            update Duriage  SET seikyuusyoBangou = _seikyuusyoBangou where kaikeiNendo = _kaikeiNendo and denpyouNO = _denpyouNO and gyouNO = _gyouNO;
        ELSE
            update Dnyuukin SET seikyuusyoBangou = _seikyuusyoBangou where kaikeiNendo = _kaikeiNendo and denpyouNO = _denpyouNO and gyouNO = _gyouNO;
        END IF;
    END IF;
    UNTIL done END REPEAT;

    CLOSE curUriNyuukin;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
