DROP PROCEDURE IF EXISTS seikyuuMaeShoriCreateTable;
DELIMITER //
CREATE PROCEDURE seikyuuMaeShoriCreateTable(
    IN _i_seikyuusakiCD1     integer(6),
    IN _i_seikyuusakiCD2     integer(6),
    IN _i_seikyuusakiCD3     integer(6),
    IN _i_seikyuusakiCD4     integer(6),
    IN _i_seikyuusakiCD5     integer(6),
    IN _i_seikyuusakiCD6     integer(6),
    IN _i_seikyuusakiCD7     integer(6),
    IN _i_seikyuusakiCD8     integer(6),
    IN _i_seikyuusakiCD9     integer(6),
    IN _i_seikyuusakiCD10    integer(6),
    IN _i_seikyuusakiFrom    integer(6),
    IN _i_seikyuusakiTo      integer(6),
    IN _i_seikyuunengetu     integer(6),
    IN _i_seikyuuDateFrom    date,
    IN _i_seikyuuDateTo      date,
    IN _i_simeBi             tinyint,
    IN _i_insertdate         date,
    IN _i_insertTantosya     integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象売上データ
     ========================================================================= */
    drop table if exists SUriage;
    -- create table SUriage
    create temporary table SUriage
        select
            DURI.*
        from DUriage as DURI
        inner join Mtokuisaki as MTOK  -- 得意先
        on DURI.tokuisakiCD = MTOK.tokuisakiCD
        inner join (select seikyuusakiCD,simebi1,simebi2,simebi3 from Mtokuisaki where seikyuusakiCD = tokuisakiCD) as MSEI  -- 請求先
        on MSEI.seikyuusakiCD = MTOK.seikyuusakiCD
        -- 2013/05/25 start
        left outer join (select distinct seikyuusakiCD,kaikeiNendo,seikyuusyoBangou,seikyuunengetu,seikyuukakuteidate from DseikyuuHead) as SKYH
        on  SKYH.seikyuusakiCD = MTOK.seikyuusakiCD
        and SKYH.kaikeiNendo = DURI.kaikeiNendo
        and SKYH.seikyuusyoBangou = DURI.seikyuusyoBangou
        -- 2013/05/25 end

        where
                (_i_seikyuuDateFrom IS NULL or DURI.uriagedate >= _i_seikyuuDateFrom)
            and (_i_seikyuuDateTo IS NULL   or DURI.uriagedate <= _i_seikyuuDateTo)
            and (_i_seikyuusakiFrom = 0 or MSEI.seikyuusakiCD >= _i_seikyuusakiFrom)
            and (_i_seikyuusakiTo = 0   or MSEI.seikyuusakiCD <= _i_seikyuusakiTo)
            and
            (
                (
                        _i_seikyuusakiCD1 = 0 and _i_seikyuusakiCD2 = 0
                    and _i_seikyuusakiCD3 = 0 and _i_seikyuusakiCD4 = 0
                    and _i_seikyuusakiCD5 = 0 and _i_seikyuusakiCD6 = 0
                    and _i_seikyuusakiCD7 = 0 and _i_seikyuusakiCD8 = 0
                    and _i_seikyuusakiCD9 = 0 and _i_seikyuusakiCD10 = 0
                )
                or
                (
                MSEI.seikyuusakiCD in (_i_seikyuusakiCD1,_i_seikyuusakiCD2,_i_seikyuusakiCD3,
                                        _i_seikyuusakiCD4,_i_seikyuusakiCD5,_i_seikyuusakiCD6,
                                        _i_seikyuusakiCD7,_i_seikyuusakiCD8,_i_seikyuusakiCD9,
                                        _i_seikyuusakiCD10)
                )
            )
            and
            (
                   MSEI.simebi1 = _i_simeBi
                or MSEI.simebi2 = _i_simeBi
                or MSEI.simebi3 = _i_simeBi
            )
            and DURI.tyouhaKBN = 0 -- 2013/12/02
            -- 2013/05/25 start
            and SKYH.seikyuukakuteidate IS NULL
            ;
            /*
            and
            -- 請求確定が終わってないもの
            not exists(select
                 SKYH.seikyuusakiCD
                ,SKYH.kaikeiNendo
                ,SKYH.seikyuusyoBangou
                from DseikyuuHead as SKYH
                where
                        SKYH.seikyuusakiCD = MTOK.seikyuusakiCD
                    and SKYH.kaikeiNendo = DURI.kaikeiNendo
                    and SKYH.seikyuunengetu = _i_seikyuunengetu
                    and SKYH.simeBi = _i_simeBi
                    and SKYH.seikyuusyoBangou = DURI.seikyuusyoBangou
                    and SKYH.seikyuukakuteidate IS NOT NULL
                group by
                     SKYH.seikyuusakiCD
                    ,SKYH.kaikeiNendo
                    ,SKYH.seikyuusyoBangou
            );
            */
            -- 2013/05/25 end

    /* =========================================================================
     一時テーブル生成 今回対象入金データ
     ========================================================================= */
    drop table if exists SNyuukinn;
    create temporary table SNyuukinn
        select
                 DNYU.*
        from Dnyuukin as DNYU
        inner join Mtokuisaki as MSEI  -- 請求先
        on DNYU.seikyuusakiCD = MSEI.tokuisakiCD
        -- 2013/05/25 start
        left outer join (select distinct seikyuusakiCD,kaikeiNendo,seikyuusyoBangou,seikyuunengetu,seikyuukakuteidate from DseikyuuHead) as SKYH
        on  SKYH.seikyuusakiCD = MSEI.tokuisakiCD
        and SKYH.kaikeiNendo = DNYU.kaikeiNendo
        and SKYH.seikyuusyoBangou = DNYU.seikyuusyoBangou
        -- 2013/05/25 end
        where
                (_i_seikyuuDateFrom IS NULL or DNYU.nyuukindate >= _i_seikyuuDateFrom)
            and (_i_seikyuuDateTo IS NULL   or DNYU.nyuukindate <= _i_seikyuuDateTo)
            and (_i_seikyuusakiFrom = 0 or DNYU.seikyuusakiCD >= _i_seikyuusakiFrom)
            and (_i_seikyuusakiTo = 0   or DNYU.seikyuusakiCD <= _i_seikyuusakiTo)
            and
            (
                (
                        _i_seikyuusakiCD1 = 0 and _i_seikyuusakiCD2 = 0
                    and _i_seikyuusakiCD3 = 0 and _i_seikyuusakiCD4 = 0
                    and _i_seikyuusakiCD5 = 0 and _i_seikyuusakiCD6 = 0
                    and _i_seikyuusakiCD7 = 0 and _i_seikyuusakiCD8 = 0
                    and _i_seikyuusakiCD9 = 0 and _i_seikyuusakiCD10 = 0
                )
                or
                (
                DNYU.seikyuusakiCD in (_i_seikyuusakiCD1,_i_seikyuusakiCD2,_i_seikyuusakiCD3,
                                        _i_seikyuusakiCD4,_i_seikyuusakiCD5,_i_seikyuusakiCD6,
                                        _i_seikyuusakiCD7,_i_seikyuusakiCD8,_i_seikyuusakiCD9,
                                        _i_seikyuusakiCD10)
                )
            )
            and
            (
                   MSEI.simebi1 = _i_simeBi
                or MSEI.simebi2 = _i_simeBi
                or MSEI.simebi3 = _i_simeBi
            )
            -- 2013/05/25 start
            and SKYH.seikyuukakuteidate IS NULL
            ;
            /*
            and
            -- 請求確定が終わってないもの
            not exists(select
                 SKYH.seikyuusakiCD
                ,SKYH.kaikeiNendo
                ,SKYH.seikyuusyoBangou
                from DseikyuuHead as SKYH
                where
                        SKYH.seikyuusakiCD = MSEI.tokuisakiCD
                    and SKYH.kaikeiNendo = DNYU.kaikeiNendo
                    and SKYH.seikyuunengetu = _i_seikyuunengetu
                    and SKYH.simeBi = _i_simeBi
                    and SKYH.seikyuusyoBangou = DNYU.seikyuusyoBangou
                    and SKYH.seikyuukakuteidate IS NOT NULL
                group by
                     SKYH.seikyuusakiCD
                    ,SKYH.kaikeiNendo
                    ,SKYH.seikyuusyoBangou
            );
            */

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
