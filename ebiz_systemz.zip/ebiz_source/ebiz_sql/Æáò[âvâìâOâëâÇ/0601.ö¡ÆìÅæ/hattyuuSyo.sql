DROP PROCEDURE IF EXISTS prtHattyuuSyo;
DELIMITER //
CREATE PROCEDURE prtHattyuuSyo(
    IN _i_jigyosyoCDfr       integer(2),
    IN _i_jigyosyoCDto       integer(2),
    IN _i_hattyuuDatefr     date,
    IN _i_hattyuuDateto     date,
    IN _i_siiresakiCDfr      integer(6),
    IN _i_siiresakiCDto      integer(6),
    IN _i_kaikeiNendofr      integer(4),
    IN _i_denpyouNOfr        integer(6),
    IN _i_denpyouNOto        integer(6),
    IN _i_CheckSaihakkou     tinyint,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     今回対象データ
     ========================================================================= */
DROP PROCEDURE IF EXISTS prtHattyuuSyo;
DELIMITER //
CREATE PROCEDURE prtHattyuuSyo(
    IN _i_jigyosyoCDfr       integer(2),
    IN _i_jigyosyoCDto       integer(2),
    IN _i_hattyuuDatefr     date,
    IN _i_hattyuuDateto     date,
    IN _i_siiresakiCDfr      integer(6),
    IN _i_siiresakiCDto      integer(6),
    IN _i_kaikeiNendofr      integer(4),
    IN _i_denpyouNOfr        integer(6),
    IN _i_denpyouNOto        integer(6),
    IN _i_CheckSaihakkou     tinyint,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     今回対象データ
     ========================================================================= */
    DROP table IF EXISTS datahattyuuSyo;
    create temporary table datahattyuuSyo
      select
          Dhattyuu.*,
          concat_ws('-', Dhattyuu.kaikeiNendo ,lpad(Dhattyuu.denpyouNO,6,'0')) as hattyuuNo,
          CONCAT(year(Dhattyuu.hattyuudate) , '年',lpad(month(Dhattyuu.hattyuudate),2,'0'), '月',lpad(day(Dhattyuu.hattyuudate),2,'0'), '日' ) as phattyuudate,
          case Msiiresaki.keisyo
            when '' then concat_ws(' ', Dhattyuu.siiresakiNM ,'御中')
            else concat_ws(' ', Dhattyuu.siiresakiNM, Msiiresaki.keisyo)
          end PTsiiresakiNM,
          Djutyuu.ankenNM as ankenNM,
          CONCAT(year(Dhattyuu.kiboudate) , '年',lpad(month(Dhattyuu.kiboudate),2,'0'), '月',lpad(day(Dhattyuu.kiboudate),2,'0'), '日' ) as pkiboudate,
          case Dhattyuu.nounyuusakiNM
            when '' then ''
            else '納入先'
          END pnounyusaki_title,
          case Dhattyuu.nounyusaki_tantousyaNM
            when '' then ''
            else CONCAT(Dhattyuu.nounyusaki_tantousyaNM, ' 殿')
          END pnounyusaki_tantousyaNM,
          Mtani.taniNM as taniNM,
          Mtantosya.jigyosyoCD as kanjigyosyoCD,
          Mjigyosyo.jigyosyoNM as kanjigyosyoNM,
          Mkanri.kaisyaNM as kankaisyaNM,
          Mjigyosyo.postalCD as kanpostalCD,
          Mjigyosyo.address1 as kanaddress1,
          Mjigyosyo.address2 as kanaddress2,
          Mjigyosyo.tel      as kantel,
          Mjigyosyo.fax      as kanfax,
          Msiiresaki.postalCD as PTpostalCD,
          Msiiresaki.address1 as PTaddress1,
          Msiiresaki.address2 as PTaddress2,
          Msiiresaki.siiresaki_tantousyaNM as PTsiiresaki_tantousyaNM

      from Dhattyuu
      left outer join (select distinct kaikeiNendo, denpyouNO, ankenNM from Djutyuu) as Djutyuu
      on   Djutyuu.kaikeiNendo = Dhattyuu.ankenKaikeiNendo
      and  Djutyuu.denpyouNO   = Dhattyuu.ankenjutyuuNO
      left outer join Msiiresaki as Msiiresaki
      on   Msiiresaki.siiresakiCD = Dhattyuu.siiresakiCD
      left outer join Mtani
      on   Mtani.taniCD = Dhattyuu.taniCD
      left outer join Mtantosya as Mtantosya
      on   Mtantosya.tantosyaCD = Msiiresaki.tantosyaCD
      left outer join Mjigyosyo as Mjigyosyo
      on   Mjigyosyo.jigyosyoCD = Mtantosya.jigyosyoCD
      inner join Mkanri
      on   Mkanri.kanriCD = 1

      where 1 = 1
      and  (_i_hattyuuDatefr = "2000-01-01" or Dhattyuu.hattyuudate >= _i_hattyuuDatefr)
      and  (_i_hattyuuDateto = "2000-01-01" or Dhattyuu.hattyuudate <= _i_hattyuuDateto)
      and  (_i_kaikeiNendofr = 0 or Dhattyuu.kaikeiNendo = _i_kaikeiNendofr)
      and  (_i_denpyouNOfr = 0 or Dhattyuu.denpyouNO >= _i_denpyouNOfr)
      and  (_i_denpyouNOto = 0 or Dhattyuu.denpyouNO <= _i_denpyouNOto)
      and  (_i_CheckSaihakkou = 1 or Dhattyuu.DenpyouHakkou = 0)

      order by Dhattyuu.kaikeiNendo, Dhattyuu.denpyouNO, Dhattyuu.gyouNO
      ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
