DROP PROCEDURE IF EXISTS prtJutyuuKakuninSyo;
DELIMITER //
CREATE PROCEDURE prtJutyuuKakuninSyo(
    IN _i_jigyosyoCDfr       integer(2),
    IN _i_jigyosyoCDto       integer(2),
    IN _i_jutyuuDatefr     date,
    IN _i_jutyuuDateto     date,
    IN _i_tokuisakiCDfr      integer(6),
    IN _i_tokuisakiCDto      integer(6),
    IN _i_kaikeiNendofr      integer(4),
    IN _i_denpyouNOfr        integer(6),
    IN _i_denpyouNOto        integer(6),
    IN _i_CheckSaihakkou     tinyint,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     今回対象データ
     ========================================================================= */
    DROP table IF EXISTS datajutyuuKakuninSyo;
    create temporary table datajutyuuKakuninSyo
      select
          Djutyuu.*,
          concat_ws('-', Djutyuu.kaikeiNendo ,lpad(Djutyuu.denpyouNO,6,'0')) as jutyuuNo,
          CONCAT(year(Djutyuu.jutyuudate) , '年',lpad(month(Djutyuu.jutyuudate),2,'0'), '月',lpad(day(Djutyuu.jutyuudate),2,'0'), '日' ) as pjutyuudate,
          case Mtokuisaki.keisyo
            when '' then concat_ws(' ', Djutyuu.tokuisakiNM ,'御中')
            else concat_ws(' ', Djutyuu.tokuisakiNM, Mtokuisaki.keisyo)
          end PTtokuisakiNM,
          case Djutyuu.nounyuusakiNM
            when '' then ''
            else '納入先'
          END pnounyusaki_title,
          CONCAT(Djutyuu.nounyusaki_tantousyaNM, ' 殿') as pnounyusaki_tantousyaNM,
          Mtani.taniNM as taniNM,
          Mtantosya.jigyosyoCD as kanjigyosyoCD,
          Mjigyosyo.jigyosyoNM as kanjigyosyoNM,
          Mkanri.kaisyaNM as kankaisyaNM,
          Mjigyosyo.postalCD as kanpostalCD,
          Mjigyosyo.address1 as kanaddress1,
          Mjigyosyo.address2 as kanaddress2,
          Mjigyosyo.tel      as kantel,
          Mjigyosyo.fax      as kanfax,
          Mtokuisaki.postalCD as PTpostalCD,
          Mtokuisaki.address1 as PTaddress1,
          Mtokuisaki.address2 as PTaddress2,
          Mtokuisaki.tokuisaki_tantousyaNM as PTtokuisaki_tantousyaNM

      from Djutyuu
      left outer join Mtokuisaki as Mtokuisaki
      on   Mtokuisaki.tokuisakiCD = Djutyuu.tokuisakiCD
      left outer join Mtani
      on   Mtani.taniCD = Djutyuu.taniCD
      left outer join Mtantosya as Mtantosya
      on   Mtantosya.tantosyaCD = Mtokuisaki.tantousyaCD
      left outer join Mjigyosyo as Mjigyosyo
      on   Mjigyosyo.jigyosyoCD = Mtantosya.jigyosyoCD
      inner join Mkanri
      on   Mkanri.kanriCD = 1

      where 1 = 1
      and  (_i_jutyuuDatefr = "2000-01-01" or Djutyuu.jutyuudate >= _i_jutyuuDatefr)
      and  (_i_jutyuuDateto = "2000-01-01" or Djutyuu.jutyuudate <= _i_jutyuuDateto)
      and  (_i_kaikeiNendofr = 0 or Djutyuu.kaikeiNendo = _i_kaikeiNendofr)
      and  (_i_denpyouNOfr = 0 or Djutyuu.denpyouNO >= _i_denpyouNOfr)
      and  (_i_denpyouNOto = 0 or Djutyuu.denpyouNO <= _i_denpyouNOto)
      and  (_i_CheckSaihakkou = 1 or Djutyuu.KakuninSyoHakkou = 0)

      order by Djutyuu.kaikeiNendo, Djutyuu.denpyouNO, Djutyuu.gyouNO
      ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
