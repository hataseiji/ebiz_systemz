DROP PROCEDURE IF EXISTS prtSiharai;
DELIMITER //
CREATE PROCEDURE prtSiharai(
    IN _i_jigyosyoCDfr       integer(2),
    IN _i_jigyosyoCDto       integer(2),
    IN _i_siiresakiCDfr      integer(6),
    IN _i_siiresakiCDto      integer(6),
    IN _i_kaikeiNendo        integer(4),
    IN _i_simebi             integer(6),
    IN _i_saiHakkou          integer(1),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    drop table if exists SSiharai;
    create temporary table SSiharai
      (select 1 as No
          ,DsiharaiHead.siharaisyoBangou as siharaisyoBangou1
          ,DsiharaiHead.siharaisyoBangou as siharaisyoBangou2
          ,DsiharaiHead.siharaisyoBangou as siharaisyoBangou3
          ,DsiharaiHead.siharaisakiCD
          ,CONCAT(Msiiresaki.siiresakiNM, ' ', Msiiresaki.keisyo) as siiresakiNM
          ,Msiiresaki.postalCD
          ,Msiiresaki.address1
          ,Msiiresaki.address2
          ,Msiiresaki.zeisansyutuKBN
          ,DsiharaiHead.ZENZAN
          ,DsiharaiHead.gkmn_siiregaku as siiregaku
          ,DsiharaiHead.gkmn_hennpinngaku as hennpinngaku
          ,DsiharaiHead.gkmn_nebikigaku as nebikigaku
          ,DsiharaiHead.gkmn_siharaigaku as siharaigaku
          ,DsiharaiHead.gkmn_syouhizeigaku + DsiharaiHead.gkmn_syouhizeisagaku as syouhizei
          ,DsiharaiHead.jikaikurikosigaku
          ,CONCAT(year(Dsiire.siiredate) , '/',lpad(month(Dsiire.siiredate),2,'0'), '/',lpad(day(Dsiire.siiredate),2,'0'), '' ) as denpyouDate
          ,concat_ws('-', Dsiire.kaikeiNendo ,lpad(Dsiire.denpyouNO,6,'0')) as denpyouNo
          ,Dsiire.gyouNO
          ,Dsiire.syouhinCD
          ,Dsiire.syouhinNM
          ,Dsiire.suryou
          ,Dsiire.taniCD
          ,Mtani.taniNM as taniNM
          ,Dsiire.tanka
          ,Dsiire.kingaku
          ,Dsiire.hontai_kingaku
          /* 消費税の差額は1行目で調整する
             消費税の印字は伝票入力時と同様にする。つまり内税商品では金額に消費税が含まれ消費税額はゼロとなる。鏡も同様。 */
          ,case Dsiire.gyouNO
            when 1 then DUR2.kaikei_syouhizei + COALESCE(Dsyouhizei.kaikei_syouhizei, 0)
            else DUR2.kaikei_syouhizei
          end meisai_syouhizei    -- 明細印字用消費税
          ,Mjigyosyo.jigyosyoNM as jigyosyoNM
          ,Mkanri.kaisyaNM as kankaisyaNM
          ,Mjigyosyo.postalCD as kanpostalCD
          ,Mjigyosyo.address1 as kanaddress1
          ,Mjigyosyo.address2 as kanaddress2
          ,Mjigyosyo.tel as kantel
          ,Mjigyosyo.fax as kanfax
      from DsiharaiHead
      left outer join Msiiresaki
      on Msiiresaki.siiresakiCD = DsiharaiHead.siharaisakiCD
      inner join Dsiire as Dsiire
      on Dsiire.siharaisyoBangou = DsiharaiHead.siharaisyoBangou
      left outer join Dsiire as Dsyouhizei
      on Dsyouhizei.kaikeiNendo = Dsiire.kaikeiNendo
      and Dsyouhizei.denpyouNO = Dsiire.denpyouNO
      and Dsyouhizei.siireKBN = 80
      left outer join Mtani
      on Mtani.taniCD = Dsiire.taniCD
      left outer join
      (select
            Dsiire.kaikeiNendo
           ,Dsiire.denpyouNO
           ,Dsiire.gyouNO
           ,case Msyouhin.sotoutiKBN
               when  1 then 0
               else  Dsiire.kaikei_syouhizei
            end kaikei_syouhizei
       from Dsiire
       inner join Msyouhin
       on Msyouhin.syouhinCD =   Dsiire.syouhinCD
      ) DUR2
      on  DUR2.kaikeiNendo = Dsiire.kaikeiNendo
      and DUR2.denpyouNO   = Dsiire.denpyouNO
      and DUR2.gyouNO      = Dsiire.gyouNO

      left outer join Mtantosya
      on   Mtantosya.tantosyaCD = Msiiresaki.tantosyaCD
      left outer join Mjigyosyo
      on   Mjigyosyo.jigyosyoCD = Mtantosya.jigyosyoCD
      inner join Mkanri
      on   Mkanri.kanriCD = 1
      where 1 = 1
        and (_i_jigyosyoCDfr = 0 or Mtantosya.jigyosyoCD >= _i_jigyosyoCDfr)
        and (_i_jigyosyoCDto = 0 or Mtantosya.jigyosyoCD <= _i_jigyosyoCDto)
        and (_i_siiresakiCDfr = 0 or DsiharaiHead.siharaisakiCD >= _i_siiresakiCDfr)
        and (_i_siiresakiCDto = 0 or DsiharaiHead.siharaisakiCD <= _i_siiresakiCDto)
      and DsiharaiHead.siharainengetu = _i_kaikeiNendo
      and DsiharaiHead.simebi = _i_simebi
      and Dsiire.siireKBN <> 80
      and Msiiresaki.siharaiannaiKBN = 0
      and (_i_saiHakkou = 1 or DsiharaiHead.hakkouKBN = 0)
      )

      UNION ALL

      (select 2 as No
          ,DsiharaiHead.siharaisyoBangou as siharaisyoBangou1
          ,DsiharaiHead.siharaisyoBangou as siharaisyoBangou2
          ,DsiharaiHead.siharaisyoBangou as siharaisyoBangou3
          ,DsiharaiHead.siharaisakiCD
          ,CONCAT(Msiiresaki.siiresakiNM, ' ', Msiiresaki.keisyo) as siiresakiNM
          ,Msiiresaki.postalCD
          ,Msiiresaki.address1
          ,Msiiresaki.address2
          ,Msiiresaki.zeisansyutuKBN
          ,DsiharaiHead.ZENZAN
          ,DsiharaiHead.gkmn_siiregaku as siiregaku
          ,DsiharaiHead.gkmn_hennpinngaku as hennpinngaku
          ,DsiharaiHead.gkmn_nebikigaku as nebikigaku
          ,DsiharaiHead.gkmn_siharaigaku as siharaigaku
          ,DsiharaiHead.gkmn_syouhizeigaku + DsiharaiHead.gkmn_syouhizeisagaku as syouhizei
          ,DsiharaiHead.jikaikurikosigaku
          ,CONCAT(year(Dsiharai.siharaidate) , '/',lpad(month(Dsiharai.siharaidate),2,'0'), '/',lpad(day(Dsiharai.siharaidate),2,'0'), '' ) as denpyouDate
          ,concat_ws('-', Dsiharai.kaikeiNendo ,lpad(Dsiharai.denpyouNO,6,'0')) as denpyouNo
          ,Dsiharai.gyouNO
          ,'' as syouhinCD
          ,'＊支払' as syouhinNM
          ,'' as suryou
          ,'' as taniCD
          ,'' as taniNM
          ,'' as tanka
          ,Dsiharai.kingaku
          ,Dsiharai.hontai_kingaku
          ,'' as meisai_syouhizei
          ,Mjigyosyo.jigyosyoNM as jigyosyoNM
          ,Mkanri.kaisyaNM as kankaisyaNM
          ,Mjigyosyo.postalCD as kanpostalCD
          ,Mjigyosyo.address1 as kanaddress1
          ,Mjigyosyo.address2 as kanaddress2
          ,Mjigyosyo.tel as kantel
          ,Mjigyosyo.fax as kanfax
      from DsiharaiHead
      left outer join Msiiresaki
      on Msiiresaki.siiresakiCD = DsiharaiHead.siharaisakiCD
      inner join Dsiharai as Dsiharai
      on Dsiharai.siharaisyoBangou = DsiharaiHead.siharaisyoBangou
      left outer join Mtantosya
      on   Mtantosya.tantosyaCD = Msiiresaki.tantosyaCD
      left outer join Mjigyosyo
      on   Mjigyosyo.jigyosyoCD = Mtantosya.jigyosyoCD
      inner join Mkanri
      on   Mkanri.kanriCD = 1
      where 1 = 1
        and (_i_jigyosyoCDfr = 0 or Mtantosya.jigyosyoCD >= _i_jigyosyoCDfr)
        and (_i_jigyosyoCDto = 0 or Mtantosya.jigyosyoCD <= _i_jigyosyoCDto)
        and (_i_siiresakiCDfr = 0 or DsiharaiHead.siharaisakiCD >= _i_siiresakiCDfr)
        and (_i_siiresakiCDto = 0 or DsiharaiHead.siharaisakiCD <= _i_siiresakiCDto)
        and DsiharaiHead.siharainengetu = _i_kaikeiNendo
        and DsiharaiHead.simebi = _i_simebi
        and Msiiresaki.siharaiannaiKBN = 0
        and (_i_saiHakkou = 1 or DsiharaiHead.hakkouKBN = 0)
      )

      Order By siharaisyoBangou1, siharaisyoBangou2, siharaisyoBangou3, siharaisakiCD, denpyouDate, denpyouNo, gyouNO;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
