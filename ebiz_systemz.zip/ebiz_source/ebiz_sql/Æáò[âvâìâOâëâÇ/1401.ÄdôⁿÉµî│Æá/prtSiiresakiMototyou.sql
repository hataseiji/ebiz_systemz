DROP PROCEDURE IF EXISTS prtSiiresakiMototyou;
DELIMITER //
CREATE PROCEDURE prtSiiresakiMototyou(
    IN _i_siiresakiCDfr      integer(6),
    IN _i_siiresakiCDto      integer(6),
    IN _i_kaikeiNendo          integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    drop table if exists SSiiresakiMototyou;
    create temporary table SSiiresakiMototyou
    (select
      1 as No ,
      Dsiirelog.siiresakiCD         as siiresakiCD ,
      Msiiresaki.siiresakiNM        as siiresakiNM ,
      Dkaikakezan.zan               as ZENZAN ,
      Dkaikakezan.siiregaku         as siiregaku ,
      Dkaikakezan.hennpinngaku      as hennpinngaku ,
      Dkaikakezan.nebikigaku        as nebikigaku ,
      Dkaikakezan.siharaigaku       as siharaigaku ,
      Dkaikakezan.syouhizeigaku     as syouhizei ,
      (Dkaikakezan.zan + Dkaikakezan.siiregaku + Dkaikakezan.hennpinngaku + Dkaikakezan.nebikigaku - Dkaikakezan.siharaigaku + Dkaikakezan.syouhizeigaku)
 as jikaikurikosigaku ,

      CONCAT(year(Dsiirelog.siiredate) , '/',lpad(month(Dsiirelog.siiredate),2,'0'), '/',lpad(day(Dsiirelog.siiredate),2,'0'), '' ) as denpyouDate ,
      concat_ws('-', Dsiirelog.kaikeiNendo ,lpad(Dsiirelog.denpyouNO,6,'0')) as denpyouNo ,
      Dsiirelog.gyouNO              as gyouNO ,
      Dsiirelog.seq                 as seq ,
      Storihiki.torihikiNM          as torihikiNM ,
      Dsiirelog.syouhinCD           as syouhinCD ,
      Dsiirelog.syouhinNM           as syouhinNM ,
      Dsiirelog.suryou              as suryou ,
      Dsiirelog.taniCD              as taniCD ,
      Mtani.taniNM                  as taniNM ,
      Dsiirelog.tanka               as tanka ,
      Dsiirelog.kingaku             as kingaku ,
      Dsiirelog.hontai_kingaku      as hontai_kingaku ,
      Dsiirelog.kaikei_syouhizei    as kaikei_syouhizei ,
      0                             as msiharaigaku ,
      0 as zandaka ,
      0 as zero
      from Dsiirelog
      inner join Dkaikakezan
        on Dkaikakezan.siiresakiCD = Dsiirelog.siiresakiCD
        and Dkaikakezan.keijounengetu = Dsiirelog.keijounengetu
      left outer join Msiiresaki
        on Msiiresaki.siiresakiCD = Dkaikakezan.siiresakiCD
      left outer join Mtani
        on Mtani.taniCD = Dsiirelog.taniCD
      inner join Storihiki as Storihiki
        on   Storihiki.dataKBN = Dsiirelog.dataKBN
        and  Storihiki.torihikiKBN = Dsiirelog.torihikiKBN
        inner join Mkanri
        on  Mkanri.kanriCD = 1
      where 1 = 1
      and (_i_siiresakiCDfr = 0 or Dkaikakezan.siiresakiCD >= _i_siiresakiCDfr)
      and (_i_siiresakiCDto = 0 or Dkaikakezan.siiresakiCD <= _i_siiresakiCDto)
      and Dsiirelog.keijounengetu = _i_kaikeiNendo
      and (Dsiirelog.hontai_kingaku <> 0 or Dsiirelog.kaikei_syouhizei <> 0)
      )
    UNION ALL
    (select 2 as No ,
      Dsiharailog.siharaisakiCD    as siiresakiCD ,
      Msiiresaki.siiresakiNM       as siiresakiNM ,
      Dkaikakezan.zan              as ZENZAN ,
      Dkaikakezan.siiregaku        as siiregaku ,
      Dkaikakezan.hennpinngaku     as hennpinngaku ,
      Dkaikakezan.nebikigaku       as nebikigaku ,
      Dkaikakezan.siharaigaku      as siharaigaku ,
      Dkaikakezan.syouhizeigaku    as syouhizei ,
      (Dkaikakezan.zan + Dkaikakezan.siiregaku + Dkaikakezan.hennpinngaku + Dkaikakezan.nebikigaku - Dkaikakezan.siharaigaku + Dkaikakezan.syouhizeigaku)
 as jikaikurikosigaku ,

      CONCAT(year(Dsiharailog.siharaidate) , '/',lpad(month(Dsiharailog.siharaidate),2,'0'), '/',lpad(day(Dsiharailog.siharaidate),2,'0'), '' ) as denpyouDate ,
      concat_ws('-', Dsiharailog.kaikeiNendo ,lpad(Dsiharailog.denpyouNO,6,'0')) as denpyouNo ,
      Dsiharailog.gyouNO           as gyouNO ,
      Dsiharailog.seq              as seq ,
      Storihiki.torihikiNM         as torihikiNM,
      ''                           as syouhinCD     ,
      '＊支払'                      as syouhinNM ,
      0                            as suryou ,
      0                            as taniCD ,
      ''                           as taniNM ,
      0                            as tanka  ,
      0                            as kingaku ,
      0                            as hontai_kingaku ,
      0                            as kaikei_syouhizei ,
      Dsiharailog.kingaku          as msiharaigaku ,
      0                            as zandaka ,
      0 as zero
      from Dsiharailog
      inner join Dkaikakezan
        on Dkaikakezan.siiresakiCD = Dsiharailog.siharaisakiCD
        and Dkaikakezan.keijounengetu = Dsiharailog.keijounengetu
      left outer join Msiiresaki
        on Msiiresaki.siiresakiCD = Dsiharailog.siharaisakiCD
      inner join Storihiki as Storihiki
        on   Storihiki.dataKBN = Dsiharailog.dataKBN
        and  Storihiki.torihikiKBN = Dsiharailog.torihikiKBN
        inner join Mkanri
        on   Mkanri.kanriCD = 1
      where 1 = 1
      and (_i_siiresakiCDfr = 0 or Dsiharailog.siharaisakiCD >= _i_siiresakiCDfr)
      and (_i_siiresakiCDto = 0 or Dsiharailog.siharaisakiCD <= _i_siiresakiCDto)
      and Dsiharailog.keijounengetu = _i_kaikeiNendo
      and Dsiharailog.kingaku <> 0
      )
    Order By siiresakiCD, denpyouDate, denpyouNo, gyouNO, seq ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
