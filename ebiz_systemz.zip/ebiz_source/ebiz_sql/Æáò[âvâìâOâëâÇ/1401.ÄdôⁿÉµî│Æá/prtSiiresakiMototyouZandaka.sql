DROP PROCEDURE IF EXISTS prtSiiresakiMototyouZandaka;
DELIMITER //
CREATE PROCEDURE prtSiiresakiMototyouZandaka(
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg          varchar(256);
    DECLARE _Result            Boolean;

    DECLARE _No                integer(2) DEFAULT 0;
    DECLARE _siiresakiCD       integer(6) DEFAULT 0;
    DECLARE _denpyouNo         varchar(11);
    DECLARE _gyouNO            integer(6) DEFAULT 0;
    DECLARE _seq               integer(6) DEFAULT 0;
    DECLARE _denpyouDate       varchar(20);
    DECLARE _zenzan            decimal(10) DEFAULT 0;
    DECLARE _hontai_kingaku    decimal(10) DEFAULT 0;
    DECLARE _kaikei_syouhizei  decimal(10) DEFAULT 0;
    DECLARE _msiharaigaku      decimal(10) DEFAULT 0;

    DECLARE _breakSiiresakiCD  integer(6) DEFAULT 0;
    DECLARE _zandaka           decimal(10) DEFAULT 0;
    DECLARE done               INT DEFAULT 0;
    DECLARE _countRanking      integer(4) DEFAULT 0;
    DECLARE _updRanking        integer(4) DEFAULT 0;

    DECLARE curZandaka CURSOR FOR
        select
           No
          ,siiresakiCD
          ,denpyouNo
          ,gyouNO
          ,seq
          ,denpyouDate
          ,ZENZAN
          ,hontai_kingaku
          ,kaikei_syouhizei
          ,msiharaigaku
        from SSiiresakiMototyou
        Order By siiresakiCD, denpyouDate, denpyouNo, gyouNO, seq
        ;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     残高算出
     ========================================================================= */
    set _breakSiiresakiCD = 0;
    OPEN curZandaka;

    REPEAT
    FETCH curZandaka
    INTO _No, _siiresakiCD, _denpyouNo, _gyouNO, _seq, _denpyouDate, _zenzan, _hontai_kingaku, _kaikei_syouhizei, _msiharaigaku;

    IF done = 0 THEN
        if _siiresakiCD <> _breakSiiresakiCD then
            set _zandaka = _zenzan;
        end if;
        if _No = 1 then
            set _zandaka = _zandaka + _hontai_kingaku;
            set _zandaka = _zandaka + _kaikei_syouhizei;
        else
            set _zandaka = _zandaka - _msiharaigaku;
        end if;

        set _breakSiiresakiCD = _siiresakiCD;

        update SSiiresakiMototyou
            set zandaka = _zandaka
            where SSiiresakiMototyou.No = _No
            and   SSiiresakiMototyou.seq = _seq
        ;
    END IF;
    UNTIL done END REPEAT;

    CLOSE curZandaka;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
