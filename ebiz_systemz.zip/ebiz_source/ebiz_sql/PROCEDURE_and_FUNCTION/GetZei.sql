DROP PROCEDURE IF EXISTS GetZei;
DELIMITER //
CREATE PROCEDURE GetZei(
    IN  _I_dataKBN                  integer(4),
    IN  _I_date                     date,
    IN  _I_torihikisakiCD           integer(6),
    IN  _I_zeikomiKingaku           decimal(10),
    IN  _I_zeinukiKingaku           decimal(10),
    OUT _O_utiZeinukigaku           decimal(10),
    OUT _O_sotoZei                  decimal(10),
    OUT _O_utiZei                   decimal(10)
)
BEGIN
/*
    消費税の計算をします。
    _I_dataKBN          50:売上入金/80:仕入支払
    _I_date             消費税算出基準日(売上計上日)
    _I_torihikisakiCD   請求先CDまたは支払先CD
    _I_zeikomiKingaku   これから内税を算出
    _I_zeinukiKingaku   これから外税を算出
    _O_utiZeinukigaku   内税の税抜額が返される
    _O_sotoZei          外税の消費税額が返される
    _O_utiZei           内税の消費税額が返される
    _zeisansyutuKBN     0:明細単位 1:伝票単位 2:請求時一括 3:計算しない
    _zeihasuuKBN        0:四捨五入 1:切捨て 2:切上げ
    内税の算出方法         内税額 = 税込額 - (税込額 / 1.05)
*/

    DECLARE _zeisansyutuKBN  tinyint(1);
    DECLARE _zeihasuuKBN     tinyint(1);
    DECLARE _zeirituKBN      tinyint(1);
    DECLARE _tekiyoudate     date;
    DECLARE _newzeiritu      decimal(4,3);  -- 採用された税率

    /* 消費税率取得 */
    drop table if exists zeirituMain;
    create temporary table zeirituMain
        SELECT sub.zeirituKBN
                ,MAX(sub.tekiyoudate) AS tekiyoudate
        FROM Szei sub
        WHERE sub.tekiyoudate <= _I_date
        GROUP BY sub.zeirituKBN;

    SELECT  SZEI.zeirituKBN, SZEI.tekiyoudate, SZEI.newzeiritu into _zeirituKBN, _tekiyoudate, _newzeiritu
    FROM Szei AS SZEI
    INNER JOIN zeirituMain AS main
    ON  SZEI.zeirituKBN  = main.zeirituKBN
    AND SZEI.tekiyoudate = main.tekiyoudate;

    /* 得意先・仕入先マスタより税算出区分・税端数区分を取得 */
    IF _I_dataKBN = 50 THEN
        select zeisansyutuKBN, zeihasuuKBN into _zeisansyutuKBN, _zeihasuuKBN from Mtokuisaki where tokuisakiCD = _I_torihikisakiCD;
    ELSEIF _I_dataKBN = 80 THEN
        select zeisansyutuKBN, zeihasuuKBN into _zeisansyutuKBN, _zeihasuuKBN from Msiiresaki where siiresakiCD = _I_torihikisakiCD;
    END IF;

    SET _O_sotoZei        = 0;
    SET _O_utiZei         = 0;
    SET _O_utiZeinukigaku = 0;

    SET _O_sotoZei        = marume(_zeihasuuKBN, 0, _I_zeinukiKingaku * _newzeiritu);
    SET _O_utiZei         = marume(_zeihasuuKBN, 0, (_I_zeikomiKingaku - (_I_zeikomiKingaku / (1 + _newzeiritu))));
    SET _O_utiZeinukigaku = _I_zeikomiKingaku - _O_utiZei;
END;
//
DELIMITER ;
