DROP PROCEDURE IF EXISTS GetYuukouZaiko;
DELIMITER //
CREATE PROCEDURE GetYuukouZaiko(
    IN  _I_soukoCD           integer(6),
    IN  _I_syouhinCD         varchar(10),
    OUT _O_zeinukiKingaku    decimal(12,3)
)
BEGIN
/*
    有効在庫数を求めます。
*/
    DECLARE _kaikei_yyyymm            integer;      /* 処理年月 */
    DECLARE _zengetumatu_zaikosu      decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_uriagesu         decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_syukkosu         decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_sonotasyukkosu   decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_tanaorosigen     decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_siiresu          decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_nyuukosu         decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_sonotanyuukosu   decimal(12,3) DEFAULT 0;
    DECLARE _tougetu_tanaorosizou     decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_uriagesu        decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_syukkosu        decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_sonotasyukkosu  decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_tanaorosigen    decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_siiresu         decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_nyuukosu        decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_sonotanyuukosu  decimal(12,3) DEFAULT 0;
    DECLARE _yokugetu_tanaorosizou    decimal(12,3) DEFAULT 0;

    /* 処理年月の取得 */
    select kaikei_yyyymm into _kaikei_yyyymm from Mkanri where kanriCD=1;
    if _kaikei_yyyymm is NULL then
        set _kaikei_yyyymm=200104;
    end if;

    set _O_zeinukiKingaku        = 0;

    /* 在庫データの取得 */
    select 
        zengetumatu_zaikosu,
        tougetu_uriagesu,
        tougetu_syukkosu,
        tougetu_sonotasyukkosu,
        tougetu_tanaorosigen,
        tougetu_siiresu,
        tougetu_nyuukosu,
        tougetu_sonotanyuukosu,
        tougetu_tanaorosizou,
        yokugetu_uriagesu,
        yokugetu_syukkosu,
        yokugetu_sonotasyukkosu,
        yokugetu_tanaorosigen,
        yokugetu_siiresu,
        yokugetu_nyuukosu,
        yokugetu_sonotanyuukosu,
        yokugetu_tanaorosizou
        into
        _zengetumatu_zaikosu,
        _tougetu_uriagesu,
        _tougetu_syukkosu,
        _tougetu_sonotasyukkosu,
        _tougetu_tanaorosigen,
        _tougetu_siiresu,
        _tougetu_nyuukosu,
        _tougetu_sonotanyuukosu,
        _tougetu_tanaorosizou,
        _yokugetu_uriagesu,
        _yokugetu_syukkosu,
        _yokugetu_sonotasyukkosu,
        _yokugetu_tanaorosigen,
        _yokugetu_siiresu,
        _yokugetu_nyuukosu,
        _yokugetu_sonotanyuukosu,
        _yokugetu_tanaorosizou
    from Dzaiko 
    where   Dzaiko.soukoCD       = _I_soukoCD
        and Dzaiko.syouhinCD     = _I_syouhinCD
        and Dzaiko.keijounengetu = _kaikei_yyyymm;

    set _O_zeinukiKingaku = 
                _zengetumatu_zaikosu
            -   _tougetu_uriagesu
            -   _tougetu_syukkosu
            -   _tougetu_sonotasyukkosu
            -   _tougetu_tanaorosigen
            +   _tougetu_siiresu
            +   _tougetu_nyuukosu
            +   _tougetu_sonotanyuukosu
            +   _tougetu_tanaorosizou
            -   _yokugetu_uriagesu
            -   _yokugetu_syukkosu
            -   _yokugetu_sonotasyukkosu
            -   _yokugetu_tanaorosigen
            +   _yokugetu_siiresu
            +   _yokugetu_nyuukosu
            +   _yokugetu_sonotanyuukosu
            +   _yokugetu_tanaorosizou;
END;
//
DELIMITER ;
