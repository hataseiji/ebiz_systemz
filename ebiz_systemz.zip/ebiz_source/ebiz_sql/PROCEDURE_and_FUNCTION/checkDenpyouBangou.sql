DROP PROCEDURE IF EXISTS checkDenpyouBangou;
DELIMITER //
CREATE PROCEDURE checkDenpyouBangou(
    IN _i_dataKBN            integer(3),
    IN _i_kaikeiNendo        integer(4),
    IN _i_denpyouBangou      integer(6),
    IN _i_programID          varchar(128),
    IN _i_tanmatuID          varchar(128),
    IN _i_insertdate         datetime,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
    OUT _o_dataKBN           Boolean
) returns integer
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;
    DECLARE _count           integer;
    DECLARE _dataKBN         integer;
    DECLARE done             INT DEFAULT 0;
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;


    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     排他処理起動チェック
     請求処理・支払処理・月次更新中は他のプログラムの投入は不可
     ========================================================================= */
    DECLARE curHaitaDataKBN CURSOR FOR
        select dataKBN from SdenpyouHaita where dataKBN >= 120;
    if _i_dataKBN <> 120 and _i_dataKBN <> 130 and _i_dataKBN <> 140 THEN

        OPEN curHaitaDataKBN;

        REPEAT
        FETCH curHaitaDataKBN INTO _dataKBN;
        IF done = 0 THEN
            if _dataKBN = 120 THEN
                retuen 120;
            end if
            if _dataKBN = 130 THEN
                retuen 130;
            end if
            if _dataKBN = 140 THEN
                retuen 140;
            end if
            SET done = 1;
        END IF;
        UNTIL done END REPEAT;
        CLOSE curHaitaDataKBN;
    else
        select count(*) into _count from SdenpyouHaita;
    end if;



