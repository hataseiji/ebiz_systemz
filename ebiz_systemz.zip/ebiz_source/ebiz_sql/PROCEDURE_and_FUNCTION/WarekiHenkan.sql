DROP PROCEDURE IF EXISTS WarekiHenkan;
DELIMITER //
create PROCEDURE WarekiHenkan(
    IN  _I_date         date,
    OUT _O_gengou       varchar(4),
    OUT _O_wareki_nenn  tinyint(2),
    OUT _O_wareki_tuki  tinyint(2),
    OUT _O_wareki_hi    tinyint(2)
)
BEGIN
/*
    西暦から和暦への変換
*/
    DECLARE _seireki_nenn   smallint;

    DECLARE gengou_mei varchar(6);
    DECLARE kaishi_nen smallint;
    DECLARE kijun_nen smallint;

    SET _seireki_nenn  = YEAR(_I_date);
    SET _O_wareki_tuki = MONTH(_I_date);
    SET _O_wareki_hi   = DAYOFMONTH(_I_date);

    if (_seireki_nenn <= 1926) then
        set _O_gengou = '大正', kaishi_nen = 1912, kijun_nen = 1;
    elseif (_seireki_nenn <= 1988) then
        set _O_gengou = '昭和', kaishi_nen = 1927, kijun_nen = 2;
    else
        set _O_gengou = '平成', kaishi_nen = 1989, kijun_nen = 1;
    end if;
    SET _O_wareki_nenn = _seireki_nenn - kaishi_nen + kijun_nen;
END;
//
DELIMITER ;
