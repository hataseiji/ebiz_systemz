DROP PROCEDURE IF EXISTS GetUTanka;
DELIMITER //
CREATE PROCEDURE GetUTanka(
    IN  _I_tokuisakiCD              integer(6),
    IN  _I_syouhinCD                varchar(10),
    IN  _I_date                     date,
    OUT _O_tanka                    decimal(10)
)
BEGIN

    DECLARE _tokuisakiCD     integer(6);
    DECLARE _syouhinCD       varchar(10);
    DECLARE _tekiyoudate     date;
    DECLARE _tanka           decimal(10);

    /*  得意先別商品別単価取得 */
    drop table if exists TUSTanka;
    create temporary table TUSTanka
        SELECT TUST.tokuisakiCD, TUST.syouhinCD
                ,MAX(TUST.tekiyoudate) AS tekiyoudate
        FROM MTokuisakiUtanka TUST
        WHERE TUST.tekiyoudate <= _I_date
        GROUP BY TUST.tokuisakiCD,TUST.syouhinCD;

    SELECT
        main.tokuisakiCD, main.syouhinCD, main.tekiyoudate, main.tanka
        into
        _tokuisakiCD    , _syouhinCD    , _tekiyoudate    , _tanka
    FROM MTokuisakiUtanka AS main
    INNER JOIN TUSTanka   AS sub
    ON  main.tokuisakiCD  = sub.tokuisakiCD
    AND main.syouhinCD    = sub.syouhinCD
    AND main.tekiyoudate  = sub.tekiyoudate
    where main.tokuisakiCD = _I_tokuisakiCD
    AND   main.syouhinCD   = _I_syouhinCD;

    IF _tanka IS NULL THEN  /* 取得できなかった場合は商品別単価を取得する */
        /* 商品別単価取得 */
        drop table if exists USTanka;
        create temporary table USTanka
            SELECT UST.syouhinCD
                    ,MAX(UST.tekiyoudate) AS tekiyoudate
            FROM MSyouhinUtanka UST
            WHERE UST.tekiyoudate <= _I_date
            GROUP BY UST.syouhinCD;

        SELECT
            main.syouhinCD, main.tekiyoudate, main.tanka
            into
            _syouhinCD    , _tekiyoudate    , _tanka
        FROM MSyouhinUtanka AS main
        INNER JOIN USTanka  AS sub
        ON  main.syouhinCD  = sub.syouhinCD
        AND main.tekiyoudate = sub.tekiyoudate
        where main.syouhinCD = _I_syouhinCD;
    END IF;

    IF _tanka IS NULL THEN
        SET _O_tanka  = 0;
    ELSE
        SET _O_tanka  = _tanka;
    END IF;
END;
//
DELIMITER ;
