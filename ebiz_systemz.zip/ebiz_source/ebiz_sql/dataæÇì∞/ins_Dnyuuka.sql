DROP PROCEDURE IF EXISTS ins_Dnyuuka;
DELIMITER //
CREATE PROCEDURE ins_Dnyuuka (
    IN _i_kaikeiNendo          integer(4),
    IN _i_denpyouNO         integer(6),
    IN _i_gyouNO            integer(3),
    IN _i_seq               integer(6),
    IN _i_akakuro           tinyint(1),
    IN _i_yuukou            tinyint(1),
    IN _i_keijounengetu     date,
    IN _i_dataKBN           tinyint(2),
    IN _i_torihikiKBN       tinyint(2),
    IN _i_nyuukaKBN         tinyint(2),
    IN _i_hattyuuKaikeiNendo integer(4),
    IN _i_hattyuuNO         integer(6),
    IN _i_hattyuuGyouNO     integer(3),
    IN _i_siireKaikeiNendo  integer(4),
    IN _i_siireNO           integer(6),
    IN _i_siireGyouNO       integer(3),
    IN _i_nyuukadate        date,
    IN _i_soukoCD           integer(6),
    IN _i_siiresakiCD       integer(6),
    IN _i_siiresakiNM       varchar(40),
    IN _i_denpyou_tekiyou1  varchar(40),
    IN _i_denpyou_tekiyou2  varchar(40),
    IN _i_mnyuukaKBN        tinyint(2),
    IN _i_syouhinCD         varchar(10),
    IN _i_syouhinNM         varchar(40),
    IN _i_hattyuu_suryou    decimal(10,3),
    IN _i_suryou            decimal(10,3),
    IN _i_taniCD            tinyint(2),
    IN _i_tanka             decimal(8),
    IN _i_kingaku           decimal(10),
    IN _i_meisai_tekiyou    varchar(40),
    IN _i_hontai_kingaku    decimal(10),
    IN _i_syouhizei         decimal(10),
    IN _i_updDataKBN        tinyint(2),
    IN _i_insertdate        datetime,
    IN _i_insertTantosya    integer(6),
    OUT _o_ErrorMsg         varchar(256),
    OUT _o_Result           Boolean
)
BEGIN
    DECLARE _counter integer;

    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    select count(*) INTO _counter from Dnyuuka where kaikeiNendo = _i_kaikeiNendo and denpyouNO = _i_denpyouNO and gyouNO = _i_gyouNO;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Dnyuuka (
            kaikeiNendo,
            denpyouNO,
            gyouNO,
            seq,
            akakuro,
            yuukou,
            keijounengetu,
            dataKBN,
            torihikiKBN,
            nyuukaKBN,
            hattyuuKaikeiNendo,
            hattyuuNO,
            hattyuu_gyouNO,
            siireKaikeiNendo,
            siireNO,
            siire_gyouNO,
            nyuukadate,
            soukoCD,
            siiresakiCD,
            siiresakiNM,
            denpyou_tekiyou1,
            denpyou_tekiyou2,
            mnyuukaKBN,
            syouhinCD,
            syouhinNM,
            hattyuu_suryou,
            suryou,
            taniCD,
            tanka,
            kingaku,
            meisai_tekiyou,
            hontai_kingaku,
            syouhizei,
            DenpyouHakkou,
            updDataKBN,
            insertdate,
            insertTantosya
        )
        values
        (
            _i_kaikeiNendo,
            _i_denpyouNO,
            _i_gyouNO,
            _i_seq,
            _i_akakuro,
            _i_yuukou,
            -- _i_keijounengetu,
            cal_KeijouDate(_i_nyuukadate),
            _i_dataKBN,
            _i_torihikiKBN,
            _i_nyuukaKBN,
            _i_hattyuuKaikeiNendo,
            _i_hattyuuNO,
            _i_hattyuuGyouNO,
            _i_siireKaikeiNendo,
            _i_siireNO,
            _i_siireGyouNO,
            _i_nyuukadate,
            _i_soukoCD,
            _i_siiresakiCD,
            _i_siiresakiNM,
            _i_denpyou_tekiyou1,
            _i_denpyou_tekiyou2,
            _i_mnyuukaKBN,
            _i_syouhinCD,
            _i_syouhinNM,
            _i_hattyuu_suryou,
            _i_suryou,
            _i_taniCD,
            _i_tanka,
            _i_kingaku,
            _i_meisai_tekiyou,
            _i_hontai_kingaku,
            _i_syouhizei,
            0,
            _i_updDataKBN,
            _i_insertdate,
            _i_insertTantosya
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
