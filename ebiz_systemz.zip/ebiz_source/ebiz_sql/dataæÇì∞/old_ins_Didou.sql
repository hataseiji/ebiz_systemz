DROP PROCEDURE IF EXISTS ins_Didou;
DELIMITER //
CREATE PROCEDURE ins_Didou (
    IN _i_kaikeiNendo        integer(4),
    IN _i_denpyouNO          integer(6),
    IN _i_gyouNO            integer(3),
    IN _i_seq               integer(6),
    IN _i_akakuro           tinyint(1),
    IN _i_yuukou            tinyint(1),
    IN _i_keijounengetu     date,
    IN _i_dataKBN           integer(3),
    IN _i_torihikiKBN       tinyint(2),
    IN _i_idouKBN           tinyint(2),
    IN _i_idoudate          date,
    IN _i_motosoukoCD       integer(6),
    IN _i_sakisoukoCD       integer(6),
    IN _i_denpyou_tekiyou1  varchar(40),
    IN _i_denpyou_tekiyou2  varchar(40),
    IN _i_midouKBN          tinyint(2),
    IN _i_syouhinCD         varchar(10),
    IN _i_syouhinNM         varchar(40),
    IN _i_suryou            decimal(10,3),
    IN _i_taniCD            tinyint(2),
    IN _i_tanka             decimal(8),
    IN _i_kingaku           decimal(10),
    IN _i_meisai_tekiyou    varchar(40),
    IN _i_insertdate        datetime,
    IN _i_insertTantosya    integer(6),
    OUT _o_ErrorMsg         varchar(256),
    OUT _o_Result           Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Didou where kaikeiNendo = _i_kaikeiNendo and denpyouNO = _i_denpyouNO and gyouNO = _i_gyouNO;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Didou (
            kaikeiNendo,
            denpyouNO,
            gyouNO,
            seq,
            akakuro,
            yuukou,
            keijounengetu,
            dataKBN,
            torihikiKBN,
            idouKBN,
            idoudate,
            motosoukoCD,
            sakisoukoCD,
            denpyou_tekiyou1,
            denpyou_tekiyou2,
            midouKBN,
            syouhinCD,
            syouhinNM,
            suryou,
            taniCD,
            tanka,
            kingaku,
            meisai_tekiyou,
            DenpyouHakkou,
            insertdate,
            insertTantosya
        )
        values
        (
            _i_kaikeiNendo,
            _i_denpyouNO,
            _i_gyouNO,
            _i_seq,
            _i_akakuro,
            _i_yuukou,
            -- _i_keijounengetu,
            -- _i_keijounengetu,
            cal_KeijouDate(_i_idoudate),
            _i_dataKBN,
            _i_torihikiKBN,
            _i_idouKBN,
            _i_idoudate,
            _i_motosoukoCD,
            _i_sakisoukoCD,
            _i_denpyou_tekiyou1,
            _i_denpyou_tekiyou2,
            _i_midouKBN,
            _i_syouhinCD,
            _i_syouhinNM,
            _i_suryou,
            _i_taniCD,
            _i_tanka,
            _i_kingaku,
            _i_meisai_tekiyou,
            0,
            _i_insertdate,
            _i_insertTantosya
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
