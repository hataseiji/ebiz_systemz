DROP PROCEDURE IF EXISTS ins_Duriageseigyo;
DELIMITER //
CREATE PROCEDURE ins_Duriageseigyo (
    IN _i_kaikeiNendo         integer(4),
    IN _i_denpyouNO           integer(6),
    IN _i_syukkaseigyo        tinyint(1),
    IN _i_insertdate           datetime,
    IN _i_insertTantosya       integer(6),
    OUT _o_ErrorMsg           varchar(256),
    OUT _o_Result             Boolean
)
BEGIN
    DECLARE _counter integer;

    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    select count(*) INTO _counter from Duriageseigyo where kaikeiNendo = _i_kaikeiNendo and denpyouNO = _i_denpyouNO;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Duriageseigyo (
            kaikeiNendo,
            denpyouNO,
            syukkaseigyo,
            insertdate,
            insertTantosya
        )
        values
        (
            _i_kaikeiNendo,
            _i_denpyouNO,
            _i_syukkaseigyo,
            _i_insertdate,
            _i_insertTantosya
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
