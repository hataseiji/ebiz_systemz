DROP PROCEDURE IF EXISTS GetujiKakuteiKanri;
DELIMITER //
CREATE PROCEDURE GetujiKakuteiKanri(
    IN  _I_date         date,
    IN  _I_Tantosya     integer(6),
    OUT _o_ErrorMsg      varchar(256),
    OUT _o_Result        Boolean
)
BEGIN
/*
    月次更新
    基本情報管理マスタの更新を行います。
*/
    DECLARE _wDate              date;
    DECLARE _kaikei_yyyymm      integer; /* 処理年月 */

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* 管理マスタより現在の処理年月を取得する。 */
    select kaikei_yyyymm into _kaikei_yyyymm from Mkanri where kanriCD=1;
    if _kaikei_yyyymm is NULL then
        set _kaikei_yyyymm=200104;
    end if;

    /* 処理年月の翌月を算出する */
    SET _wDate = _kaikei_yyyymm * 100 + 1;
    SET _wDate = _wDate + INTERVAL 1 MONTH;

    update Mkanri 
    set 
         kaikei_year     = YEAR(_wDate)
        ,kaikei_yyyymm   = PERIOD_ADD(_kaikei_yyyymm,1)
        ,keikatu_kisuu   = keikatu_kisuu + 1   /* 経過月数 */
    where kanriCD=1;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
