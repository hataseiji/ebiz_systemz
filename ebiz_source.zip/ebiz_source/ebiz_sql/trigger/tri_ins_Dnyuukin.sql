drop trigger IF EXISTS tri_ins_Dnyuukin;
delimiter ;;
CREATE TRIGGER `tri_ins_Dnyuukin` AFTER INSERT ON `Dnyuukin` FOR EACH ROW BEGIN
    /* 黒処理 */
    INSERT INTO Dnyuukinlog
    (
      kaikeiNendo,
      denpyouNO,
      gyouNO,
      akakuro,
      yuukou,
      keijounengetu,
      dataKBN,
      torihikiKBN,
      nyuukinKBN,
      nyuukindate,
      seikyuusakiCD,
      denpyou_tekiyou1,
      denpyou_tekiyou2,
      mnyuukinKBN,
      kingaku,
      meisai_tekiyou,
      hontai_kingaku,
      syouhizei,
      seikyuusyoBangou,
      DenpyouHakkou,
      ginkouNM,
      sitenNM,
      tegatadate,
      tegataNO,
      furidasiNM,
      Krenkeidate,  -- 2013/10/13
      insertdate,
      insertTantosya
    )
    values
    (
        NEW.kaikeiNendo,
        NEW.denpyouNO,
        NEW.gyouNO,
        0, /* 黒 */
        0, /* 有効 */
        cal_KeijouDate(NEW.nyuukindate),
        NEW.dataKBN,
        NEW.torihikiKBN,
        NEW.nyuukinKBN,
        NEW.nyuukindate,
        NEW.seikyuusakiCD,
        NEW.denpyou_tekiyou1,
        NEW.denpyou_tekiyou2,
        NEW.mnyuukinKBN,
        NEW.kingaku,
        NEW.meisai_tekiyou,
        NEW.hontai_kingaku,
        NEW.syouhizei,
        NEW.seikyuusyoBangou,
        NEW.DenpyouHakkou,
        NEW.ginkouNM,
        NEW.sitenNM,
        NEW.tegatadate,
        NEW.tegataNO,
        NEW.furidasiNM,
        NEW.Krenkeidate,  -- 2013/10/13
        CURRENT_TIMESTAMP(),
        NEW.insertTantosya
    );
END;
 ;;
delimiter ;
