drop trigger IF EXISTS tri_ins_Dnyuusyukko_fromN;
delimiter ;;
CREATE TRIGGER `tri_ins_Dnyuusyukko_fromN` AFTER INSERT ON `Dnyuukalog` FOR EACH ROW BEGIN
    INSERT INTO Dnyuusyukko
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        systemKBN,
        nyuusyukkodate,
        soukoCD,
        syouhinCD,
        syouhinNM,
        suryou,
        taniCD,
        tanka,
        kingaku,
        hontai_kingaku,
        syouhizei,
        insertdate,
        insertTantosya
    )
    values
    (
        NEW.kaikeiNendo,
        NEW.denpyouNO,
        NEW.gyouNO,
        NEW.akakuro,
        NEW.yuukou,
        NEW.keijounengetu,
        NEW.dataKBN,
        NEW.torihikiKBN,
        NEW.nyuukaKBN,
        NEW.nyuukadate,
        NEW.soukoCD,
        NEW.syouhinCD,
        NEW.syouhinNM,
        NEW.suryou,
        NEW.taniCD,
        NEW.tanka,
        NEW.kingaku,
        NEW.hontai_kingaku,
        NEW.syouhizei,
        CURRENT_TIMESTAMP(),
        NEW.insertTantosya
    );
END;
 ;;
delimiter ;
