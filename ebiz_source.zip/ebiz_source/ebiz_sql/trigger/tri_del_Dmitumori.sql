drop trigger IF EXISTS tri_del_Dmitumori;
delimiter ;;
CREATE TRIGGER `tri_del_Dmitumori` AFTER DELETE ON `Dmitumori` FOR EACH ROW BEGIN
    INSERT INTO Dmitumorilog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        mitumoriKBN,
        mitumoridate,
        syukkadate,
        nouki,
        tokuisakiCD,
        soukoCD,
        tokuisakiNM,
        TtyuumonNo,
        mitumriAnken1,
        mitumriAnken2,
        denpyou_tekiyou1,
        denpyou_tekiyou2,
        mmitumoriKBN,
        syouhinCD,
        syouhinNM,
        suryou,
        taniCD,
        tanka,
        kingaku,
        genka_tanka,
        genka_kingaku,
        arari,
        meisai_tekiyou,
        hontai_kingaku,
        inji_syouhizei,
        kaikei_syouhizei,
        DenpyouHakkou,
        insertdate,
        insertTantosya
    )
    values
    (
        OLD.kaikeiNendo,
        OLD.denpyouNO,
        OLD.gyouNO,
        1,  /* 赤 */
        1,  /* 無効 */
        cal_KeijouDate(OLD.mitumoridate),
        OLD.dataKBN,
        OLD.torihikiKBN,
        OLD.mitumoriKBN,
        OLD.mitumoridate,
        OLD.syukkadate,
        OLD.nouki,
        OLD.tokuisakiCD,
        OLD.soukoCD,
        OLD.tokuisakiNM,
        OLD.TtyuumonNo,
        OLD.mitumriAnken1,
        OLD.mitumriAnken2,
        OLD.denpyou_tekiyou1,
        OLD.denpyou_tekiyou2,
        OLD.mmitumoriKBN,
        OLD.syouhinCD,
        OLD.syouhinNM,
        OLD.suryou * -1,
        OLD.taniCD,
        OLD.tanka,
        OLD.kingaku * -1,
        OLD.genka_tanka,
        OLD.genka_kingaku * -1,
        OLD.arari * -1,
        OLD.meisai_tekiyou,
        OLD.hontai_kingaku * -1,
        OLD.inji_syouhizei * -1,
        OLD.kaikei_syouhizei * -1,
        OLD.DenpyouHakkou,
        CURRENT_TIMESTAMP(),
        OLD.insertTantosya
    );
    -- 全てのログは無効
    update Dmitumorilog set yuukou=1 where kaikeiNendo=OLD.kaikeiNendo and denpyouNO=OLD.denpyouNO;
END;
 ;;
delimiter ;
