drop trigger IF EXISTS tri_ins_Dnyuuka;
delimiter ;;
CREATE TRIGGER `tri_ins_Dnyuuka` AFTER INSERT ON `Dnyuuka` FOR EACH ROW BEGIN
    /* 黒処理 */
    INSERT INTO Dnyuukalog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        nyuukaKBN,
        hattyuuKaikeiNendo,
        hattyuuNO,
        hattyuu_gyouNO,
        siireKaikeiNendo,
        siireNO,
        siire_gyouNO,
        nyuukadate,
        soukoCD,
        siiresakiCD,
        siiresakiNM,
        denpyou_tekiyou1,
        denpyou_tekiyou2,
        mnyuukaKBN,
        syouhinCD,
        syouhinNM,
        hattyuu_suryou,
        suryou,
        taniCD,
        tanka,
        kingaku,
        meisai_tekiyou,
        hontai_kingaku,
        syouhizei,
        DenpyouHakkou,
        updDataKBN,
        insertdate,
        insertTantosya
    )
    values
    (
        NEW.kaikeiNendo,
        NEW.denpyouNO,
        NEW.gyouNO,
        0, /* 黒 */
        0, /* 有効 */
        cal_KeijouDate(NEW.nyuukadate),
        NEW.dataKBN,
        NEW.torihikiKBN,
        NEW.nyuukaKBN,
        NEW.hattyuuKaikeiNendo,
        NEW.hattyuuNO,
        NEW.hattyuu_gyouNO,
        NEW.siireKaikeiNendo,
        NEW.siireNO,
        NEW.siire_gyouNO,
        NEW.nyuukadate,
        NEW.soukoCD,
        NEW.siiresakiCD,
        NEW.siiresakiNM,
        NEW.denpyou_tekiyou1,
        NEW.denpyou_tekiyou2,
        NEW.mnyuukaKBN,
        NEW.syouhinCD,
        NEW.syouhinNM,
        NEW.hattyuu_suryou,
        NEW.suryou,
        NEW.taniCD,
        NEW.tanka,
        NEW.kingaku,
        NEW.meisai_tekiyou,
        NEW.hontai_kingaku,
        NEW.syouhizei,
        NEW.DenpyouHakkou,
        NEW.updDataKBN,
        CURRENT_TIMESTAMP(),
        NEW.insertTantosya
    );
END;
 ;;
delimiter ;
