drop trigger IF EXISTS tri_del_Sjikkoujoutai;
delimiter ;;
CREATE TRIGGER `tri_del_Sjikkoujoutai` AFTER DELETE ON `Sjikkoujoutai` FOR EACH ROW BEGIN
    INSERT INTO Sjikkoujoutailog
    (
      programID,
      tantosyaCD,
      LEVEL,
      tekiyou,
      insertDate
    )
    values
    (
      OLD.programID,
      OLD.tantosyaCD,
      OLD.LEVEL,
      '終了',
      now()
    );
END;
 ;;
delimiter ;
