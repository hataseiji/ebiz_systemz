drop trigger IF EXISTS tri_ins_Dsyukka;
delimiter ;;
CREATE TRIGGER `tri_ins_Dsyukka` AFTER INSERT ON `Dsyukka` FOR EACH ROW BEGIN
    INSERT INTO Dsyukkalog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        syukkaKBN,
        jutyuuKaikeiNendo,
        jutyuuNO,
        jutyuu_gyouNO,
        uriageKaikeiNendo,
        uriageNO,
        uriage_gyouNO,
        syukkadate,
        soukoCD,
        denpyou_tekiyou1,
        denpyou_tekiyou2,
        nouhinsyo_tankaKBN,
        msyukkaKBN,
        syouhinCD,
        syouhinNM,
        suryou,
        taniCD,
        tanka,
        kingaku,
        meisai_tekiyou,
        hontai_kingaku,
        syouhizei,
        DenpyouHakkou,
        NouhinsyoHakkou, -- 2013/12/02
        updDataKBN,
        insertdate,
        insertTantosya
    )
    values
    (
        NEW.kaikeiNendo,
        NEW.denpyouNO,
        NEW.gyouNO,
        0, /* 黒 */
        0, /* 有効 */
        -- OLD.keijounengetu,
        cal_KeijouDate(NEW.syukkadate),
        NEW.dataKBN,
        NEW.torihikiKBN,
        NEW.syukkaKBN,
        NEW.jutyuuKaikeiNendo,
        NEW.jutyuuNO,
        NEW.jutyuu_gyouNO,
        NEW.uriageKaikeiNendo,
        NEW.uriageNO,
        NEW.uriage_gyouNO,
        NEW.syukkadate,
        NEW.soukoCD,
        NEW.denpyou_tekiyou1,
        NEW.denpyou_tekiyou2,
        NEW.nouhinsyo_tankaKBN,
        NEW.msyukkaKBN,
        NEW.syouhinCD,
        NEW.syouhinNM,
        NEW.suryou,
        NEW.taniCD,
        NEW.tanka,
        NEW.kingaku,
        NEW.meisai_tekiyou,
        NEW.hontai_kingaku,
        NEW.syouhizei,
        NEW.DenpyouHakkou,
        NEW.NouhinsyoHakkou, -- 2013/12/02
        NEW.updDataKBN,
        NEW.insertdate,
        NEW.insertTantosya
    );
END;
 ;;
delimiter ;
