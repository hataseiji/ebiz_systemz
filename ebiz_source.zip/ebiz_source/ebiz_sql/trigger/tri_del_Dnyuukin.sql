drop trigger IF EXISTS tri_del_Dnyuukin;
delimiter ;;
CREATE TRIGGER `tri_del_Dnyuukin` AFTER DELETE ON `Dnyuukin` FOR EACH ROW BEGIN
    /* 赤処理 */
    INSERT INTO Dnyuukinlog
    (
      kaikeiNendo,
      denpyouNO,
      gyouNO,
      -- seq,
      akakuro,
      yuukou,
      keijounengetu,
      dataKBN,
      torihikiKBN,
      nyuukinKBN,
      nyuukindate,
      seikyuusakiCD,
      denpyou_tekiyou1,
      denpyou_tekiyou2,
      mnyuukinKBN,
      kingaku,
      meisai_tekiyou,
      hontai_kingaku,
      syouhizei,
      seikyuusyoBangou,
      DenpyouHakkou,
      ginkouNM,
      sitenNM,
      tegatadate,
      tegataNO,
      furidasiNM,
      Krenkeidate,  -- 2013/10/13
      insertdate,
      insertTantosya
    )
    values
    (
        OLD.kaikeiNendo,
        OLD.denpyouNO,
        OLD.gyouNO,
        1,  /* 赤 */
        1,  /* 無効 */
        cal_KeijouDate(OLD.nyuukindate),
        OLD.dataKBN,
        OLD.torihikiKBN,
        OLD.nyuukinKBN,
        OLD.nyuukindate,
        OLD.seikyuusakiCD,
        OLD.denpyou_tekiyou1,
        OLD.denpyou_tekiyou2,
        OLD.mnyuukinKBN,
        OLD.kingaku * -1,
        OLD.meisai_tekiyou,
        OLD.hontai_kingaku * -1,
        OLD.syouhizei * -1,
        OLD.seikyuusyoBangou,
        OLD.DenpyouHakkou,
        OLD.ginkouNM,
        OLD.sitenNM,
        OLD.tegatadate,
        OLD.tegataNO,
        OLD.furidasiNM,
        OLD.Krenkeidate,  -- 2013/10/13
        CURRENT_TIMESTAMP(),
        OLD.insertTantosya
    );
    -- 全てのログは無効
    update Dnyuukinlog set yuukou=1 where kaikeiNendo=OLD.kaikeiNendo and denpyouNO=OLD.denpyouNO;
END;
 ;;
delimiter ;
