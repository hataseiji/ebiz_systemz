drop trigger IF EXISTS tri_ins_Dnyuusyukko_fromI;
delimiter ;;
CREATE TRIGGER `tri_ins_Dnyuusyukko_fromI` AFTER INSERT ON `Didoulog` FOR EACH ROW BEGIN
    DECLARE _suryou      decimal(12,3) DEFAULT 0;
    DECLARE _kingaku     decimal(10,0) DEFAULT 0;

    if NEW.dataKBN = 110 and NEW.torihikiKBN >= 40 then
    /* 棚卸の場合の数量のセット */
        -- 帳簿在庫数取得
        SET @kaikei_yyyy = 0;
        SET @DenpyouNumber = 0;
        call GetYuukouZaiko(
              NEW.sakisoukoCD
             ,NEW.syouhinCD
             ,@tyoubo);
        if NEW.akakuro = 1 then
        -- 赤 帳簿在庫数全てで赤を切る
            set _suryou = @tyoubo * -1;
        else
        -- 黒
            set _suryou = NEW.suryou - @tyoubo;
        end if;
    else
        set _suryou = NEW.suryou;
    end if;

    if NEW.motosoukoCD <> 0 then
        INSERT INTO Dnyuusyukko
        (
            kaikeiNendo,
            denpyouNO,
            gyouNO,
            akakuro,
            yuukou,
            keijounengetu,
            dataKBN,
            torihikiKBN,
            systemKBN,
            nyuusyukkodate,
            soukoCD,
            syouhinCD,
            syouhinNM,
            suryou,
            taniCD,
            tanka,
            kingaku,
            hontai_kingaku,
            syouhizei,
            insertdate,
            insertTantosya
        )
        values
        (
            NEW.kaikeiNendo,
            NEW.denpyouNO,
            NEW.gyouNO,
            NEW.akakuro,
            NEW.yuukou,
            NEW.keijounengetu,
            NEW.dataKBN,
            20,    /* 社内品減 */
            20,    /* 社内品減 */
            NEW.idoudate,
            NEW.motosoukoCD,
            NEW.syouhinCD,
            NEW.syouhinNM,
            _suryou,
            NEW.taniCD,
            NEW.tanka,
            NEW.kingaku,
            0,
            0,
            CURRENT_TIMESTAMP(),
            NEW.insertTantosya
        );
    end if;
    if NEW.sakisoukoCD <> 0 then
        INSERT INTO Dnyuusyukko
        (
            kaikeiNendo,
            denpyouNO,
            gyouNO,
            akakuro,
            yuukou,
            keijounengetu,
            dataKBN,
            systemKBN,
            torihikiKBN,
            nyuusyukkodate,
            soukoCD,
            syouhinCD,
            syouhinNM,
            suryou,
            taniCD,
            tanka,
            kingaku,
            hontai_kingaku,
            syouhizei,
            insertdate,
            insertTantosya
        )
        values
        (
            NEW.kaikeiNendo,
            NEW.denpyouNO,
            NEW.gyouNO,
            NEW.akakuro,
            NEW.yuukou,
            NEW.keijounengetu,
            NEW.dataKBN,
            10,    /* 社内品増 */
            10,    /* 社内品増 */
            NEW.idoudate,
            NEW.sakisoukoCD,
            NEW.syouhinCD,
            NEW.syouhinNM,
            _suryou,
            NEW.taniCD,
            NEW.tanka,
            NEW.kingaku,
            0,
            0,
            CURRENT_TIMESTAMP(),
            NEW.insertTantosya
        );
    end if;
END;
 ;;
delimiter ;
