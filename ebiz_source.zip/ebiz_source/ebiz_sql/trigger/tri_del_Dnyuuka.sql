drop trigger IF EXISTS tri_del_Dnyuuka;
delimiter ;;
CREATE TRIGGER `tri_del_Dnyuuka` AFTER DELETE ON `Dnyuuka` FOR EACH ROW BEGIN
    /* 赤処理 */
    INSERT INTO Dnyuukalog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        nyuukaKBN,
        hattyuuKaikeiNendo,
        hattyuuNO,
        hattyuu_gyouNO,
        siireKaikeiNendo,
        siireNO,
        siire_gyouNO,
        nyuukadate,
        soukoCD,
        siiresakiCD,
        siiresakiNM,
        denpyou_tekiyou1,
        denpyou_tekiyou2,
        mnyuukaKBN,
        syouhinCD,
        syouhinNM,
        hattyuu_suryou,
        suryou,
        taniCD,
        tanka,
        kingaku,
        meisai_tekiyou,
        hontai_kingaku,
        syouhizei,
        DenpyouHakkou,
        updDataKBN,
        insertdate,
        insertTantosya
    )
    values
    (
        OLD.kaikeiNendo,
        OLD.denpyouNO,
        OLD.gyouNO,
        1,  /* 赤 */
        1,  /* 無効 */
        cal_KeijouDate(OLD.nyuukadate),
        OLD.dataKBN,
        OLD.torihikiKBN,
        OLD.nyuukaKBN,
        OLD.hattyuuKaikeiNendo,
        OLD.hattyuuNO,
        OLD.hattyuu_gyouNO,
        OLD.siireKaikeiNendo,
        OLD.siireNO,
        OLD.siire_gyouNO,
        OLD.nyuukadate,
        OLD.soukoCD,
        OLD.siiresakiCD,
        OLD.siiresakiNM,
        OLD.denpyou_tekiyou1,
        OLD.denpyou_tekiyou2,
        OLD.mnyuukaKBN,
        OLD.syouhinCD,
        OLD.syouhinNM,
        OLD.hattyuu_suryou * -1,
        OLD.suryou * -1,
        OLD.taniCD,
        OLD.tanka,
        OLD.kingaku * -1,
        OLD.meisai_tekiyou,
        OLD.hontai_kingaku * -1,
        OLD.syouhizei * -1,
        OLD.DenpyouHakkou,
        OLD.updDataKBN,
        CURRENT_TIMESTAMP(),
        OLD.insertTantosya
    );
    -- 全てのログは無効
    update Dnyuukalog set yuukou=1 where kaikeiNendo=OLD.kaikeiNendo and denpyouNO=OLD.denpyouNO;
END;
 ;;
delimiter ;
