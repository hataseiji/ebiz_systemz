drop trigger IF EXISTS tri_del_Dsiire;
delimiter ;;
CREATE TRIGGER `tri_del_Dsiire` AFTER DELETE ON `Dsiire` FOR EACH ROW BEGIN
    INSERT INTO Dsiirelog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        siireKBN,
        hattyuuKaikeiNendo,
        hattyuuNO,
        hattyuu_gyouNO,
        nyuukaKaikeiNendo,
        nyuukaNO,
        nyuuka_gyouNO,
        siiredate,
        nyuukadate,
        ankenKaikeiNendo,
        ankenjutyuuNO,
        siiresakiCD,
        siiresakiNM,
        soukoCD,
        denpyou_tekiyou1,
        denpyou_tekiyou2,
        msiireKBN,
        syouhinCD,
        syouhinNM,
        suryou,
        taniCD,
        tanka,
        kingaku,
        meisai_tekiyou,
        hontai_kingaku,
        inji_syouhizei,
        kaikei_syouhizei,
        siharaisyoBangou,
        DenpyouHakkou,
        Krenkeidate,  -- 2013/10/13
        insertdate,
        insertTantosya
        )
        values
        (
        OLD.kaikeiNendo,
        OLD.denpyouNO,
        OLD.gyouNO,
        1,
        1,

        cal_KeijouDate(OLD.siiredate),
        OLD.dataKBN,
        OLD.torihikiKBN,
        OLD.siireKBN,
        OLD.hattyuuKaikeiNendo,
        OLD.hattyuuNO,
        OLD.hattyuu_gyouNO,
        OLD.nyuukaKaikeiNendo,
        OLD.nyuukaNO,
        OLD.nyuuka_gyouNO,
        OLD.siiredate,
        OLD.nyuukadate,
        OLD.ankenKaikeiNendo,
        OLD.ankenjutyuuNO,
        OLD.siiresakiCD,
        OLD.siiresakiNM,
        OLD.soukoCD,
        OLD.denpyou_tekiyou1,
        OLD.denpyou_tekiyou2,
        OLD.msiireKBN,
        OLD.syouhinCD,
        OLD.syouhinNM,
        OLD.suryou * -1,
        OLD.taniCD,
        OLD.tanka,
        OLD.kingaku * -1,
        OLD.meisai_tekiyou,
        OLD.hontai_kingaku * -1,
        OLD.inji_syouhizei * -1,
        OLD.kaikei_syouhizei * -1,
        OLD.siharaisyoBangou,
        OLD.DenpyouHakkou,
        OLD.Krenkeidate,  -- 2013/10/13
        CURRENT_TIMESTAMP(),
        OLD.insertTantosya
    );

    update Dsiirelog set yuukou=1 where kaikeiNendo=OLD.kaikeiNendo and denpyouNO=OLD.denpyouNO;
END;
 ;;
delimiter ;
