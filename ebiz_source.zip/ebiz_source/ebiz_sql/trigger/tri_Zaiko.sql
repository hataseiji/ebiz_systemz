drop trigger IF EXISTS tri_Zaiko;
delimiter ;;
CREATE TRIGGER `tri_Zaiko` AFTER INSERT ON `Dnyuusyukko` FOR EACH ROW BEGIN
/*
    入出庫データより在庫データの更新を行う。
    伝票の計上年月が翌月以降であっても処理年月でデータは作成され、翌月以降エリアに集計される。
*/
    DECLARE _counter                        integer;
    DECLARE _kaikei_yyyymm                  integer;      /* 処理年月 */
    DECLARE _keijounengetu                  integer;      /* 計上年月 (未使用) */
    DECLARE _zengetumatu_zaikosu        decimal(12,3);    /* 前月末在庫数 */
    DECLARE _tougetu_uriagesu           decimal(12,3);    /* 当月売上数 */
    DECLARE _tougetu_syukkosu           decimal(12,3);    /* 当月出庫数 */
    DECLARE _tougetu_sonotasyukkosu     decimal(12,3);    /* 当月その他出庫数 */
    DECLARE _tougetu_tanaorosigen       decimal(12,3);    /* 当月棚卸減 */
    DECLARE _tougetu_siiresu            decimal(12,3);    /* 当月仕入数 */
    DECLARE _tougetu_nyuukosu           decimal(12,3);    /* 当月入庫数 */
    DECLARE _tougetu_sonotanyuukosu     decimal(12,3);    /* 当月その他入庫数 */
    DECLARE _tougetu_tanaorosizou       decimal(12,3);    /* 当月棚卸増 */
    DECLARE _yokugetu_uriagesu          decimal(12,3);    /* 翌月売上数 */
    DECLARE _yokugetu_syukkosu          decimal(12,3);    /* 翌月出庫数 */
    DECLARE _yokugetu_sonotasyukkosu    decimal(12,3);    /* 翌月その他出庫数 */
    DECLARE _yokugetu_tanaorosigen      decimal(12,3);    /* 翌月棚卸減 */
    DECLARE _yokugetu_siiresu           decimal(12,3);    /* 翌月仕入数 */
    DECLARE _yokugetu_nyuukosu          decimal(12,3);    /* 翌月入庫数 */
    DECLARE _yokugetu_sonotanyuukosu    decimal(12,3);    /* 翌月その他入庫数 */
    DECLARE _yokugetu_tanaorosizou      decimal(12,3);    /* 翌月棚卸増 */
    DECLARE _tanka                      decimal(12,3);    /* 在庫評価単価 */

    /* 処理年月の取得 */
    select kaikei_yyyymm into _kaikei_yyyymm from Mkanri where kanriCD=1;
    if _kaikei_yyyymm is NULL then
        set _kaikei_yyyymm=200104;
    end if;

    /* 前月末在庫数クリア */
    set _zengetumatu_zaikosu = 0;
    set _tougetu_uriagesu = 0;
    set _tougetu_syukkosu = 0;
    set _tougetu_sonotasyukkosu = 0;
    set _tougetu_tanaorosigen = 0;
    set _tougetu_siiresu = 0;
    set _tougetu_nyuukosu = 0;
    set _tougetu_sonotanyuukosu = 0;
    set _tougetu_tanaorosizou = 0;
    set _yokugetu_uriagesu = 0;
    set _yokugetu_syukkosu = 0;
    set _yokugetu_sonotasyukkosu = 0;
    set _yokugetu_tanaorosigen = 0;
    set _yokugetu_siiresu = 0;
    set _yokugetu_nyuukosu = 0;
    set _yokugetu_sonotanyuukosu = 0;
    set _yokugetu_tanaorosizou = 0;
    set _tanka = NEW.tanka;
    if NEW.keijounengetu > _kaikei_yyyymm then
    /* 伝票の計上年月が翌月以降の場合 */
        -- set _keijounengetu = NEW.keijounengetu;
        if NEW.dataKBN=40 then
            set _yokugetu_uriagesu = NEW.suryou;
        end if;
        set _yokugetu_syukkosu = 0;
        if NEW.dataKBN=110 and NEW.torihikiKBN = 20 then
            set _yokugetu_sonotasyukkosu = NEW.suryou;
        end if;
        if NEW.dataKBN=110 and NEW.torihikiKBN = 50 then
            set _yokugetu_sonotasyukkosu = NEW.suryou;
        end if;
        if NEW.dataKBN=70 then
            set _yokugetu_siiresu = NEW.suryou;
        end if;
        set _yokugetu_nyuukosu = 0;
        if NEW.dataKBN=110 and NEW.torihikiKBN = 10 then
            set _yokugetu_sonotanyuukosu = NEW.suryou;
        end if;
        if NEW.dataKBN=110 and NEW.torihikiKBN = 40 then
            set _yokugetu_tanaorosizou = NEW.suryou;
        end if;
    else
    /* 伝票の計上年月が当月の場合 */
        if NEW.dataKBN=40 then
            set _tougetu_uriagesu = NEW.suryou;
        end if;
        set _tougetu_syukkosu = 0;
        if NEW.dataKBN=110 and NEW.torihikiKBN = 20 then
            set _tougetu_sonotasyukkosu = NEW.suryou;
        end if;
        if NEW.dataKBN=110 and NEW.torihikiKBN = 50 then
            set _tougetu_sonotasyukkosu = NEW.suryou;
        end if;
        if NEW.dataKBN=70 then
            set _tougetu_siiresu = NEW.suryou;
        end if;
        set _tougetu_nyuukosu = 0;
        if NEW.dataKBN=110 and NEW.torihikiKBN = 10 then
            set _tougetu_sonotanyuukosu = NEW.suryou;
        end if;
        if NEW.dataKBN=110 and NEW.torihikiKBN = 40 then
            set _tougetu_tanaorosizou = NEW.suryou;
        end if;
    end if;

    select count(*) INTO _counter from Dzaiko where Dzaiko.soukoCD = NEW.soukoCD and Dzaiko.syouhinCD = NEW.syouhinCD and Dzaiko.keijounengetu = _kaikei_yyyymm;
    if _counter = 0 then

        INSERT INTO Dzaiko
        (
            soukoCD,
            syouhinCD,
            keijounengetu,
            zengetumatu_zaikosu,
            tougetu_uriagesu,
            tougetu_syukkosu,
            tougetu_sonotasyukkosu,
            tougetu_tanaorosigen,
            tougetu_siiresu,
            tougetu_nyuukosu,
            tougetu_sonotanyuukosu,
            tougetu_tanaorosizou,
            yokugetu_uriagesu,
            yokugetu_syukkosu,
            yokugetu_sonotasyukkosu,
            yokugetu_tanaorosigen,
            yokugetu_siiresu,
            yokugetu_nyuukosu,
            yokugetu_sonotanyuukosu,
            yokugetu_tanaorosizou,
            -- tanka,
            insertdate,
            insertTantosya,
            updatedate,
            updateTantosya
        )
        values
        (
            NEW.soukoCD,
            NEW.syouhinCD,
            _kaikei_yyyymm,
            _zengetumatu_zaikosu,
            _tougetu_uriagesu,
            _tougetu_syukkosu,
            _tougetu_sonotasyukkosu,
            _tougetu_tanaorosigen,
            _tougetu_siiresu,
            _tougetu_nyuukosu,
            _tougetu_sonotanyuukosu,
            _tougetu_tanaorosizou,
            _yokugetu_uriagesu,
            _yokugetu_syukkosu,
            _yokugetu_sonotasyukkosu,
            _yokugetu_tanaorosigen,
            _yokugetu_siiresu,
            _yokugetu_nyuukosu,
            _yokugetu_sonotanyuukosu,
            _yokugetu_tanaorosizou,
            -- _tanka,
            NEW.insertdate,
            NEW.insertTantosya,
            NEW.insertdate,
            NEW.insertTantosya
        );
    else
        update Dzaiko set
            zengetumatu_zaikosu     =    zengetumatu_zaikosu     + _zengetumatu_zaikosu,
            tougetu_uriagesu        =    tougetu_uriagesu        + _tougetu_uriagesu,
            tougetu_syukkosu        =    tougetu_syukkosu        + _tougetu_syukkosu,
            tougetu_sonotasyukkosu  =    tougetu_sonotasyukkosu  + _tougetu_sonotasyukkosu,
            tougetu_tanaorosigen    =    tougetu_tanaorosigen    + _tougetu_tanaorosigen,
            tougetu_siiresu         =    tougetu_siiresu         + _tougetu_siiresu,
            tougetu_nyuukosu        =    tougetu_nyuukosu        + _tougetu_nyuukosu,
            tougetu_sonotanyuukosu  =    tougetu_sonotanyuukosu  + _tougetu_sonotanyuukosu,
            tougetu_tanaorosizou    =    tougetu_tanaorosizou    + _tougetu_tanaorosizou,
            yokugetu_uriagesu       =    yokugetu_uriagesu       + _yokugetu_uriagesu,
            yokugetu_syukkosu       =    yokugetu_syukkosu       + _yokugetu_syukkosu,
            yokugetu_sonotasyukkosu =    yokugetu_sonotasyukkosu + _yokugetu_sonotasyukkosu,
            yokugetu_tanaorosigen   =    yokugetu_tanaorosigen   + _yokugetu_tanaorosigen,
            yokugetu_siiresu        =    yokugetu_siiresu        + _yokugetu_siiresu,
            yokugetu_nyuukosu       =    yokugetu_nyuukosu       + _yokugetu_nyuukosu,
            yokugetu_sonotanyuukosu =    yokugetu_sonotanyuukosu + _yokugetu_sonotanyuukosu,
            yokugetu_tanaorosizou   =    yokugetu_tanaorosizou   + _yokugetu_tanaorosizou,
            -- tanka                   =    _tanka,
            updatedate              =    NEW.insertdate,
            updateTantosya          =    NEW.insertTantosya
        where
                soukoCD              =    NEW.soukoCD
            and syouhinCD            =    NEW.syouhinCD
            and keijounengetu        =    _kaikei_yyyymm;
    end if;
    if NEW.dataKBN = 110 then
        update Dzaiko set
            tanka                    =    _tanka
        where
                soukoCD              =    NEW.soukoCD
            and syouhinCD            =    NEW.syouhinCD
            and keijounengetu        =    _kaikei_yyyymm;
    end if;
END;
 ;;
delimiter ;
