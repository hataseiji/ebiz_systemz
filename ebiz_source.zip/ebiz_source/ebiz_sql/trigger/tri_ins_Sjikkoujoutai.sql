drop trigger IF EXISTS tri_ins_Sjikkoujoutai;
delimiter ;;
CREATE TRIGGER `tri_ins_Sjikkoujoutai` AFTER INSERT ON `Sjikkoujoutai` FOR EACH ROW BEGIN
    INSERT INTO Sjikkoujoutailog
    (
      programID,
      tantosyaCD,
      LEVEL,
      tekiyou,
      insertDate
    )
    values
    (
      NEW.programID,
      NEW.tantosyaCD,
      NEW.LEVEL,
      '開始',
      now()
    );
END;
 ;;
delimiter ;
