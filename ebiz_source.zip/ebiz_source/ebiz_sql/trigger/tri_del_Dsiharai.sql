drop trigger IF EXISTS tri_del_Dsiharai;
delimiter ;;
CREATE TRIGGER `tri_del_Dsiharai` AFTER DELETE ON `Dsiharai` FOR EACH ROW BEGIN
    /* 赤処理 */
    INSERT INTO Dsiharailog
    (
        kaikeiNendo,
        denpyouNO,
        gyouNO,
        akakuro,
        yuukou,
        keijounengetu,
        dataKBN,
        torihikiKBN,
        siharaiKBN,
        siharaidate,
        siharaisakiCD,
        denpyou_tekiyou1,
        denpyou_tekiyou2,
        msiharaiKBN,
        kingaku,
        meisai_tekiyou,
        hontai_kingaku,
        syouhizei,
        siharaisyoBangou,
        DenpyouHakkou,
        ginkouNM,
        sitenNM,
        tegatadate,
        tegataNO,
        furidasiNM,
        Krenkeidate,  -- 2013/10/13
        insertdate,
        insertTantosya
    )
    values
    (
        OLD.kaikeiNendo,
        OLD.denpyouNO,
        OLD.gyouNO,
        1,  /* 赤 */
        1,  /* 無効 */
        cal_KeijouDate(OLD.siharaidate),
        OLD.dataKBN,
        OLD.torihikiKBN,
        OLD.siharaiKBN,
        OLD.siharaidate,
        OLD.siharaisakiCD,
        OLD.denpyou_tekiyou1,
        OLD.denpyou_tekiyou2,
        OLD.msiharaiKBN,
        OLD.kingaku * -1,
        OLD.meisai_tekiyou,
        OLD.hontai_kingaku * -1,
        OLD.syouhizei * -1,
        OLD.siharaisyoBangou,
        OLD.DenpyouHakkou,
        OLD.ginkouNM,
        OLD.sitenNM,
        OLD.tegatadate,
        OLD.tegataNO,
        OLD.furidasiNM,
        OLD.Krenkeidate,  -- 2013/10/13
        CURRENT_TIMESTAMP(),
        OLD.insertTantosya
    );
    update Dsiharailog set yuukou=1
    WHERE   kaikeiNendo = OLD.kaikeiNendo
        and denpyouNO   = OLD.denpyouNO;
    END;
 ;;
delimiter ;
