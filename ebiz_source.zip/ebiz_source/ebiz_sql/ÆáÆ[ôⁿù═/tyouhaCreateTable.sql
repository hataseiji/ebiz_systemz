DROP PROCEDURE IF EXISTS tyouhaCreateTable;
DELIMITER //
CREATE PROCEDURE tyouhaCreateTable(
    IN _i_seikyuusakiFrom    integer(6),
    IN _i_seikyuusakiTo      integer(6),
    IN _i_seikyuunengetu     integer(6),
    IN _i_seikyuuDateFrom    date,
    IN _i_seikyuuDateTo      date,
    IN _i_simeBi             tinyint,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象売上データ
     売上番号(11)/案件番号(11)/案件名(40)/得意先名(40)/金額(15)/ちょうは
     ========================================================================= */
    drop table if exists Styouha;
    -- create table Styouha
    create temporary table Styouha
		select
			concat_ws('-', DURI.kaikeiNendo ,lpad(DURI.denpyouNO,6,'0')) as uriageNo ,
			DURI.kaikeiNendo,
			DURI.denpyouNO,
			DURI.uriagedate,
			concat_ws('-', DURI.ankenKaikeiNendo ,lpad(DURI.ankenjutyuuNO,6,'0')) as ankenNo ,
			DURI.ankenKaikeiNendo,
			DURI.ankenjutyuuNO,
			DJUT.ankenNM,
			DURI.tokuisakiCD,
			DURI.tokuisakiNM,
			sum(DURI.kingaku) as kingaku,
			DURI.tyouhaKBN,
			0 as zero
		from Duriage as DURI
		left outer join (select distinct kaikeiNendo,denpyouNO,ankenNM from Djutyuu) as DJUT
		on  DJUT.kaikeiNendo = DURI.ankenKaikeiNendo
		and DJUT.denpyouNO   = DURI.ankenjutyuuNO
		inner join Mtokuisaki as MTOK  -- 得意先
		on DURI.tokuisakiCD = MTOK.tokuisakiCD
		inner join (select seikyuusakiCD,simebi1,simebi2,simebi3 from Mtokuisaki where seikyuusakiCD = tokuisakiCD) as MSEI  -- 請求先
		on MSEI.seikyuusakiCD = MTOK.seikyuusakiCD
		-- 2013/05/25 start
		left outer join (select distinct seikyuusakiCD,kaikeiNendo,seikyuusyoBangou,seikyuunengetu,seikyuukakuteidate from DseikyuuHead) as SKYH
		on  SKYH.seikyuusakiCD = MTOK.seikyuusakiCD
		and SKYH.kaikeiNendo = DURI.kaikeiNendo
		and SKYH.seikyuusyoBangou = DURI.seikyuusyoBangou
		where
		    (_i_seikyuuDateFrom IS NULL or DURI.uriagedate >= _i_seikyuuDateFrom)
		and (_i_seikyuuDateTo IS NULL   or DURI.uriagedate <= _i_seikyuuDateTo)
		and (_i_seikyuusakiFrom = 0 or MSEI.seikyuusakiCD >= _i_seikyuusakiFrom)
		and (_i_seikyuusakiTo = 0   or MSEI.seikyuusakiCD <= _i_seikyuusakiTo)
		and
		(
		       MSEI.simebi1 = _i_simeBi
		    or MSEI.simebi2 = _i_simeBi
		    or MSEI.simebi3 = _i_simeBi
		)
		and SKYH.seikyuukakuteidate IS NULL
		group by DURI.kaikeiNendo, DURI.denpyouNO
		;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
