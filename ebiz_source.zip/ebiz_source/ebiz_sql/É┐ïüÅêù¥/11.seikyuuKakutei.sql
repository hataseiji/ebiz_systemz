DROP PROCEDURE IF EXISTS seikyuuKakutei;
DELIMITER //
CREATE PROCEDURE seikyuuKakutei(
    IN  _i_kaikei_nendo       integer(4),
    IN  _i_seikyuunengetu     integer(6),
    IN  _i_simeBi             tinyint(2),
    IN  _i_seikyuusakiFrom    integer(6), -- 2013/06/09
    IN  _i_seikyuusakiTo      integer(6), -- 2013/06/09
    IN  _i_insertdate         date,
    IN  _i_insertTantosya     integer(6),
    OUT _o_ErrorMsg           varchar(256),
    OUT _o_Result             Boolean
)
BEGIN
/* =========================================================================
    請求確定処理
 ========================================================================= */
    DECLARE _seikyuusakiCD      integer(6);
    DECLARE _uriagegaku         decimal(12);
    DECLARE _hennpinngaku       decimal(12);
    DECLARE _nebikigaku         decimal(12);
    DECLARE _nyuukinngaku       decimal(12);
    DECLARE _syouhizeigaku      decimal(12);
    DECLARE _syouhizeisagaku    decimal(12);
    DECLARE _seikyuusyoBangou   integer(6);
    DECLARE _kijun_kingaku      decimal(12);
    DECLARE _kaisyuu_mm1        tinyint(2);
    DECLARE _kaisyuu_dd1        tinyint(2);
    DECLARE _kaisyuu_mm2        tinyint(2);
    DECLARE _kaisyuu_dd2        tinyint(2);
    DECLARE _nyuukinnsyubetu1     tinyint(2);
    DECLARE _nyuukinnsyubetu2     tinyint(2);
    DECLARE _seikyuu_kingaku    decimal(12);
    DECLARE _hontai_kingaku     decimal(12);
    DECLARE _syouhizeiKei       decimal(12);
    DECLARE _seikyuu_kingaku1   decimal(12);
    -- DECLARE _hontai_kingaku1    decimal(12);
    -- DECLARE _syouhizeiKei1      decimal(12);
    DECLARE _seikyuu_kingaku2   decimal(12);
    -- DECLARE _hontai_kingaku2    decimal(12);
    -- DECLARE _syouhizeiKei2      decimal(12);

    DECLARE _wDate              date;
    DECLARE _wDate1             date;
    DECLARE _wDate2             date;
    DECLARE _counter            integer(6);

    DECLARE _aa                 tinyint DEFAULT 0;
    DECLARE done                INT DEFAULT 0;

    DECLARE curSeikyuuH CURSOR FOR
        select
             DSEH.seikyuusakiCD         AS seikyuusakiCD
            ,sum(DSEH.uriagegaku)       AS uriagegaku
            ,sum(DSEH.hennpinngaku)     AS hennpinngaku
            ,sum(DSEH.nebikigaku)       AS nebikigaku
            ,sum(DSEH.nyuukinngaku)     AS nyuukinngaku
            ,sum(DSEH.syouhizeigaku)    AS syouhizeigaku
            ,sum(DSEH.syouhizeisagaku)  AS syouhizeisagaku
            ,min(DSEH.seikyuusyoBangou) AS seikyuusyoBangou
            ,min(MSEI.kijun_kingaku)    AS kijun_kingaku
            ,min(MSEI.kaisyuu_mm1)      AS kaisyuu_mm1
            ,min(MSEI.kaisyuu_dd1)      AS kaisyuu_dd1
            ,min(MSEI.kaisyuu_mm2)      AS kaisyuu_mm2
            ,min(MSEI.kaisyuu_dd2)      AS kaisyuu_dd2
            ,min(MSEI.nyuukinnsyubetu1)   AS nyuukinnsyubetu1
            ,min(MSEI.nyuukinnsyubetu2)   AS nyuukinnsyubetu2
        from DseikyuuHead DSEH
        inner join Mtokuisaki as MSEI -- 請求先
        on MSEI.tokuisakiCD   = DSEH.seikyuusakiCD
        where
            DSEH.kaikeiNendo        = _i_kaikei_nendo
            and DSEH.seikyuunengetu = _i_seikyuunengetu
            and DSEH.simebi         = _i_simeBi
            and (_i_seikyuusakiFrom = 0 or DSEH.seikyuusakiCD >= _i_seikyuusakiFrom) -- 2013/06/09
            and (_i_seikyuusakiTo = 0   or DSEH.seikyuusakiCD <= _i_seikyuusakiTo)   -- 2013/06/09
             -- 2013/06/09 and MSEI.kaisyuu_mm1    <> 0    -- 回収月1が入力されてない場合は回収予定データの作成は無し。
            and MSEI.kaisyuu_dd1    <> 0 -- 回収日1が入力されてない場合は回収予定データの作成は無し。
            and DSEH.seikyuukakuteidate IS NULL -- 2014/02/07
        Group by DSEH.seikyuusakiCD;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =============================================================================
       請求ヘッダ  請求確定日時・次回繰越額更新
     ========================================================================= */
    update DseikyuuHead
        set
         jikaikurikosigaku = ZENZAN + uriagegaku + hennpinngaku + nebikigaku - nyuukinngaku + syouhizeigaku + syouhizeisagaku
    where
        kaikeiNendo    = _i_kaikei_nendo
    and seikyuunengetu = _i_seikyuunengetu
    and simebi         = _i_simeBi
    and (_i_seikyuusakiFrom = 0 or seikyuusakiCD >= _i_seikyuusakiFrom) -- 2014/02/07
    and (_i_seikyuusakiTo = 0   or seikyuusakiCD <= _i_seikyuusakiTo)   -- 2014/02/07
    and seikyuukakuteidate IS NULL -- 2014/02/07
    ;

    /* =============================================================================
       回収予定データ生成
     ========================================================================= */
    OPEN curSeikyuuH;

    REPEAT
    FETCH curSeikyuuH
    INTO _seikyuusakiCD, _uriagegaku, _hennpinngaku, _nebikigaku, _nyuukinngaku, _syouhizeigaku, _syouhizeisagaku, _seikyuusyoBangou, _kijun_kingaku, _kaisyuu_mm1, _kaisyuu_dd1, _kaisyuu_mm2, _kaisyuu_dd2, _nyuukinnsyubetu1, _nyuukinnsyubetu2;
    IF done = 0 THEN
        /* 2013/09/23 start
        入金額は回収予定としては加味しない。発生している入金額はどこかの回収予定でで消し込まれてる。
        SET _seikyuu_kingaku = _uriagegaku + _hennpinngaku + _nebikigaku - _nyuukinngaku + _syouhizeigaku + _syouhizeisagaku;
        SET _hontai_kingaku  = _uriagegaku + _hennpinngaku + _nebikigaku - _nyuukinngaku;
        */
        SET _seikyuu_kingaku = _uriagegaku + _hennpinngaku + _nebikigaku + _syouhizeigaku + _syouhizeisagaku;
        SET _hontai_kingaku  = _uriagegaku + _hennpinngaku + _nebikigaku ;
        SET _syouhizeiKei    = _syouhizeigaku + _syouhizeisagaku;
        -- 2013/09/23 end

        -- 回収予定日1算出
        IF _kaisyuu_dd1 <> 31 THEN
            SET _wDate1 = _i_seikyuunengetu * 100 + _kaisyuu_dd1;
            if _wDate1 IS NULL THEN
                SET _wDate1 = _i_seikyuunengetu * 100 + 1;
                SET _wDate1 = LAST_DAY(_wDate1);
            end if;
            SET _wDate1 = _wDate1 + INTERVAL _kaisyuu_mm1 MONTH;
        ELSE
            SET _wDate1 = _i_seikyuunengetu * 100 + 1;
            SET _wDate1 = _wDate1 + INTERVAL _kaisyuu_mm1 MONTH;
            SET _wDate1 = LAST_DAY(_wDate1);
        END IF;

        -- 回収予定日2算出
        IF _kaisyuu_mm2 <> 0 AND _kaisyuu_dd2 <> 0 THEN
            IF _kaisyuu_dd2 <> 31 THEN
                SET _wDate2 = _i_seikyuunengetu * 100 + _kaisyuu_dd2;
                if _wDate1 IS NULL THEN
                    SET _wDate2 = _i_seikyuunengetu * 100 + 1;
                    SET _wDate2 = LAST_DAY(_wDate2);
                end if;
                SET _wDate2 = _wDate2 + INTERVAL _kaisyuu_mm2 MONTH;
            ELSE
                SET _wDate2 = _i_seikyuunengetu * 100 + 1;
                SET _wDate2 = _wDate2 + INTERVAL _kaisyuu_mm2 MONTH;
                SET _wDate2 = LAST_DAY(_wDate2);
            END IF;
        ELSE
            SET _wDate2 = _wDate1;
        END IF;

        IF _seikyuu_kingaku > _kijun_kingaku and _kijun_kingaku <> 0 THEN
        /* 基準金額が存在して請求額が上回っている時に回収予定が分割される。 */
            SET _seikyuu_kingaku1 = _kijun_kingaku;
            SET _seikyuu_kingaku2 = _seikyuu_kingaku - _kijun_kingaku;
        ELSE
            SET _seikyuu_kingaku1 = _seikyuu_kingaku;
            SET _seikyuu_kingaku2 = 0;
        END IF;

        select count(*) INTO _counter from Dkaisyuuyotei where seikyuusakiCD = _seikyuusakiCD and kaisyuuyoteidate = _wDate1 and nyuukinnsyubetu = _nyuukinnsyubetu1 and simebi = _i_simeBi;
        IF _counter = 0 THEN
            insert into Dkaisyuuyotei (
                 seikyuusakiCD
                ,kaisyuuyoteidate
                ,nyuukinnsyubetu
                ,kaisyuuyoteigaku
                ,hontai_kingaku
                ,syouhizei
                ,nyuukin_kesikomigaku
                ,seikyuunengetu
                ,simebi
                ,seikyuusyoBangou
                ,kanryouKBN       -- 2013/06/09
                ,tegataBangou
                ,tegataKijitu
                ,tegataFuridasinin
                ,insertdate
                ,insertTantosya
            ) values (
                 _seikyuusakiCD
                ,_wDate1
                ,_nyuukinnsyubetu1
                ,_seikyuu_kingaku1
                ,_hontai_kingaku
                ,_syouhizeiKei
                ,0
                ,_i_seikyuunengetu
                ,_i_simeBi
                ,_seikyuusyoBangou
                ,0
                ,''
                ,'2000-01-01'
                ,''
                ,_i_insertdate
                ,_i_insertTantosya
            );
        END IF;

        IF _seikyuu_kingaku > _kijun_kingaku and _kijun_kingaku <> 0 THEN
        /* 基準金額が存在して請求額が上回っている時に回収予定が分割される。 */
        -- 入金が分割される場合
            select count(*) INTO _counter from Dkaisyuuyotei where seikyuusakiCD = _seikyuusakiCD and kaisyuuyoteidate = _wDate2 and nyuukinnsyubetu = _nyuukinnsyubetu2 and simebi = _i_simeBi;
            IF _counter = 0 THEN
                insert into Dkaisyuuyotei (
                     seikyuusakiCD
                    ,kaisyuuyoteidate
                    ,nyuukinnsyubetu
                    ,kaisyuuyoteigaku
                    ,hontai_kingaku
                    ,syouhizei
                    ,nyuukin_kesikomigaku
                    ,seikyuunengetu
                    ,simebi
                    ,seikyuusyoBangou
                    ,kanryouKBN       -- 2013/06/09
                    ,tegataBangou
                    ,tegataKijitu
                    ,tegataFuridasinin
                    ,insertdate
                    ,insertTantosya
                ) values (
                     _seikyuusakiCD
                    ,_wDate2
                    ,_nyuukinnsyubetu2
                    ,_seikyuu_kingaku2
                    ,0
                    ,0
                    ,0
                    ,_i_seikyuunengetu
                    ,_i_simeBi
                    ,_seikyuusyoBangou
                    ,0
                    ,''
                    ,'2000-01-01'
                    ,''
                    ,_i_insertdate
                    ,_i_insertTantosya
                );
            END IF;
        END IF;
    END IF;
    UNTIL done END REPEAT;
    CLOSE curSeikyuuH;

    /* =============================================================================
       請求ヘッダ  請求確定日時・次回繰越額更新
     ========================================================================= */
    update DseikyuuHead
        set
         kakuteiKBN = 1
        ,seikyuukakuteidate = Now()
    where
        kaikeiNendo    = _i_kaikei_nendo
    and seikyuunengetu = _i_seikyuunengetu
    and simebi         = _i_simeBi
    and (_i_seikyuusakiFrom = 0 or seikyuusakiCD >= _i_seikyuusakiFrom) -- 2014/02/07
    and (_i_seikyuusakiTo = 0   or seikyuusakiCD <= _i_seikyuusakiTo)   -- 2014/02/07
    and seikyuukakuteidate IS NULL -- 2014/02/07
    ;
    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
