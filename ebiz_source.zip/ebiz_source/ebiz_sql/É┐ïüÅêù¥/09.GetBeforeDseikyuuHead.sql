DROP PROCEDURE IF EXISTS GetBeforeDseikyuuHead;
DELIMITER //
CREATE PROCEDURE GetBeforeDseikyuuHead(
    IN  _I_seikyuusakiCD            integer(6),
    OUT _O_seikyuusakiCD           integer(6),
    OUT _O_kaikeinendo             integer(4),
    OUT _O_seikyuunengetu          integer(6),
    OUT _O_simeBi                  tinyint,
    OUT _O_uriagedateFrom          date,
    OUT _O_uriagedateTo            date,
    OUT _O_ZENZAN                  decimal(12),
    OUT _O_uriagegaku              decimal(12),
    OUT _O_hennpinngaku            decimal(12),
    OUT _O_nebikigaku              decimal(12),
    OUT _O_nyuukinngaku            decimal(12),
    OUT _O_syouhizeigaku           decimal(12),
    OUT _O_syouhizeisagaku         decimal(12),
    OUT _O_hakkouKBN               tinyint,
    OUT _O_kakuteiKBN              tinyint,
    OUT _O_seikyuusyoBangou        integer(6),
    OUT _O_seikyuusyohakkoudate    datetime,
    OUT _O_seikyuukakuteidate      datetime,
    OUT _O_jikaikurikosigaku       decimal(12)
)
BEGIN
/*
	前回の請求情報を取得します
*/
    select
         SKYH.seikyuusakiCD
        ,SKYH.kaikeiNendo
        ,SKYH.seikyuunengetu
        ,SKYH.simebi
        ,SKYH.uriagedateFrom
        ,SKYH.uriagedateTo
        ,SKYH.ZENZAN
        ,SKYH.uriagegaku
        ,SKYH.hennpinngaku
        ,SKYH.nebikigaku
        ,SKYH.nyuukinngaku
        ,SKYH.syouhizeigaku
        ,SKYH.syouhizeisagaku
        ,SKYH.hakkouKBN
        ,SKYH.kakuteiKBN
        ,SKYH.seikyuusyoBangou
        ,SKYH.seikyuusyohakkoudate
        ,SKYH.seikyuukakuteidate
        ,SKYH.jikaikurikosigaku
        into
         _O_seikyuusakiCD
        ,_O_kaikeinendo
        ,_O_seikyuunengetu
        ,_O_simeBi
        ,_O_uriagedateFrom
        ,_O_uriagedateTo
        ,_O_ZENZAN
        ,_O_uriagegaku
        ,_O_hennpinngaku
        ,_O_nebikigaku
        ,_O_nyuukinngaku
        ,_O_syouhizeigaku
        ,_O_syouhizeisagaku
        ,_O_hakkouKBN
        ,_O_kakuteiKBN
        ,_O_seikyuusyoBangou
        ,_O_seikyuusyohakkoudate
        ,_O_seikyuukakuteidate
        ,_O_jikaikurikosigaku
    from DseikyuuHead as SKYH
    inner join (
        select
             SKYH1.seikyuusakiCD
            ,MAX(SKYH1.kaikeiNendo) as kaikeiNendo
        from DseikyuuHead as SKYH1
        group by
             SKYH1.seikyuusakiCD
    ) as KKND  -- 会計年度最大値
    on KKND.seikyuusakiCD = SKYH.seikyuusakiCD
    inner join (
        select
             SKYH2.seikyuusakiCD
            ,SKYH2.kaikeiNendo
            ,MAX(SKYH2.seikyuunengetu) as seikyuunengetu
        from DseikyuuHead as SKYH2
        group by
             SKYH2.seikyuusakiCD
            ,SKYH2.kaikeiNendo
    ) as SKYM  -- 請求年月最大値
    on  SKYM.seikyuusakiCD = KKND.seikyuusakiCD
    and SKYM.kaikeiNendo   = KKND.kaikeiNendo
    inner join (
        select
             SKYH3.seikyuusakiCD
            ,SKYH3.kaikeiNendo
            ,SKYH3.seikyuunengetu
            ,MAX(SKYH3.simebi) as simebi
        from DseikyuuHead as SKYH3
        group by
             SKYH3.seikyuusakiCD
            ,SKYH3.kaikeiNendo
            ,SKYH3.seikyuunengetu
    ) as SMBI  -- 締日最大値
    on  SMBI.seikyuusakiCD    = SKYM.seikyuusakiCD
    and SMBI.kaikeiNendo      = SKYM.kaikeiNendo
    and SMBI.seikyuunengetu   = SKYM.seikyuunengetu
    and SMBI.simebi           = SKYH.simebi

    where SKYH.seikyuusakiCD = _I_seikyuusakiCD
    and SKYH.seikyuusakiCD   = SMBI.seikyuusakiCD
    and SKYH.kaikeiNendo     = SMBI.kaikeiNendo
    and SKYH.seikyuunengetu  = SMBI.seikyuunengetu
    and SKYH.simebi          = SMBI.simebi    ;

    IF _O_seikyuusakiCD IS NULL THEN
        SET _O_seikyuusakiCD = 0;
    END IF;
    IF _O_kaikeinendo IS NULL THEN
        SET _O_kaikeinendo = 0;
    END IF;
    IF _O_seikyuunengetu IS NULL THEN
        SET _O_seikyuunengetu = 0;
    END IF;
    IF _O_simeBi IS NULL THEN
        SET _O_simeBi = 0;
    END IF;
    IF _O_uriagedateFrom IS NULL THEN
        SET _O_uriagedateFrom = 0;
    END IF;
    IF _O_uriagedateTo IS NULL THEN
        SET _O_uriagedateTo = 0;
    END IF;
    IF _O_ZENZAN IS NULL THEN
        SET _O_ZENZAN = 0;
    END IF;
    IF _O_uriagegaku IS NULL THEN
        SET _O_uriagegaku = 0;
    END IF;
    IF _O_hennpinngaku IS NULL THEN
        SET _O_hennpinngaku = 0;
    END IF;
    IF _O_nebikigaku IS NULL THEN
        SET _O_nebikigaku = 0;
    END IF;
    IF _O_nyuukinngaku IS NULL THEN
        SET _O_nyuukinngaku = 0;
    END IF;
    IF _O_syouhizeigaku IS NULL THEN
        SET _O_syouhizeigaku = 0;
    END IF;
    IF _O_syouhizeisagaku IS NULL THEN
        SET _O_syouhizeisagaku = 0;
    END IF;
    IF _O_hakkouKBN IS NULL THEN
        SET _O_hakkouKBN = 0;
    END IF;
    IF _O_kakuteiKBN IS NULL THEN
        SET _O_kakuteiKBN = 0;
    END IF;
    IF _O_seikyuusyoBangou IS NULL THEN
        SET _O_seikyuusyoBangou = 0;
    END IF;
    IF _O_seikyuusyohakkoudate IS NULL THEN
        SET _O_seikyuusyohakkoudate = 0;
    END IF;
    IF _O_seikyuukakuteidate IS NULL THEN
        SET _O_seikyuukakuteidate = 0;
    END IF;
    IF _O_jikaikurikosigaku IS NULL THEN
        SET _O_jikaikurikosigaku = 0;
    END IF;

    SET _O_jikaikurikosigaku = _O_ZENZAN
                                + _O_uriagegaku
                                + _O_hennpinngaku
                                + _O_nebikigaku
                                - _O_nyuukinngaku
                                + _O_syouhizeigaku
                                + _O_syouhizeisagaku;

    /* 前回請求情報の次回繰越額更新 */
    UPDATE DseikyuuHead SET jikaikurikosigaku = _O_jikaikurikosigaku
    where
                seikyuusakiCD   = _O_seikyuusakiCD
            and kaikeiNendo     = _O_kaikeinendo
            and seikyuunengetu  = _O_seikyuunengetu
            and simebi          = _O_simeBi;

END;
//
DELIMITER ;
