DROP PROCEDURE IF EXISTS seikyuuMaeShori;
DELIMITER //
CREATE PROCEDURE seikyuuMaeShori(
    IN _i_seikyuusakiCD1     integer(6),
    IN _i_seikyuusakiCD2     integer(6),
    IN _i_seikyuusakiCD3     integer(6),
    IN _i_seikyuusakiCD4     integer(6),
    IN _i_seikyuusakiCD5     integer(6),
    IN _i_seikyuusakiCD6     integer(6),
    IN _i_seikyuusakiCD7     integer(6),
    IN _i_seikyuusakiCD8     integer(6),
    IN _i_seikyuusakiCD9     integer(6),
    IN _i_seikyuusakiCD10    integer(6),
    IN _i_seikyuusakiFrom    integer(6),
    IN _i_seikyuusakiTo      integer(6),
    IN _i_seikyuunengetu     integer(6),
    IN _i_seikyuuDateFrom    date,
    IN _i_seikyuuDateTo      date,
    IN _i_simeBi             tinyint,
    IN _i_insertdate         date,
    IN _i_insertTantosya     integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
       請求ヘッダ削除
       今回作成する請求ヘッダだが、過去に請求前処理のみされていて今回再度前処理をかけるものを削除
     ========================================================================= */
     call seikyuuMaeShori_01_delete_DseikyuuHead(
            _i_seikyuusakiFrom,  -- 2014/02/07
            _i_seikyuusakiTo,    -- 2014/02/07
            _i_seikyuusakiCD1,
            _i_seikyuusakiCD2,
            _i_seikyuusakiCD3,
            _i_seikyuusakiCD4,
            _i_seikyuusakiCD5,
            _i_seikyuusakiCD6,
            _i_seikyuusakiCD7,
            _i_seikyuusakiCD8,
            _i_seikyuusakiCD9,
            _i_seikyuusakiCD10,
            _i_seikyuunengetu,
            _i_seikyuuDateFrom,
            _i_seikyuuDateTo,
            _i_simeBi,
            _i_insertdate,
            _i_insertTantosya,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    /* =========================================================================
       売上データ内消費税誤差データを削除
       過去に請求前処理のみされていて今回再度前処理をかけるものを削除
    ========================================================================= */
    delete DURI
    from DUriage as DURI
    inner join SUriage as SURI  -- 今回請求対象のデータを抽出済み
    on  SURI.kaikeiNendo = DURI.kaikeiNendo
    and SURI.denpyouNO   = DURI.denpyouNO
    and SURI.gyouNO      = DURI.gyouNO
    where DURI.dataKBN     = 50
    and   DURI.torihikiKBN = 82
    and   DURI.uriageKBN   = 80; -- 請求単位消費税

    /* =========================================================================
       今回請求・入金データより今回請求分請求ヘッダを作成
    ========================================================================= */
    call seikyuuMaeShori_02_insert_DseikyuuHead(
            _i_seikyuunengetu,
            _i_simeBi,
            _i_insertdate,
            _i_insertTantosya,
            _i_seikyuuDateFrom,
            _i_seikyuuDateTo,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    /* =========================================================================
       売上・入金データに請求書番号を更新
     ========================================================================= */
     call seikyuuMaeShori_03_update_UriNyuukin(
            _i_seikyuunengetu,
            _i_simeBi,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    /* =========================================================================
       消費税が請求一括の請求先の消費税差額データを算出する
     ========================================================================= */
     call seikyuuMaeShori_04_insert_zeiSagaku(
            _i_seikyuunengetu,
            _i_simeBi,
            _i_insertdate,
            _i_insertTantosya,
            _ErrorMsg,
            _Result
        );
    set _o_Result   = _Result;
    set _o_ErrorMsg = _ErrorMsg;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
