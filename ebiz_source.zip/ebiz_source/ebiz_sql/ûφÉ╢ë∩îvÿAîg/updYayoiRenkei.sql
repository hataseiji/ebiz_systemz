DROP PROCEDURE IF EXISTS updYayoiRenkei;
DELIMITER //
CREATE PROCEDURE updYayoiRenkei(
    IN _i_syori_yyyymm       integer(6),
    IN _i_torihikiDatefr     date,
    IN _i_torihikiDateto     date,
    IN _i_path               varchar(1024),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN

	DECLARE _path    varchar(1024);

	set _o_Result = 0;
	set _o_ErrorMsg = '予期しないエラーが発生しました。';

	/* 出力ファイル名取得 */
	select concat('"', _i_path, '/', 'Yayoi', now(), '.csv', '"') into _path;

	/* =========================================================================
	 一時テーブル生成 今回対象データ
	 ========================================================================= */
	drop table if exists SYayoiRenkei;
	create temporary table SYayoiRenkei
	select
		sikibetuFLG,
		denpyouNO,
		kessan,
		torihikiDate,
		kkKanjouNM,
		kkHojoNM,
		kkBumonNM,
		kkZeiKBN,
		kkKingaku,
		kkZeigaku,
		ksKanjouNM,
		ksHojoNM,
		ksBumonNM,
		ksZeiKBN,
		ksKingaku,
		ksZeigaku,
		tekiyou,
		bangou,
		kijiutu,
		type,
		seiseiMoto,
		siwakeMemo,
		fusen1,
		fusen2,
		tyousei
	from Dsiwakelog
	where 1 = 1
	and  Dsiwakelog.kaikeiRenkeiDate IS NULL
	and  (_i_syori_yyyymm = 0 or Dsiwakelog.keijounengetu = _i_syori_yyyymm)
	and  (_i_torihikiDatefr = 0 or Dsiwakelog.torihikiDate >= _i_torihikiDatefr)
	and  (_i_torihikiDateto = 0 or Dsiwakelog.torihikiDate <= _i_torihikiDateto)
	;

	SET @query = CONCAT("select * from SYayoiRenkei INTO OUTFILE ", _path , "FIELDS TERMINATED BY \',\' OPTIONALLY ENCLOSED BY \'\"\' ");
	PREPARE statement FROM @query;
	EXECUTE statement;

	update Dsiwakelog
	set kaikeiRenkeiDate = CURRENT_TIMESTAMP()
	where 1 = 1
	and  Dsiwakelog.kaikeiRenkeiDate IS NULL
	and  (_i_syori_yyyymm = 0 or Dsiwakelog.keijounengetu = _i_syori_yyyymm)
	and  (_i_torihikiDatefr = 0 or Dsiwakelog.torihikiDate >= _i_torihikiDatefr)
	and  (_i_torihikiDateto = 0 or Dsiwakelog.torihikiDate <= _i_torihikiDateto)
	;


    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
