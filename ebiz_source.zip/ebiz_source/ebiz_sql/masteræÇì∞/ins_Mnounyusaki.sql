DROP PROCEDURE IF EXISTS ins_Mnounyusaki;
DELIMITER //
CREATE PROCEDURE ins_Mnounyusaki (
     IN _i_tokuisakiCD                       integer(6),
     IN _i_nounyuusakiCD                     integer(6),
     IN _i_nounyuusakiNM                     varchar(40),
     IN _i_nounyuusakiRNM                    varchar(20),
     IN _i_nounyuusakiKNM                    varchar(20),
     IN _i_syokutiKBN                        tinyint(1),
     IN _i_postalCD                          varchar(8),
     IN _i_address1                          varchar(40),
     IN _i_address2                          varchar(40),
     IN _i_tel1                              varchar(20),
     IN _i_naisen1                           varchar(10),
     IN _i_tel2                              varchar(20),
     IN _i_naisen2                           varchar(10),
     IN _i_fax                               varchar(20),
     IN _i_nounyuusaki_tantousyaNM           varchar(40),
     IN _i_nounyuusaki_tantousyabusyoNM      varchar(20),
     IN _i_nounyuusaki_tantousyayakusyokuNM  varchar(24),
     IN _i_totalization1                     varchar(9),
     IN _i_totalization2                     varchar(9),
     IN _i_totalization3                     varchar(9),
     IN _i_insertdate                        datetime,
     IN _i_insertTantosya                    integer(6),
     IN _i_updatedate                        datetime,
     IN _i_updateTantosya                    integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Mnounyusaki where tokuisakiCD = _i_tokuisakiCD and  nounyuusakiCD = _i_nounyuusakiCD;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Mnounyusaki (
            tokuisakiCD                       ,
            nounyuusakiCD                     ,
            nounyuusakiNM                     ,
            nounyuusakiRNM                    ,
            nounyuusakiKNM                    ,
            syokutiKBN                        ,
            postalCD                          ,
            address1                          ,
            address2                          ,
            tel1                              ,
            naisen1                           ,
            tel2                              ,
            naisen2                           ,
            fax                               ,
            nounyuusaki_tantousyaNM           ,
            nounyuusaki_tantousyabusyoNM      ,
            nounyuusaki_tantousyayakusyokuNM  ,
            totalization1                     ,
            totalization2                     ,
            totalization3                     ,
            insertdate                        ,
            insertTantosya                    ,
            updatedate                        ,
            updateTantosya                    
        )
        values
        (
            _i_tokuisakiCD                       ,
            _i_nounyuusakiCD                     ,
            _i_nounyuusakiNM                     ,
            _i_nounyuusakiRNM                    ,
            _i_nounyuusakiKNM                    ,
            _i_syokutiKBN                        ,
            _i_postalCD                          ,
            _i_address1                          ,
            _i_address2                          ,
            _i_tel1                              ,
            _i_naisen1                           ,
            _i_tel2                              ,
            _i_naisen2                           ,
            _i_fax                               ,
            _i_nounyuusaki_tantousyaNM           ,
            _i_nounyuusaki_tantousyabusyoNM      ,
            _i_nounyuusaki_tantousyayakusyokuNM  ,
            _i_totalization1                     ,
            _i_totalization2                     ,
            _i_totalization3                     ,
            _i_insertdate                        ,
            _i_insertTantosya                    ,
            _i_insertdate                        ,
            _i_insertTantosya                    
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
