DROP PROCEDURE IF EXISTS ins_Sjikkoujoutai;
DELIMITER //
CREATE PROCEDURE ins_Sjikkoujoutai (
     IN _i_programID   varchar(128),
     IN _i_tanmatuID   varchar(128),
     IN _i_insertDate  datetime,
     IN _i_updateDate  datetime,
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
        -- データ更新
        insert into Sjikkoujoutai (
            programID   ,
            tanmatuID   ,
            insertDate  ,
            updateDate  
        )
        values
        (
            _i_programID   ,
            _i_tanmatuID   ,
            _i_insertDate  ,
            _i_updateDate  
        );
    -- データ存在チェック
    set _o_ErrorMsg = '';
    set _o_Result = 1;
END;
//
DELIMITER ;
