DROP PROCEDURE IF EXISTS ins_Mkanri;
DELIMITER //
CREATE PROCEDURE ins_Mkanri (
     IN _i_kanriCD            tinyint(1),
     IN _i_kaisyaNM           varchar(40),
     IN _i_kaisyaRNM          varchar(20),
     IN _i_kaisyaKNM          varchar(40),
     IN _i_postalCD           varchar(8),
     IN _i_address1           varchar(40),
     IN _i_address2           varchar(40),
     IN _i_tel                varchar(20),
     IN _i_fax                varchar(20),
     IN _i_innjiyou_kaisyaNM  varchar(40),
     IN _i_kisyudate          date,
     IN _i_kisyu_yyyymm       date,
     IN _i_kaikei_nendo       integer(4),
     IN _i_kaikei_year        integer(4),
     IN _i_kaikei_yyyymm      integer(6),
     IN _i_keikatu_kisuu      tinyint(2),
     IN _i_kessan_kisu        integer(3),
     IN _i_seirekiwarekiKBN   tinyint(1),
     IN _i_hozontukisuu1      integer(3),
     IN _i_hozontukisuu2      integer(3),
     IN _i_hozontukisuu3      integer(3),
     IN _i_hozontukisuu4      integer(3),
     IN _i_hozontukisuu5      integer(3),
     IN _i_hozontukisuu6      integer(3),
     IN _i_hozontukisuu7      integer(3),
     IN _i_hozontukisuu8      integer(3),
     IN _i_seikyuu_kariFLG    tinyint(1),
     IN _i_siharai_kariFLG    tinyint(1),
     IN _i_getuji_kariFLG     tinyint(1),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Mkanri where kanriCD = _i_kanriCD;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Mkanri (
            kanriCD            ,
            kaisyaNM           ,
            kaisyaRNM          ,
            kaisyaKNM          ,
            postalCD           ,
            address1           ,
            address2           ,
            tel                ,
            fax                ,
            innjiyou_kaisyaNM  ,
            kisyudate          ,
            kisyu_yyyymm       ,
            kaikei_nendo       ,
            kaikei_year        ,
            kaikei_yyyymm      ,
            keikatu_kisuu      ,
            kessan_kisu        ,
            seirekiwarekiKBN   ,
            hozontukisuu1      ,
            hozontukisuu2      ,
            hozontukisuu3      ,
            hozontukisuu4      ,
            hozontukisuu5      ,
            hozontukisuu6      ,
            hozontukisuu7      ,
            hozontukisuu8      ,
            seikyuu_kariFLG    ,
            siharai_kariFLG    ,
            getuji_kariFLG     
        )
        values
        (
            _i_kanriCD            ,
            _i_kaisyaNM           ,
            _i_kaisyaRNM          ,
            _i_kaisyaKNM          ,
            _i_postalCD           ,
            _i_address1           ,
            _i_address2           ,
            _i_tel                ,
            _i_fax                ,
            _i_innjiyou_kaisyaNM  ,
            _i_kisyudate          ,
            _i_kisyu_yyyymm       ,
            _i_kaikei_nendo       ,
            _i_kaikei_year        ,
            _i_kaikei_yyyymm      ,
            _i_keikatu_kisuu      ,
            _i_kessan_kisu        ,
            _i_seirekiwarekiKBN   ,
            _i_hozontukisuu1      ,
            _i_hozontukisuu2      ,
            _i_hozontukisuu3      ,
            _i_hozontukisuu4      ,
            _i_hozontukisuu5      ,
            _i_hozontukisuu6      ,
            _i_hozontukisuu7      ,
            _i_hozontukisuu8      ,
            _i_seikyuu_kariFLG    ,
            _i_siharai_kariFLG    ,
            _i_getuji_kariFLG     
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
