DROP PROCEDURE IF EXISTS sel_Mjigyosyo;
DELIMITER //
CREATE PROCEDURE sel_Mjigyosyo (
     IN _i_jigyosyoCD      tinyint(2)
    ,OUT _o_ErrorMsg       varchar(256)
    ,OUT _o_Result         Boolean
)
BEGIN
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '';
    
    select * from Mjigyosyo where jigyosyoCD = _i_jigyosyoCD;
    if _counter = 0 then
        set _o_ErrorMsg = 'マスタに存在しないコードです。';
    else
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
