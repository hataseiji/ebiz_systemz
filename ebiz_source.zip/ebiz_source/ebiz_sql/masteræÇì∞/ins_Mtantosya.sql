DROP PROCEDURE IF EXISTS ins_Mtantosya;
DELIMITER //
CREATE PROCEDURE ins_Mtantosya (
     IN _i_tantosyaCD     integer(6),
     IN _i_tantosyaNM     varchar(40),
     IN _i_jigyosyoCD     tinyint(2),
     IN _i_bumonCD        varchar(5),
     IN _i_mobilePhone    varchar(20),
     IN _i_totalization1  varchar(9),
     IN _i_totalization2  varchar(9),
     IN _i_totalization3  varchar(9),
     IN _i_totalization4  varchar(9),
     IN _i_totalization5  varchar(9),
     IN _i_insertdate     datetime,
     IN _i_insertTantosya integer(6),
     IN _i_updatedate     datetime,
     IN _i_updateTantosya integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Mtantosya where tantosyaCD = _i_tantosyaCD;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Mtantosya (
            tantosyaCD     ,
            tantosyaNM     ,
            jigyosyoCD     ,
            bumonCD        ,
            mobilePhone    ,
            totalization1  ,
            totalization2  ,
            totalization3  ,
            totalization4  ,
            totalization5  ,
            insertdate     ,
            insertTantosya ,
            updatedate     ,
            updateTantosya 
        )
        values
        (
            _i_tantosyaCD     ,
            _i_tantosyaNM     ,
            _i_jigyosyoCD     ,
            _i_bumonCD        ,
            _i_mobilePhone    ,
            _i_totalization1  ,
            _i_totalization2  ,
            _i_totalization3  ,
            _i_totalization4  ,
            _i_totalization5  ,
            _i_insertdate     ,
            _i_insertTantosya ,
            _i_insertdate     ,
            _i_insertTantosya
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
