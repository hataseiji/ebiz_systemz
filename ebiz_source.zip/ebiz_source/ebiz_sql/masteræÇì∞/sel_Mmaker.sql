DROP PROCEDURE IF EXISTS sel_Mmaker;
DELIMITER //
CREATE PROCEDURE sel_Mmaker (
     IN _i_makerCD         integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select * from Mmaker where makerCD = _i_makerCD;
    if _counter = 0 then
        set _o_ErrorMsg = 'マスタに存在しないコードです。';
    else
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
