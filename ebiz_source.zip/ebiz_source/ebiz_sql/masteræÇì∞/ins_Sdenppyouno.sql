DROP PROCEDURE IF EXISTS ins_Sdenppyouno;
DELIMITER //
CREATE PROCEDURE ins_Sdenppyouno (
     IN _i_denpyouKBN  tinyint(1),
     IN _i_denpyouNO   integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Sdenppyouno where denpyouKBN = _i_denpyouKBN;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Sdenppyouno (
            denpyouKBN  ,
            denpyouNO   
        )
        values
        (
            _i_denpyouKBN  ,
            _i_denpyouNO   
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
