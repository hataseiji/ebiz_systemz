DROP PROCEDURE IF EXISTS sel_Mtani;
DELIMITER //
CREATE PROCEDURE sel_Mtani (
     IN _i_taniCD          tinyint(2),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select * from Mtani where taniCD = _i_taniCD;
    if _counter = 0 then
        set _o_ErrorMsg = 'マスタに存在しないコードです。';
    else
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
