DROP PROCEDURE IF EXISTS ins_Msyouhin;
DELIMITER //
CREATE PROCEDURE ins_Msyouhin (
     IN _i_syouhinCD        varchar(10),
     IN _i_syouhinNM        varchar(40),
     IN _i_syouhinRNM       varchar(40),
     IN _i_kikaku           varchar(50),
     IN _i_kataban          varchar(20),
     IN _i_serialNO         varchar(30),
     IN _i_lotNO            varchar(30),
     IN _i_syokutiKBN       tinyint(1),
     IN _i_hinsyuCD         integer(6),
     IN _i_daibunruiCD      integer(6),
     IN _i_tyuubunruiCD     integer(6),
     IN _i_makerCD          integer(6),
     IN _i_siiresakiCD      integer(6),
     IN _i_totalization1    varchar(9),
     IN _i_totalization2    varchar(9),
     IN _i_totalization3    varchar(9),
     IN _i_totalization4    varchar(9),
     IN _i_totalization5    varchar(9),
     IN _i_taniCD           tinyint(2),
     IN _i_janCD            varchar(13),
     IN _i_barCD1           varchar(40),
     IN _i_barCD2           varchar(40),
     IN _i_barCD3           varchar(40),
     IN _i_iriSUU           decimal(10,3),
     IN _i_zaikokanriKBN    tinyint(1),
     IN _i_sethinKBN        tinyint(1),
     IN _i_sotoutiKBN       tinyint(1),
     IN _i_hyoujunzaikoTNK  bigint(10),
     IN _i_zeisyohinKBN     tinyint(1),
     IN _i_juryou           decimal(11,4),
     IN _i_size             varchar(10),
     IN _i_soukoCD          integer(6),
     IN _i_picturePASS      varchar(100),
     IN _i_yukoudate        date,
     IN _i_insertdate       datetime,
     IN _i_insertTantosya   integer(6),
     IN _i_updatedate       datetime,
     IN _i_updateTantosya   integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Msyouhin where syouhinCD = _i_syouhinCD;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Msyouhin (
            syouhinCD        ,
            syouhinNM        ,
            syouhinRNM       ,
            kikaku           ,
            kataban          ,
            serialNO         ,
            lotNO            ,
            syokutiKBN       ,
            hinsyuCD         ,
            daibunruiCD      ,
            tyuubunruiCD     ,
            makerCD          ,
            siiresakiCD      ,
            totalization1    ,
            totalization2    ,
            totalization3    ,
            totalization4    ,
            totalization5    ,
            taniCD           ,
            janCD            ,
            barCD1           ,
            barCD2           ,
            barCD3           ,
            iriSUU           ,
            zaikokanriKBN    ,
            sethinKBN        ,
            sotoutiKBN       ,
            hyoujunzaikoTNK  ,
            zeisyohinKBN     ,
            juryou           ,
            size             ,
            soukoCD          ,
            picturePASS      ,
            yukoudate        ,
            insertdate       ,
            insertTantosya   ,
            updatedate       ,
            updateTantosya   
        )
        values
        (
            _i_syouhinCD        ,
            _i_syouhinNM        ,
            _i_syouhinRNM       ,
            _i_kikaku           ,
            _i_kataban          ,
            _i_serialNO         ,
            _i_lotNO            ,
            _i_syokutiKBN       ,
            _i_hinsyuCD         ,
            _i_daibunruiCD      ,
            _i_tyuubunruiCD     ,
            _i_makerCD          ,
            _i_siiresakiCD      ,
            _i_totalization1    ,
            _i_totalization2    ,
            _i_totalization3    ,
            _i_totalization4    ,
            _i_totalization5    ,
            _i_taniCD           ,
            _i_janCD            ,
            _i_barCD1           ,
            _i_barCD2           ,
            _i_barCD3           ,
            _i_iriSUU           ,
            _i_zaikokanriKBN    ,
            _i_sethinKBN        ,
            _i_sotoutiKBN       ,
            _i_hyoujunzaikoTNK  ,
            _i_zeisyohinKBN     ,
            _i_juryou           ,
            _i_size             ,
            _i_soukoCD          ,
            _i_picturePASS      ,
            _i_yukoudate        ,
            _i_insertdate       ,
            _i_insertTantosya   ,
            _i_insertdate       ,
            _i_insertTantosya   
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
