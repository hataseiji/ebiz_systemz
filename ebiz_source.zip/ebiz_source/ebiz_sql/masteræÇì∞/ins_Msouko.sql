DROP PROCEDURE IF EXISTS ins_Msouko;
DELIMITER //
CREATE PROCEDURE ins_Msouko (
     IN _i_soukoCD         integer(6),
     IN _i_soukoNM         varchar(40),
     IN _i_soukoRNM        varchar(20),
     IN _i_soukoKNM        varchar(20),
     IN _i_postalCD        varchar(8),
     IN _i_address1        varchar(40),
     IN _i_address2        varchar(40),
     IN _i_tel1            varchar(20),
     IN _i_tel2            varchar(20),
     IN _i_fax             varchar(20),
     IN _i_soukoKBN        tinyint(1),
     IN _i_jigyosyoCD      tinyint(2),
     IN _i_jisyaKBN        tinyint(1),
     IN _i_insertdate      datetime,
     IN _i_insertTantosya  integer(6),
     IN _i_updatedate      datetime,
     IN _i_updateTantosya  integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Msouko where soukoCD = _i_soukoCD;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Msouko (
            soukoCD         ,
            soukoNM         ,
            soukoRNM        ,
            soukoKNM        ,
            postalCD        ,
            address1        ,
            address2        ,
            tel1            ,
            tel2            ,
            fax             ,
            soukoKBN        ,
            jigyosyoCD      ,
            jisyaKBN        ,
            insertdate      ,
            insertTantosya  ,
            updatedate      ,
            updateTantosya  
        )
        values
        (
            _i_soukoCD         ,
            _i_soukoNM         ,
            _i_soukoRNM        ,
            _i_soukoKNM        ,
            _i_postalCD        ,
            _i_address1        ,
            _i_address2        ,
            _i_tel1            ,
            _i_tel2            ,
            _i_fax             ,
            _i_soukoKBN        ,
            _i_jigyosyoCD      ,
            _i_jisyaKBN        ,
            _i_insertdate      ,
            _i_insertTantosya  ,
            _i_insertdate      ,
            _i_insertTantosya  
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
