DROP PROCEDURE IF EXISTS ins_Mtani;
DELIMITER //
CREATE PROCEDURE ins_Mtani (
     IN _i_taniCD          tinyint(2),
     IN _i_taniNM          varchar(8),
     IN _i_insertdate      datetime,
     IN _i_insertTantosya  integer(6),
     IN _i_updatedate      datetime,
     IN _i_updateTantosya  integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Mtani where taniCD = _i_taniCD;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Mtani (
            taniCD          ,
            taniNM          ,
            insertdate      ,
            insertTantosya  ,
            updatedate      ,
            updateTantosya  
        )
        values
        (
            _i_taniCD          ,
            _i_taniNM          ,
            _i_insertdate      ,
            _i_insertTantosya  ,
            _i_insertdate      ,
            _i_insertTantosya  
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
