DROP PROCEDURE IF EXISTS upd_Mhinsyu;
DELIMITER //
CREATE PROCEDURE upd_Mhinsyu (
     IN _i_hinsyuCD        integer(6),
     IN _i_hinsyuNM        varchar(40),
     IN _i_hinsyuKNM       varchar(40),
     IN _i_insertdate      datetime,
     IN _i_insertTantosya  integer(6),
     IN _i_updatedate      datetime,
     IN _i_updateTantosya  integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Mhinsyu where hinsyuCD = _i_hinsyuCD;
    if _counter = 0 then
        set _o_ErrorMsg = 'マスタに存在しないコードです。';
    else
        -- データ更新
        update Mhinsyu 
            set
            hinsyuNM         = _i_hinsyuNM        ,
            hinsyuKNM        = _i_hinsyuKNM       ,
            insertdate       = _i_insertdate      ,
            insertTantosya   = _i_insertTantosya  ,
            updatedate       = _i_updatedate      ,
            updateTantosya   = _i_updateTantosya  
            where hinsyuCD         = _i_hinsyuCD;
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
