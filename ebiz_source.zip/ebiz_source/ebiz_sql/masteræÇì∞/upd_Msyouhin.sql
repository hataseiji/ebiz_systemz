DROP PROCEDURE IF EXISTS upd_Msyouhin;
DELIMITER //
CREATE PROCEDURE upd_Msyouhin (
     IN _i_syouhinCD        varchar(10),
     IN _i_syouhinNM        varchar(40),
     IN _i_syouhinRNM       varchar(40),
     IN _i_kikaku           varchar(50),
     IN _i_kataban          varchar(20),
     IN _i_serialNO         varchar(30),
     IN _i_lotNO            varchar(30),
     IN _i_syokutiKBN       tinyint(1),
     IN _i_hinsyuCD         integer(6),
     IN _i_daibunruiCD      integer(6),
     IN _i_tyuubunruiCD     integer(6),
     IN _i_makerCD          integer(6),
     IN _i_siiresakiCD      integer(6),
     IN _i_totalization1    varchar(9),
     IN _i_totalization2    varchar(9),
     IN _i_totalization3    varchar(9),
     IN _i_totalization4    varchar(9),
     IN _i_totalization5    varchar(9),
     IN _i_taniCD           tinyint(2),
     IN _i_janCD            varchar(13),
     IN _i_barCD1           varchar(40),
     IN _i_barCD2           varchar(40),
     IN _i_barCD3           varchar(40),
     IN _i_iriSUU           decimal(10,3),
     IN _i_zaikokanriKBN    tinyint(1),
     IN _i_sethinKBN        tinyint(1),
     IN _i_sotoutiKBN       tinyint(1),
     IN _i_hyoujunzaikoTNK  bigint(10),
     IN _i_zeisyohinKBN     tinyint(1),
     IN _i_juryou           decimal(11,4),
     IN _i_size             varchar(10),
     IN _i_soukoCD          integer(6),
     IN _i_picturePASS      varchar(100),
     IN _i_yukoudate        date,
     IN _i_insertdate       datetime,
     IN _i_insertTantosya   integer(6),
     IN _i_updatedate       datetime,
     IN _i_updateTantosya   integer(6),
     OUT _o_ErrorMsg       varchar(256),
     OUT _o_Result         Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Msyouhin where syouhinCD = _i_syouhinCD;
    if _counter = 0 then
        set _o_ErrorMsg = 'マスタに存在しないコードです。';
    else
        -- データ更新
        update Msyouhin 
        set
            syouhinNM         = _i_syouhinNM        ,
            syouhinRNM        = _i_syouhinRNM       ,
            kikaku            = _i_kikaku           ,
            kataban           = _i_kataban          ,
            serialNO          = _i_serialNO         ,
            lotNO             = _i_lotNO            ,
            syokutiKBN        = _i_syokutiKBN       ,
            hinsyuCD          = _i_hinsyuCD         ,
            daibunruiCD       = _i_daibunruiCD      ,
            tyuubunruiCD      = _i_tyuubunruiCD     ,
            makerCD           = _i_makerCD          ,
            siiresakiCD       = _i_siiresakiCD      ,
            totalization1     = _i_totalization1    ,
            totalization2     = _i_totalization2    ,
            totalization3     = _i_totalization3    ,
            totalization4     = _i_totalization4    ,
            totalization5     = _i_totalization5    ,
            taniCD            = _i_taniCD           ,
            janCD             = _i_janCD            ,
            barCD1            = _i_barCD1           ,
            barCD2            = _i_barCD2           ,
            barCD3            = _i_barCD3           ,
            iriSUU            = _i_iriSUU           ,
            zaikokanriKBN     = _i_zaikokanriKBN    ,
            sethinKBN         = _i_sethinKBN        ,
            sotoutiKBN        = _i_sotoutiKBN       ,
            hyoujunzaikoTNK   = _i_hyoujunzaikoTNK  ,
            zeisyohinKBN      = _i_zeisyohinKBN     ,
            juryou            = _i_juryou           ,
            size              = _i_size             ,
            soukoCD           = _i_soukoCD          ,
            picturePASS       = _i_picturePASS      ,
            yukoudate         = _i_yukoudate        ,
            updatedate        = _i_updatedate       ,
            updateTantosya    = _i_updateTantosya   
        where syouhinCD         = _i_syouhinCD      ;

        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
