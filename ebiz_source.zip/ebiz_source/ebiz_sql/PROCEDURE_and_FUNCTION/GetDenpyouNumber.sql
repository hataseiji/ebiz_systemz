DROP PROCEDURE IF EXISTS GetDenpyouNumber;
DELIMITER //
CREATE PROCEDURE GetDenpyouNumber(
    IN  _I_dataKBN           integer(4),
    OUT _O_kaikei_yyyy       integer(4),
    OUT _O_DenpyouNumber     integer(6)
)
BEGIN
/*
    各伝票番号を採番します。
*/
    -- DECLARE _O_kaikei_yyyy   integer(6);
    DECLARE _counter integer;

    /* 管理マスタより会計年度を取得 */
    select kaikei_nendo into _O_kaikei_yyyy from MKanri where kanriCD = 1;

    /* 伝票番号管理マスタより伝票番号を採番 */
    -- 該当する伝票番号管理マスタが無い場合は insert する。
    select count(*) INTO _counter from Sdenpyouno where kaikeiNendo = _O_kaikei_yyyy and dataKBN = _I_dataKBN;
    IF _counter = 0 THEN
        insert into Sdenpyouno (kaikeiNendo,dataKBN,denpyouNO) values (_O_kaikei_yyyy,_I_dataKBN,'0');
    END IF;

    select  denpyouNO into _O_DenpyouNumber from Sdenpyouno
        where kaikeiNendo = _O_kaikei_yyyy and dataKBN = _I_dataKBN FOR UPDATE;

    -- 伝票番号をカウントアップして採用 (一周した場合は1から)
    SET _O_DenpyouNumber = _O_DenpyouNumber + 1;
    IF _O_DenpyouNumber <= 0 THEN
        SET _O_DenpyouNumber = 1;
    END IF;

    -- 伝票番号採番マスタに値を戻す
    UPDATE Sdenpyouno SET denpyouNO = _O_DenpyouNumber where  kaikeiNendo = _O_kaikei_yyyy and dataKBN = _I_dataKBN;

END;
//
DELIMITER ;
