DROP function IF EXISTS cal_KeijouDate;
DELIMITER //
CREATE function cal_KeijouDate (
	 _i_Date      date
) returns integer
/*
	会計年月と伝票年月日より計上年月を決定する
*/
BEGIN
	DECLARE _kaikei_yyyymm integer;

	if DAYOFYEAR(_i_Date) IS NULL then
		return 200001;
	end if;

	select kaikei_yyyymm into _kaikei_yyyymm from Mkanri where kanriCD=1;
	if DATE_FORMAT(_i_Date, '%Y%m') >= _kaikei_yyyymm then
		return DATE_FORMAT(_i_Date, '%Y%m');
	else
		return _kaikei_yyyymm;
	end if;
END;
//
DELIMITER ;
