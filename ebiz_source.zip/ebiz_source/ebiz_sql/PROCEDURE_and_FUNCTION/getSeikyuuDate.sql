DROP FUNCTION IF EXISTS getSeikyuuDate;
DELIMITER //
CREATE FUNCTION getSeikyuuDate(
    _I_uriageDate			date,
    _I_simebi				tinyint(2)
) returns date
    /* =========================================================================
		 売上日より請求日を算出する
     ========================================================================= */
BEGIN
    DECLARE _wDate                    date;
    DECLARE _yyyymm                   integer(6);

	IF day(_I_uriageDate)  > _I_simebi THEN
		SET _yyyymm = EXTRACT(YEAR_MONTH FROM _I_uriageDate + INTERVAL 1 MONTH);
	ELSE
		SET _yyyymm = EXTRACT(YEAR_MONTH FROM _I_uriageDate);
	END IF;
	IF _I_simebi = 31 THEN
		SET _wDate = date_format(_yyyymm * 100 + 1, '%Y-%m-%d');
		return last_day(_wDate);
	ELSE
		return date_format(_yyyymm * 100 + _I_simebi, '%Y-%m-%d');
	END IF;

END;
//
DELIMITER ;
