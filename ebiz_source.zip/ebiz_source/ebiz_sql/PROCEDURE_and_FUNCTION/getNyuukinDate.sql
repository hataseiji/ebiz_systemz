DROP FUNCTION IF EXISTS getNyuukinDate;
DELIMITER //
CREATE FUNCTION getNyuukinDate(
    _I_seikyuuDate			date,
    _I_yoteiM				tinyint(2),
    _I_yoteiD				tinyint(2)
) returns date
    /* =========================================================================
		 売上日より請求日を算出する
     ========================================================================= */
BEGIN
    DECLARE _wDate                    date;
    DECLARE _yyyymm                   integer(6);

	SET _yyyymm = EXTRACT(YEAR_MONTH FROM _I_seikyuuDate + INTERVAL _I_yoteiM MONTH);
	IF _I_yoteiD = 31 THEN
		SET _wDate = date_format(_yyyymm * 100 + 1, '%Y-%m-%d');
		return last_day(_wDate);
	ELSE
		return date_format(_yyyymm * 100 + _I_yoteiD, '%Y-%m-%d');
	END IF;

END;
//
DELIMITER ;
