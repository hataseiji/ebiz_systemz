DROP PROCEDURE IF EXISTS GetSTanka;
DELIMITER //
CREATE PROCEDURE GetSTanka(
    IN  _I_siiresakiCD              integer(6),
    IN  _I_syouhinCD                varchar(10),
    IN  _I_date                     date,
    OUT _O_tanka                    decimal(10)
)
BEGIN

    DECLARE _siiresakiCD     integer(6);
    DECLARE _syouhinCD       varchar(10);
    DECLARE _tekiyoudate     date;
    DECLARE _tanka           decimal(10);

    /*  仕入先別商品別単価取得 */
    drop table if exists SSSTanka;
    create temporary table SSSTanka
        SELECT SSST.siiresakiCD, SSST.syouhinCD
                ,MAX(SSST.tekiyoudate) AS tekiyoudate
        FROM MSiiresakiStanka SSST
        WHERE SSST.tekiyoudate <= _I_date
        GROUP BY SSST.siiresakiCD,SSST.syouhinCD;

    SELECT
        main.siiresakiCD, main.syouhinCD, main.tekiyoudate, main.tanka
        into
        _siiresakiCD    , _syouhinCD    , _tekiyoudate    , _tanka
    FROM MSiiresakiStanka AS main
    INNER JOIN SSSTanka   AS sub
    ON  main.siiresakiCD  = sub.siiresakiCD
    AND main.syouhinCD    = sub.syouhinCD
    AND main.tekiyoudate  = sub.tekiyoudate
    where main.siiresakiCD = _I_siiresakiCD
    AND   main.syouhinCD   = _I_syouhinCD;

    IF _tanka IS NULL THEN  /* 取得できなかった場合は商品別単価を取得する */
        /* 商品別単価取得 */
        drop table if exists USTanka;
        create temporary table USTanka
            SELECT SST.syouhinCD
                    ,MAX(SST.tekiyoudate) AS tekiyoudate
            FROM MSyouhinStanka SST
            WHERE SST.tekiyoudate <= _I_date
            GROUP BY SST.syouhinCD;

        SELECT
            main.syouhinCD, main.tekiyoudate, main.tanka
            into
            _syouhinCD    , _tekiyoudate    , _tanka
        FROM MSyouhinStanka AS main
        INNER JOIN USTanka  AS sub
        ON  main.syouhinCD  = sub.syouhinCD
        AND main.tekiyoudate = sub.tekiyoudate
        where main.syouhinCD = _I_syouhinCD;
    END IF;

    IF _tanka IS NULL THEN
        SET _O_tanka  = 0;
    ELSE
        SET _O_tanka  = _tanka;
    END IF;
END;
//
DELIMITER ;
