DROP PROCEDURE IF EXISTS KeikeiRenkeiUriage;
DELIMITER //
CREATE PROCEDURE KeikeiRenkeiUriage(
    IN  _I_kaikeiNengetu integer(6),
    IN  _I_keijouDateFr  date,
    IN  _I_keijouDateTo  date,
    OUT _o_ErrorMsg      varchar(256),
    OUT _o_Result        Boolean
)
BEGIN
/*
    会計連携 (売上データ)
*/
    DECLARE _kaikeiNendo      integer(4);
    DECLARE _denpyouNO        integer(6);
    DECLARE _gyouNO           integer(6);
    DECLARE _akakuro          tinyint(1);
    DECLARE _yuukou           tinyint(1);
    DECLARE _keijounengetu    integer(6);
    DECLARE _dataKBN          integer(3);
    DECLARE _torihikiKBN      integer(3);
    DECLARE _uriageKBN        integer(3);
    DECLARE _siwakeCD         integer(6);
    DECLARE _uriagedate       varchar(10);
    DECLARE _KKCD             varchar(10);
    DECLARE _KKNM             varchar(24);
    DECLARE _KSCD             varchar(10);
    DECLARE _KSNM             varchar(24);
    DECLARE _TKNM             varchar(40);
    DECLARE _HKCD             varchar(10);
    DECLARE _HKNM             varchar(24);
    DECLARE _HSCD             varchar(10);
    DECLARE _HSNM             varchar(24);
    DECLARE _hontai_kingaku   decimal(10,0) DEFAULT 0;
    DECLARE _kaikei_syouhizei decimal(10,0) DEFAULT 0;
    DECLARE _sotoutiKBN       tinyint(1);
    DECLARE _No               tinyint(1);
    DECLARE _ZEIKBN          varchar(24);
    DECLARE done                      INT DEFAULT 0;


    DECLARE curUriage CURSOR FOR
        select
            Duriagelog.kaikeiNendo,
            Duriagelog.denpyouNO,
            Duriagelog.gyouNO,
            Duriagelog.akakuro,
            Duriagelog.yuukou,
            Duriagelog.keijounengetu,
            Duriagelog.dataKBN,
            Duriagelog.torihikiKBN,
            Duriagelog.uriageKBN,
            Msyouhin.siwakeCD,
            date(Duriagelog.uriagedate)      as uriagedate,
            MKKamokuctl.kkKamokuCD        as KKCD,
            MKKanjoukamoku.kanjoukamokuNM as KKNM,
            MKKamokuctl.ksKamokuCD        as KSCD,
            MSKanjoukamoku.kanjoukamokuNM as KSNM,
            Mtokuisaki.tokuisakiNM        as TKNM,
            -- 2013/11/27 start
            -- 補助科目は得意先の情報をセットする
            -- 補助科目コントロールには何も設定がない前提
            -- MHKamokuctl.kkHojoCD          as HKCD,
            -- MKHojokamoku.hojokamokuNM     as HKNM,
            Duriagelog.tokuisakiCD        as HKCD,
            Mtokuisaki.tokuisakiRNM       as HKNM,
            -- 2013/11/27 end
            MHKamokuctl.ksHojoCD          as HSCD,
            MSHojokamoku.hojokamokuNM     as HSNM,
            Duriagelog.hontai_kingaku        as hontai_kingaku,
            Duriagelog.kaikei_syouhizei      as kaikei_syouhizei,
            Msyouhin.sotoutiKBN           as sotoutiKBN,
            1 as No
        from Duriagelog
        inner join Msyouhin
        on Msyouhin.syouhinCD = Duriagelog.syouhinCD
        inner join MKKamokuctl
        on  MKKamokuctl.dataKBN      = Duriagelog.dataKBN
        and MKKamokuctl.torihikiKBN  = Duriagelog.torihikiKBN
        and MKKamokuctl.programKBN   = Duriagelog.uriageKBN
        and MKKamokuctl.siwakeCD     = Msyouhin.siwakeCD
        left outer join MHKamokuctl
        on  MHKamokuctl.dataKBN        = Duriagelog.dataKBN
        and MHKamokuctl.torihikiKBN    = Duriagelog.torihikiKBN
        and MHKamokuctl.programKBN     = Duriagelog.uriageKBN
        and MHKamokuctl.siwakeCD       = Msyouhin.siwakeCD
        and MHKamokuctl.torihikisakiCD = Duriagelog.tokuisakiCD
        inner join MKanjoukamoku as MKKanjoukamoku
        on  MKKanjoukamoku.kanjoukamokuCD = MKKamokuctl.kkKamokuCD
        inner join MKanjoukamoku as MSKanjoukamoku
        on  MSKanjoukamoku.kanjoukamokuCD = MKKamokuctl.ksKamokuCD
        left outer join MHojokamoku as MKHojokamoku
        on  MKHojokamoku.kanjoukamokuCD = MKKamokuctl.kkKamokuCD
        and MKHojokamoku.hojokamokuCD   = MHKamokuctl.kkHojoCD
        left outer join MHojokamoku as MSHojokamoku
        on  MSHojokamoku.kanjoukamokuCD = MKKamokuctl.ksKamokuCD
        and MSHojokamoku.hojokamokuCD   = MHKamokuctl.ksHojoCD
        left outer join Mtokuisaki as Mtokuisaki
        on  Mtokuisaki.tokuisakiCD = Duriagelog.tokuisakiCD
        where Duriagelog.keijounengetu = _I_kaikeiNengetu
        and  (_I_keijouDateFr = "2000-01-01" or Duriagelog.uriagedate >= _I_keijouDateFr)
        and  (_I_keijouDateTo = "2000-01-01" or Duriagelog.uriagedate <= _I_keijouDateTo)
        and  Duriagelog.Krenkeidate IS NULL
        ;


    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    open curUriage;

    REPEAT
    FETCH curUriage
    INTO
        _kaikeiNendo,
        _denpyouNO,
        _gyouNO,
        _akakuro,
        _yuukou,
        _keijounengetu,
        _dataKBN,
        _torihikiKBN,
        _uriageKBN,
        _siwakeCD,
        _uriagedate,
        _KKCD,
        _KKNM,
        _KSCD,
        _KSNM,
        _TKNM,
        _HKCD,
        _HKNM,
        _HSCD,
        _HSNM,
        _hontai_kingaku,
        _kaikei_syouhizei,
        _sotoutiKBN,
        _No;

    IF done = 0 THEN
        -- 伝票番号取得
        SET @kaikei_yyyy = 0;
        SET @DenpyouNumber = 0;
        call GetDenpyouNumber(
              150
             ,@kaikei_yyyy
             ,@DenpyouNumber);

        IF _sotoutiKBN = 0 then      -- 外税
            SET _ZEIKBN = '課税売上外';
        ELSEIF _sotoutiKBN = 1 then  -- 内税
            SET _ZEIKBN = '課税売上内';
        ELSE                         -- 非課税
            SET _ZEIKBN = '非課税';
        END IF;

        IF _hontai_kingaku >= 0 THEN
            /* 通常仕訳 */
            INSERT INTO Dsiwake
            (
                kaikeiNendo,
                denpyouNO,
                gyouNO,
                SEQ,
                akakuro,
                yuukou,
                keijounengetu,
                dataKBN,
                torihikiKBN,
                siwakeKBN,
                motoKaikeiNendo,
                motoDenpyouNO,
                motoGyouNO,
                sikibetuFLG,
                siwakeDenpyouNO,
                kessan,
                torihikiDate,
                kkKanjouCD,
                kkKanjouNM,
                kkHojoCD,
                kkHojoNM,
                kkBumonNM,
                kkZeiKBN,
                kkKingaku,
                kkZeigaku,
                ksKanjouCD,
                ksKanjouNM,
                ksHojoCD,
                ksHojoNM,
                ksBumonNM,
                ksZeiKBN,
                ksKingaku,
                ksZeigaku,
                tekiyou,
                bangou,
                kijiutu,
                type,
                seiseiMoto,
                siwakeMemo,
                fusen1,
                fusen2,
                tyousei,
                kouzaCD,
                insertdate,
                insertTantosya,
                updatedate,
                updateTantosya
            )
            values
            (
                @kaikei_yyyy,
                @DenpyouNumber,
                1,
                0,
                _akakuro,
                _yuukou,
                _keijounengetu,
                _dataKBN,
                _torihikiKBN,
                _uriageKBN,
                _kaikeiNendo,
                _denpyouNO,
                _gyouNO,
                '2000',
                0,
                '',
                _uriagedate,

                _KKCD,
                _KKNM,
                _HKCD,
                _HKNM,
                '',
                _ZEIKBN,
                _hontai_kingaku,
                _kaikei_syouhizei,

                _KSCD,
                _KSNM,
                _HSCD,
                _HSNM,
                '',
                _ZEIKBN,
                _hontai_kingaku,
                _kaikei_syouhizei,

                '',
                '',
                '',
                0,
                '',
                '',
                0,
                0,
                'no',
                1,
                CURRENT_TIMESTAMP(),
                1,
                CURRENT_TIMESTAMP(),
                1
            );
        ELSE
            /* 逆仕訳 */
            INSERT INTO Dsiwake
            (
                kaikeiNendo,
                denpyouNO,
                gyouNO,
                SEQ,
                akakuro,
                yuukou,
                keijounengetu,
                dataKBN,
                torihikiKBN,
                siwakeKBN,
                motoKaikeiNendo,
                motoDenpyouNO,
                motoGyouNO,
                sikibetuFLG,
                siwakeDenpyouNO,
                kessan,
                torihikiDate,
                kkKanjouCD,
                kkKanjouNM,
                kkHojoCD,
                kkHojoNM,
                kkBumonNM,
                kkZeiKBN,
                kkKingaku,
                kkZeigaku,
                ksKanjouCD,
                ksKanjouNM,
                ksHojoCD,
                ksHojoNM,
                ksBumonNM,
                ksZeiKBN,
                ksKingaku,
                ksZeigaku,
                tekiyou,
                bangou,
                kijiutu,
                type,
                seiseiMoto,
                siwakeMemo,
                fusen1,
                fusen2,
                tyousei,
                kouzaCD,
                insertdate,
                insertTantosya,
                updatedate,
                updateTantosya
            )
            values
            (
                @kaikei_yyyy,
                @DenpyouNumber,
                1,
                0,
                _akakuro,
                _yuukou,
                _keijounengetu,
                _dataKBN,
                _torihikiKBN,
                _uriageKBN,
                _kaikeiNendo,
                _denpyouNO,
                _gyouNO,
                '2000',
                0,
                '',
                _uriagedate,

                _KSCD,
                _KSNM,
                _HSCD,
                _HSNM,
                '',
                _ZEIKBN,
                _hontai_kingaku * -1,
                _kaikei_syouhizei * -1,

                _KKCD,
                _KKNM,
                _HKCD,
                _HKNM,
                '',
                _ZEIKBN,
                _hontai_kingaku * -1,
                _kaikei_syouhizei * -1,

                '',
                '',
                '',
                0,
                '',
                '',
                0,
                0,
                'no',
                1,
                CURRENT_TIMESTAMP(),
                1,
                CURRENT_TIMESTAMP(),
                1
            );
        END IF;

        UPDATE Duriagelog
        SET  Duriagelog.Krenkeidate = now()
        where Duriagelog.keijounengetu = _I_kaikeiNengetu
        and  (_I_keijouDateFr = "2000-01-01" or Duriagelog.uriagedate >= _I_keijouDateFr)
        and  (_I_keijouDateTo = "2000-01-01" or Duriagelog.uriagedate <= _I_keijouDateTo)
        and  Duriagelog.Krenkeidate IS NULL;
    END IF;
    UNTIL done END REPEAT;
    CLOSE curUriage;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
