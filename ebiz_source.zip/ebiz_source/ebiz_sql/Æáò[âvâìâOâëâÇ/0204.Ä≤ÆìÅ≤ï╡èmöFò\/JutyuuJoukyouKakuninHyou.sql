DROP PROCEDURE IF EXISTS prtJutyuuJoukyouKakunin;
DELIMITER //
CREATE PROCEDURE prtJutyuuJoukyouKakunin(
    IN _i_jigyosyoCDfr       integer(2),
    IN _i_jigyosyoCDto       integer(2),
    IN _i_jutyuuDatefr     date,
    IN _i_jutyuuDateto     date,
    IN _i_tokuisakiCDfr      integer(6),
    IN _i_tokuisakiCDto      integer(6),
    IN _i_kaikeiNendofr      integer(4),
    IN _i_denpyouNOfr        integer(6),
    IN _i_denpyouNOto        integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     今回対象データ
     ========================================================================= */
    drop table if exists SJutyuuJoukyouHeadNeta;
    create temporary table SJutyuuJoukyouHeadNeta
    -- create table SJutyuuJoukyouHeadNeta
        /* 出荷指示パターン 全完了 --------------------------------------------------------------------------------- */
        (
        select
            Djutyuu.kaikeiNendo as jkaikeiNendo,
            Djutyuu.denpyouNO as jdenpyouNO,
            Djutyuu.gyouNO as jgyouNO,
            01 as id,
            Djutyuu.syouhinCD,
            Djutyuu.syouhinNM,
            Djutyuu.taniCD,
            Mtani.taniNM,
            concat_ws('-', Djutyuu.kaikeiNendo ,lpad(Djutyuu.denpyouNO,6,'0'),lpad(Djutyuu.gyouNO,3,'0')) as jutyuuNO,
            Djutyuu.suryou as jutyuuSuu,
            concat_ws('-', Dsyukkasiji.kaikeiNendo ,lpad(Dsyukkasiji.denpyouNO,6,'0'),lpad(Dsyukkasiji.gyouNO,3,'0')) as sijiNO,
            Dsyukkasiji.sijisuryou as sijiSuu,
            concat_ws('-', Dsyukka.kaikeiNendo ,lpad(Dsyukka.denpyouNO,6,'0'),lpad(Dsyukka.gyouNO,3,'0')) as syukkaNO,
            Dsyukka.suryou as syukkaSuu,
            concat_ws('-', Duriage.kaikeiNendo ,lpad(Duriage.denpyouNO,6,'0'),lpad(Duriage.gyouNO,3,'0')) as uriageNO,
            Duriage.suryou as uriageSuu,
            0 as zero
        from Djutyuu
        left outer join Mtani
        on  Mtani.taniCD = Djutyuu.taniCD
        inner join Dsyukkasiji
        on  Dsyukkasiji.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
        and Dsyukkasiji.jutyuuNO          = Djutyuu.denpyouNO
        and Dsyukkasiji.jutyuu_gyouNO     = Djutyuu.gyouNO
        inner join Dsyukka
        on  Dsyukka.kaikeiNendo = Dsyukkasiji.syukkaKaikeiNendo
        and Dsyukka.denpyouNO   = Dsyukkasiji.syukkaNO
        and Dsyukka.gyouNO      = Dsyukkasiji.syukka_gyouNO
        inner join Duriage
        on  Duriage.kaikeiNendo = Dsyukka.uriageKaikeiNendo
        and Duriage.denpyouNO   = Dsyukka.uriageNO
        and Duriage.gyouNO      = Dsyukka.uriage_gyouNO
        where 1 = 1
        and  (_i_jutyuuDatefr = "2000-01-01" or Djutyuu.jutyuudate >= _i_jutyuuDatefr)
        and  (_i_jutyuuDateto = "2000-01-01" or Djutyuu.jutyuudate <= _i_jutyuuDateto)
        and  (_i_kaikeiNendofr = 0 or Djutyuu.kaikeiNendo = _i_kaikeiNendofr)
        and  (_i_denpyouNOfr = 0 or Djutyuu.denpyouNO >= _i_denpyouNOfr)
        and  (_i_denpyouNOto = 0 or Djutyuu.denpyouNO <= _i_denpyouNOto)
        )
        UNION ALL

        /* 出荷指示パターン 売上未完了 --------------------------------------------------------------------------------- */
        (
        select
            Djutyuu.kaikeiNendo as jkaikeiNendo,
            Djutyuu.denpyouNO as jdenpyouNO,
            Djutyuu.gyouNO as jgyouNO,
            02 as id,
            Djutyuu.syouhinCD,
            Djutyuu.syouhinNM,
            Djutyuu.taniCD,
            Mtani.taniNM,
            concat_ws('-', Djutyuu.kaikeiNendo ,lpad(Djutyuu.denpyouNO,6,'0'),lpad(Djutyuu.gyouNO,3,'0')) as jutyuuNO,
            Djutyuu.suryou as jutyuuSuu,
            concat_ws('-', Dsyukkasiji.kaikeiNendo ,lpad(Dsyukkasiji.denpyouNO,6,'0'),lpad(Dsyukkasiji.gyouNO,3,'0')) as sijiNO,
            Dsyukkasiji.sijisuryou as sijiSuu,
            concat_ws('-', Dsyukka.kaikeiNendo ,lpad(Dsyukka.denpyouNO,6,'0'),lpad(Dsyukka.gyouNO,3,'0')) as syukkaNO,
            Dsyukka.suryou as syukkaSuu,
            '' as uriageNO,
            0 as uriageSuu,
            0 as zero
        from Djutyuu
        left outer join Mtani
        on  Mtani.taniCD = Djutyuu.taniCD
        inner join Dsyukkasiji
        on  Dsyukkasiji.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
        and Dsyukkasiji.jutyuuNO          = Djutyuu.denpyouNO
        and Dsyukkasiji.jutyuu_gyouNO     = Djutyuu.gyouNO
        inner join Dsyukka
        on  Dsyukka.kaikeiNendo = Dsyukkasiji.syukkaKaikeiNendo
        and Dsyukka.denpyouNO   = Dsyukkasiji.syukkaNO
        and Dsyukka.gyouNO      = Dsyukkasiji.syukka_gyouNO
        and not exists (select Duriage.kaikeiNendo,Duriage.denpyouNO,Duriage.gyouNO from Duriage
                        where
                            Duriage.kaikeiNendo = Dsyukka.uriageKaikeiNendo
                        and Duriage.denpyouNO   = Dsyukka.uriageNO
                        and Duriage.gyouNO      = Dsyukka.uriage_gyouNO
                        )
        where 1 = 1
        and  (_i_jutyuuDatefr = "2000-01-01" or Djutyuu.jutyuudate >= _i_jutyuuDatefr)
        and  (_i_jutyuuDateto = "2000-01-01" or Djutyuu.jutyuudate <= _i_jutyuuDateto)
        and  (_i_kaikeiNendofr = 0 or Djutyuu.kaikeiNendo = _i_kaikeiNendofr)
        and  (_i_denpyouNOfr = 0 or Djutyuu.denpyouNO >= _i_denpyouNOfr)
        and  (_i_denpyouNOto = 0 or Djutyuu.denpyouNO <= _i_denpyouNOto)
        )
        UNION ALL

        /* 出荷指示パターン 出荷未完了 --------------------------------------------------------------------------------- */
        (
        select
            Djutyuu.kaikeiNendo as jkaikeiNendo,
            Djutyuu.denpyouNO as jdenpyouNO,
            Djutyuu.gyouNO as jgyouNO,
            03 as id,
            Djutyuu.syouhinCD,
            Djutyuu.syouhinNM,
            Djutyuu.taniCD,
            Mtani.taniNM,
            concat_ws('-', Djutyuu.kaikeiNendo ,lpad(Djutyuu.denpyouNO,6,'0'),lpad(Djutyuu.gyouNO,3,'0')) as jutyuuNO,
            Djutyuu.suryou as jutyuuSuu,
            concat_ws('-', Dsyukkasiji.kaikeiNendo ,lpad(Dsyukkasiji.denpyouNO,6,'0'),lpad(Dsyukkasiji.gyouNO,3,'0')) as sijiNO,
            Dsyukkasiji.sijisuryou as sijiSuu,
            '' as syukkaNO,
            0 as syukkaSuu,
            '' as uriageNO,
            0 as uriageSuu,
            0 as zero
        from Djutyuu
        left outer join Mtani
        on  Mtani.taniCD = Djutyuu.taniCD
        inner join Dsyukkasiji
        on  Dsyukkasiji.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
        and Dsyukkasiji.jutyuuNO          = Djutyuu.denpyouNO
        and Dsyukkasiji.jutyuu_gyouNO     = Djutyuu.gyouNO
        /*
        and not exists (select Dsyukka.kaikeiNendo,Dsyukka.denpyouNO,Dsyukka.gyouNO from Dsyukka
                        where
                            Dsyukka.kaikeiNendo = Dsyukkasiji.syukkaKaikeiNendo
                        and Dsyukka.denpyouNO   = Dsyukkasiji.syukkaNO
                        and Dsyukka.gyouNO      = Dsyukkasiji.syukka_gyouNO
                        )
        and not exists (select Duriage.kaikeiNendo,Duriage.denpyouNO,Duriage.gyouNO from Duriage
                        where
                            Duriage.kaikeiNendo = Dsyukka.uriageKaikeiNendo
                        and Duriage.denpyouNO   = Dsyukka.uriageNO
                        and Duriage.gyouNO      = Dsyukka.uriage_gyouNO
                        )
        */
        where 1 = 1
        and  Dsyukkasiji.syukkaKaikeiNendo = 0
        and  Dsyukkasiji.syukkaNO = 0
        and  Dsyukkasiji.syukka_gyouNO = 0

        and  (_i_jutyuuDatefr = "2000-01-01" or Djutyuu.jutyuudate >= _i_jutyuuDatefr)
        and  (_i_jutyuuDateto = "2000-01-01" or Djutyuu.jutyuudate <= _i_jutyuuDateto)
        and  (_i_kaikeiNendofr = 0 or Djutyuu.kaikeiNendo = _i_kaikeiNendofr)
        and  (_i_denpyouNOfr = 0 or Djutyuu.denpyouNO >= _i_denpyouNOfr)
        and  (_i_denpyouNOto = 0 or Djutyuu.denpyouNO <= _i_denpyouNOto)
        )
        UNION ALL

        /* 出荷パターン 全完了 --------------------------------------------------------------------------------- */
        (
        select
            Djutyuu.kaikeiNendo as jkaikeiNendo,
            Djutyuu.denpyouNO as jdenpyouNO,
            Djutyuu.gyouNO as jgyouNO,
            04 as id,
            Djutyuu.syouhinCD,
            Djutyuu.syouhinNM,
            Djutyuu.taniCD,
            Mtani.taniNM,
            concat_ws('-', Djutyuu.kaikeiNendo ,lpad(Djutyuu.denpyouNO,6,'0'),lpad(Djutyuu.gyouNO,3,'0')) as jutyuuNO,
            Djutyuu.suryou as jutyuuSuu,
            '' as sijiNO,
            0 as sijiSuu,
            concat_ws('-', Dsyukka.kaikeiNendo ,lpad(Dsyukka.denpyouNO,6,'0'),lpad(Dsyukka.gyouNO,3,'0')) as syukkaNO,
            Dsyukka.suryou as syukkaSuu,
            concat_ws('-', Duriage.kaikeiNendo ,lpad(Duriage.denpyouNO,6,'0'),lpad(Duriage.gyouNO,3,'0')) as uriageNO,
            Duriage.suryou as uriageSuu,
            0 as zero
        from Djutyuu
        left outer join Mtani
        on  Mtani.taniCD = Djutyuu.taniCD
        /*
        inner join Dsyukkasiji
        on  Dsyukkasiji.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
        and Dsyukkasiji.jutyuuNO          = Djutyuu.denpyouNO
        and Dsyukkasiji.jutyuu_gyouNO     = Djutyuu.gyouNO
        */
        inner join Dsyukka
        on  Dsyukka.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
        and Dsyukka.jutyuuNO          = Djutyuu.denpyouNO
        and Dsyukka.jutyuu_gyouNO     = Djutyuu.gyouNO
        inner join Duriage
        on  Duriage.kaikeiNendo = Dsyukka.uriageKaikeiNendo
        and Duriage.denpyouNO   = Dsyukka.uriageNO
        and Duriage.gyouNO      = Dsyukka.uriage_gyouNO
        where 1 = 1
        and not exists (select Dsyukkasiji.kaikeiNendo,Dsyukkasiji.denpyouNO,Dsyukkasiji.gyouNO from Dsyukkasiji
                        where
                            Dsyukkasiji.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
                        and Dsyukkasiji.jutyuuNO          = Djutyuu.denpyouNO
                        and Dsyukkasiji.jutyuu_gyouNO     = Djutyuu.gyouNO
                        )
        and  (_i_jutyuuDatefr = "2000-01-01" or Djutyuu.jutyuudate >= _i_jutyuuDatefr)
        and  (_i_jutyuuDateto = "2000-01-01" or Djutyuu.jutyuudate <= _i_jutyuuDateto)
        and  (_i_kaikeiNendofr = 0 or Djutyuu.kaikeiNendo = _i_kaikeiNendofr)
        and  (_i_denpyouNOfr = 0 or Djutyuu.denpyouNO >= _i_denpyouNOfr)
        and  (_i_denpyouNOto = 0 or Djutyuu.denpyouNO <= _i_denpyouNOto)
        -- Order by Djutyuu.kaikeiNendo, Djutyuu.denpyouNO, Djutyuu.gyouNO
        )
        UNION ALL

        /* 出荷パターン 売上未完了 --------------------------------------------------------------------------------- */
        (
        select
            Djutyuu.kaikeiNendo as jkaikeiNendo,
            Djutyuu.denpyouNO as jdenpyouNO,
            Djutyuu.gyouNO as jgyouNO,
            05 as id,
            Djutyuu.syouhinCD,
            Djutyuu.syouhinNM,
            Djutyuu.taniCD,
            Mtani.taniNM,
            concat_ws('-', Djutyuu.kaikeiNendo ,lpad(Djutyuu.denpyouNO,6,'0'),lpad(Djutyuu.gyouNO,3,'0')) as jutyuuNO,
            Djutyuu.suryou as jutyuuSuu,
            '' as sijiNO,
            0 as sijiSuu,
            concat_ws('-', Dsyukka.kaikeiNendo ,lpad(Dsyukka.denpyouNO,6,'0'),lpad(Dsyukka.gyouNO,3,'0')) as syukkaNO,
            Dsyukka.suryou as syukkaSuu,
            '' as uriageNO,
            0 as uriageSuu,
            0 as zero
        from Djutyuu
        left outer join Mtani
        on  Mtani.taniCD = Djutyuu.taniCD
        /*
        inner join Dsyukkasiji
        on  Dsyukkasiji.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
        and Dsyukkasiji.jutyuuNO          = Djutyuu.denpyouNO
        and Dsyukkasiji.jutyuu_gyouNO     = Djutyuu.gyouNO
        */
        inner join Dsyukka
        on  Dsyukka.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
        and Dsyukka.jutyuuNO          = Djutyuu.denpyouNO
        and Dsyukka.jutyuu_gyouNO     = Djutyuu.gyouNO
        /*
        inner join Duriage
        on  Duriage.kaikeiNendo = Dsyukka.uriageKaikeiNendo
        and Duriage.denpyouNO   = Dsyukka.uriageNO
        and Duriage.gyouNO      = Dsyukka.uriage_gyouNO
        */
        where 1 = 1
        and not exists (select Dsyukkasiji.kaikeiNendo,Dsyukkasiji.denpyouNO,Dsyukkasiji.gyouNO from Dsyukkasiji
                        where
                            Dsyukkasiji.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
                        and Dsyukkasiji.jutyuuNO          = Djutyuu.denpyouNO
                        and Dsyukkasiji.jutyuu_gyouNO     = Djutyuu.gyouNO
                        )
        and not exists (select Duriage.kaikeiNendo,Duriage.denpyouNO,Duriage.gyouNO from Duriage
                        where
                            Duriage.kaikeiNendo = Dsyukka.uriageKaikeiNendo
                        and Duriage.denpyouNO   = Dsyukka.uriageNO
                        and Duriage.gyouNO      = Dsyukka.uriage_gyouNO
                        )
        and  (_i_jutyuuDatefr = "2000-01-01" or Djutyuu.jutyuudate >= _i_jutyuuDatefr)
        and  (_i_jutyuuDateto = "2000-01-01" or Djutyuu.jutyuudate <= _i_jutyuuDateto)
        and  (_i_kaikeiNendofr = 0 or Djutyuu.kaikeiNendo = _i_kaikeiNendofr)
        and  (_i_denpyouNOfr = 0 or Djutyuu.denpyouNO >= _i_denpyouNOfr)
        and  (_i_denpyouNOto = 0 or Djutyuu.denpyouNO <= _i_denpyouNOto)
        )
        UNION ALL

        /* 出荷パターン 全未完了 --------------------------------------------------------------------------------- */
        (
        select
            Djutyuu.kaikeiNendo as jkaikeiNendo,
            Djutyuu.denpyouNO as jdenpyouNO,
            Djutyuu.gyouNO as jgyouNO,
            06 as id,
            Djutyuu.syouhinCD,
            Djutyuu.syouhinNM,
            Djutyuu.taniCD,
            Mtani.taniNM,
            concat_ws('-', Djutyuu.kaikeiNendo ,lpad(Djutyuu.denpyouNO,6,'0'),lpad(Djutyuu.gyouNO,3,'0')) as jutyuuNO,
            Djutyuu.suryou as jutyuuSuu,
            '' as sijiNO,
            0 as sijiSuu,
            '' as syukkaNO,
            0 as syukkaSuu,
            '' as uriageNO,
            0 as uriageSuu,
            0 as zero
        from Djutyuu
        left outer join Mtani
        on  Mtani.taniCD = Djutyuu.taniCD
        /*
        inner join Dsyukkasiji
        on  Dsyukkasiji.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
        and Dsyukkasiji.jutyuuNO          = Djutyuu.denpyouNO
        and Dsyukkasiji.jutyuu_gyouNO     = Djutyuu.gyouNO
        inner join Dsyukka
        on  Dsyukka.kaikeiNendo = Djutyuu.syukkaKaikeiNendo
        and Dsyukka.denpyouNO   = Djutyuu.syukkaNO
        and Dsyukka.gyouNO      = Djutyuu.syukka_gyouNO
        inner join Duriage
        on  Duriage.kaikeiNendo = Dsyukka.uriageKaikeiNendo
        and Duriage.denpyouNO   = Dsyukka.uriageNO
        and Duriage.gyouNO      = Dsyukka.uriage_gyouNO
        */
        where 1 = 1
        and not exists (select Dsyukkasiji.kaikeiNendo,Dsyukkasiji.denpyouNO,Dsyukkasiji.gyouNO from Dsyukkasiji
                        where
                            Dsyukkasiji.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
                        and Dsyukkasiji.jutyuuNO          = Djutyuu.denpyouNO
                        and Dsyukkasiji.jutyuu_gyouNO     = Djutyuu.gyouNO
                        )
        and not exists (select Dsyukka.kaikeiNendo,Dsyukka.denpyouNO,Dsyukka.gyouNO from Dsyukka
                        where
                            Dsyukka.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
                        and Dsyukka.jutyuuNO          = Djutyuu.denpyouNO
                        and Dsyukka.jutyuu_gyouNO     = Djutyuu.gyouNO
                        )
        and not exists (select Duriage.kaikeiNendo,Duriage.denpyouNO,Duriage.gyouNO from Duriage
                        where
                            Duriage.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
                        and Duriage.jutyuuNO          = Djutyuu.denpyouNO
                        and Duriage.jutyuu_gyouNO     = Djutyuu.gyouNO
                        )
        and  (_i_jutyuuDatefr = "2000-01-01" or Djutyuu.jutyuudate >= _i_jutyuuDatefr)
        and  (_i_jutyuuDateto = "2000-01-01" or Djutyuu.jutyuudate <= _i_jutyuuDateto)
        and  (_i_kaikeiNendofr = 0 or Djutyuu.kaikeiNendo = _i_kaikeiNendofr)
        and  (_i_denpyouNOfr = 0 or Djutyuu.denpyouNO >= _i_denpyouNOfr)
        and  (_i_denpyouNOto = 0 or Djutyuu.denpyouNO <= _i_denpyouNOto)
        )
        Order by jkaikeiNendo, jdenpyouNO, jgyouNO
        ;

    drop table if exists SJutyuuJoukyouHeadNetaSum;
    create temporary table SJutyuuJoukyouHeadNetaSum
        select
            jkaikeiNendo,
            jdenpyouNO,
            jgyouNO,
            -- sum(jutyuuSuu) as jutyuuSuuKei,
            sum(sijiSuu) as sijiSuuKei,
            sum(syukkaSuu) as syukkaSuuKei,
            sum(uriageSuu) as uriageSuuKei
        from SJutyuuJoukyouHeadNeta as SJutyuuJoukyouHeadNetaS
        group by jkaikeiNendo, jdenpyouNO, jgyouNO
        ;

    drop table if exists SJutyuuJoukyouHead;
    create temporary table SJutyuuJoukyouHead
    -- create table SJutyuuJoukyouHead
        select
            SJutyuuJoukyouHeadNeta.*,
            -- SJutyuuJoukyouHeadNetaSum.jutyuuSuuKei,
            SJutyuuJoukyouHeadNetaSum.sijiSuuKei,
            SJutyuuJoukyouHeadNetaSum.syukkaSuuKei,
            SJutyuuJoukyouHeadNetaSum.uriageSuuKei
        from SJutyuuJoukyouHeadNeta
        left outer join SJutyuuJoukyouHeadNetaSum
        on  SJutyuuJoukyouHeadNetaSum.jkaikeiNendo = SJutyuuJoukyouHeadNeta.jkaikeiNendo
        and SJutyuuJoukyouHeadNetaSum.jdenpyouNO   = SJutyuuJoukyouHeadNeta.jdenpyouNO
        and SJutyuuJoukyouHeadNetaSum.jgyouNO      = SJutyuuJoukyouHeadNeta.jgyouNO
        ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
