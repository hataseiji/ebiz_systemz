DROP PROCEDURE IF EXISTS prtTokuisakiUriZeinenTaihi;
DELIMITER //
CREATE PROCEDURE prtTokuisakiUriZeinenTaihi(
    IN _i_jigyosyoCDfr       integer(2),
    IN _i_jigyosyoCDto       integer(2),
    IN _i_tantousyaCDfr      integer(6),
    IN _i_tantousyaCDto      integer(6),
    IN _i_tokuisakiCDfr      integer(6),
    IN _i_tokuisakiCDto      integer(6),
    IN _i_konki              integer(4),
    IN _i_zenki              integer(4),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    drop table if exists preTokuisakiUriZeinenTaihi;
    create temporary table preTokuisakiUriZeinenTaihi
        select
            _i_konki as kaikeiNendo,
            Durikakezan.tokuisakiCD as tokuisakiCD,
            Mtokuisaki.tokuisakiNM  as tokuisakiNM,
            Mtokuisaki.tantousyaCD as tantousyaCD,
            Mtantosya.tantosyaNM as tantosyaNM,
            Mtantosya.jigyosyoCD as jigyosyoCD,
            Mjigyosyo.jigyosyoRNM as jigyosyoRNM,
            Mjigyosyo.jigyosyoNM as jigyosyoNM,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 0 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki4,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 1 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki5,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 2 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki6,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 3 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki7,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 4 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki8,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 5 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki9,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 6 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki10,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 7 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki11,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 8 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki12,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 9 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki1,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 10 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki2,
            case when Durikakezan.kaikeiNendo = _i_konki AND Durikakezan.keijoutukisuu = 11 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as konki3,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 0 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki4,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 1 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki5,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 2 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki6,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 3 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki7,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 4 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki8,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 5 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki9,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 6 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki10,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 7 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki11,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 8 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki12,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 9 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki1,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 10 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki2,
            case when Durikakezan.kaikeiNendo = _i_zenki AND Durikakezan.keijoutukisuu = 11 THEN
                Durikakezan.uriagegaku + Durikakezan.hennpinngaku + Durikakezan.nebikigaku
            else 0
            end as zenki3
        from Durikakezan
        left outer join Mtokuisaki
        on Mtokuisaki.tokuisakiCD = Durikakezan.tokuisakiCD
        left outer join Mtantosya
        on Mtantosya.tantosyaCD   = Mtokuisaki.tantousyaCD
        left outer join Mjigyosyo
        on Mjigyosyo.jigyosyoCD   = Mtantosya.jigyosyoCD
        where 1 = 1
            and (_i_jigyosyoCDfr  = 0 or Mtantosya.jigyosyoCD    >= _i_jigyosyoCDfr)
            and (_i_jigyosyoCDto  = 0 or Mtantosya.jigyosyoCD    <= _i_jigyosyoCDto)
            and (_i_tantousyaCDfr = 0 or Mtokuisaki.tantousyaCD  >= _i_tantousyaCDfr)
            and (_i_tantousyaCDto = 0 or Mtokuisaki.tantousyaCD  <= _i_tantousyaCDto)
            and (_i_tokuisakiCDfr = 0 or Durikakezan.tokuisakiCD >= _i_tokuisakiCDfr)
            and (_i_tokuisakiCDto = 0 or Durikakezan.tokuisakiCD <= _i_tokuisakiCDto)
            and (Durikakezan.kaikeiNendo = _i_konki or Durikakezan.kaikeiNendo = _i_zenki)
        order by Durikakezan.kaikeiNendo, Mtokuisaki.tantousyaCD, Durikakezan.tokuisakiCD
        ;

    drop table if exists tokuisakiUriZeinenTaihi;
    create temporary table tokuisakiUriZeinenTaihi
        select
            kaikeiNendo,
            tokuisakiCD,
            tokuisakiNM,
            tantousyaCD,
            tantosyaNM,
            jigyosyoCD,
            jigyosyoRNM,
            jigyosyoNM,
            sum(konki4)  as konki4,
            sum(konki5)  as konki5,
            sum(konki6)  as konki6,
            sum(konki7)  as konki7,
            sum(konki8)  as konki8,
            sum(konki9)  as konki9,
            sum(konki10) as konki10,
            sum(konki11) as konki11,
            sum(konki12) as konki12,
            sum(konki1)  as konki1,
            sum(konki2)  as konki2,
            sum(konki3)  as konki3,
            sum(zenki4)  as zenki4,
            sum(zenki5)  as zenki5,
            sum(zenki6)  as zenki6,
            sum(zenki7)  as zenki7,
            sum(zenki8)  as zenki8,
            sum(zenki9)  as zenki9,
            sum(zenki10) as zenki10,
            sum(zenki11) as zenki11,
            sum(zenki12) as zenki12,
            sum(zenki1)  as zenki1,
            sum(zenki2)  as zenki2,
            sum(zenki3)  as zenki3,
            000.00       as taihi4,
            000.00       as taihi5,
            000.00       as taihi6,
            000.00       as taihi7,
            000.00       as taihi8,
            000.00       as taihi9,
            000.00       as taihi10,
            000.00       as taihi11,
            000.00       as taihi12,
            000.00       as taihi1,
            000.00       as taihi2,
            000.00       as taihi3
        from preTokuisakiUriZeinenTaihi
        group by kaikeiNendo, tantousyaCD, tokuisakiCD
        ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
