DROP PROCEDURE IF EXISTS prtSyouhinUriageRanking;
DELIMITER //
CREATE PROCEDURE prtSyouhinUriageRanking(
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg          varchar(256);
    DECLARE _Result            Boolean;
    DECLARE _syouhinCD         varchar(10);
    DECLARE _uriagegaku        decimal(10) DEFAULT 0;
    DECLARE _arari             decimal(10) DEFAULT 0;
    DECLARE _break_uriagegaku  decimal(10) DEFAULT 0;
    DECLARE done               INT DEFAULT 0;
    DECLARE _countRanking      integer(4) DEFAULT 0;
    DECLARE _updRanking        integer(4) DEFAULT 0;

    DECLARE curRanking CURSOR FOR
        select
           syouhinCD
          ,uriagegaku
          ,arari
        from syouhinRanking
        order by uriagegaku DESC
        ;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     順位採番
     ========================================================================= */
    set _break_uriagegaku = 0;
    set _countRanking     = 0;
    set _updRanking       = 0;
    OPEN curRanking;

    REPEAT
    FETCH curRanking
    INTO _syouhinCD, _uriagegaku, _arari;
    IF done = 0 THEN
        set _countRanking = _countRanking + 1;
        IF _uriagegaku <> _break_uriagegaku THEN
            set _updRanking = _countRanking;
        end if;
        set _break_uriagegaku = _uriagegaku;
        update syouhinRanking
            set No = _updRanking
            where syouhinRanking.syouhinCD = _syouhinCD
        ;
    END IF;
    UNTIL done END REPEAT;

    CLOSE curRanking;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
