DROP PROCEDURE IF EXISTS prtSyouhinRanking;
DELIMITER //
CREATE PROCEDURE prtSyouhinRanking(
    IN _i_syouhinCDfr        varchar(10),
    IN _i_syouhinCDto        varchar(10),
    IN _i_uriageYYYYMMfr     integer(6),
    IN _i_uriageYYYYMMto     integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
      drop table if exists syouhinRanking;
      create temporary table syouhinRanking
      select 0 as No
          ,Dsyouhinuriage.syouhinCD as syouhinCD
          ,Msyouhin.syouhinNM as syouhinNM
          ,sum(Dsyouhinuriage.uriagegaku) as uriagegaku
          ,000.00  as kouseiHi
          ,sum(Dsyouhinuriage.uriagegaku - Dsyouhinuriage.genka) as arari
          ,000.00  as arariRitu
      from Dsyouhinuriage
      left outer join Msyouhin
      on Msyouhin.syouhinCD = Dsyouhinuriage.syouhinCD
      where 1 = 1
        and (_i_syouhinCDfr    = 0 or Dsyouhinuriage.syouhinCD   >= _i_syouhinCDfr)
        and (_i_syouhinCDto    = 0 or Dsyouhinuriage.syouhinCD   <= _i_syouhinCDto)
        and (_i_uriageYYYYMMfr = 0 or Dsyouhinuriage.keijounengetu >= _i_uriageYYYYMMfr)
        and (_i_uriageYYYYMMto = 0 or Dsyouhinuriage.keijounengetu <= _i_uriageYYYYMMto)
      group by Dsyouhinuriage.syouhinCD
      ;

    /* =========================================================================
     一時テーブル生成 構成比算出用
     ========================================================================= */
      drop table if exists sstKouseiHi;
      create temporary table sstKouseiHi
      select 0 as No
          ,sum(syouhinRanking.uriagegaku) as uriagegaku
      from syouhinRanking
      ;

    /* =========================================================================
     売上構成比・粗利率算出
     ========================================================================= */
    update syouhinRanking
      inner join sstKouseiHi
      on sstKouseiHi.No = syouhinRanking.No
      set syouhinRanking.kouseiHi  = round(syouhinRanking.uriagegaku / sstKouseiHi.uriagegaku * 100, 2)
      where sstKouseiHi.uriagegaku <> 0
      ;
    update syouhinRanking
      inner join sstKouseiHi
      on sstKouseiHi.No = syouhinRanking.No
      set syouhinRanking.arariRitu = round(syouhinRanking.arari / syouhinRanking.uriagegaku * 100, 2)
      where syouhinRanking.uriagegaku <> 0
      ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
