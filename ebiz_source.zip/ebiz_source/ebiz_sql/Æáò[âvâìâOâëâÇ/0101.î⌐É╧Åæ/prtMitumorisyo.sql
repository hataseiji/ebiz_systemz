DROP PROCEDURE IF EXISTS prtMitumorisyo;
DELIMITER //
CREATE PROCEDURE prtMitumorisyo(
    IN _i_jigyosyoCDfr       integer(2),
    IN _i_jigyosyoCDto       integer(2),
    IN _i_mitumoriDatefr     date,
    IN _i_mitumoriDateto     date,
    IN _i_tokuisakiCDfr      integer(6),
    IN _i_tokuisakiCDto      integer(6),
    IN _i_kaikeiNendofr      integer(4),
    IN _i_denpyouNOfr        integer(6),
    IN _i_denpyouNOto        integer(6),
    IN _i_CheckSaihakkou     tinyint,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     今回対象データ
     ========================================================================= */
    /* 外税の場合のみ会計用消費税を印字対象とする */
    DROP table IF EXISTS dataMitumoriZei;
    create temporary table dataMitumoriZei
		select
			kaikeiNendo as zkaikeiNendo, 
			denpyouNO as zdenpyouNO, 
			gyouNO as zgyouNO, 
			kingaku as zkingaku, 
			case Msyouhin.sotoutiKBN
				when 0 then kaikei_syouhizei
				else 0
			end as zkaikei_syouhizei 
			
			from Dmitumori
			left outer join Msyouhin
			on   Msyouhin.syouhinCD = Dmitumori.syouhinCD
	;
    /* ヘッダの見積額 */
    DROP table IF EXISTS dataMitumoriZeiSum;
    create temporary table dataMitumoriZeiSum
		select
			zkaikeiNendo as skaikeiNendo, 
			zdenpyouNO as sdenpyouNO, 
			sum(zkingaku) as sKingaku, 
			sum(zkaikei_syouhizei) as skaikei_syouhizei, 
			sum(zkingaku + zkaikei_syouhizei) as mitumoriGakuKei 
			from dataMitumoriZei
			group by zkaikeiNendo, zdenpyouNO
	;
    
    DROP table IF EXISTS dataMitumorisyo;
    create temporary table dataMitumorisyo
      select
          Dmitumori.*,
          dataMitumoriZeiSum.mitumoriGakuKei as mitumoriGakuKei,
          dataMitumoriZei.zkingaku as zkingaku, 
          dataMitumoriZei.zkaikei_syouhizei as zkaikei_syouhizei, 
          dataMitumoriZei.zkingaku + dataMitumoriZei.zkaikei_syouhizei as zgoukei,
          
          concat_ws('-', Dmitumori.kaikeiNendo ,lpad(Dmitumori.denpyouNO,6,'0')) as mitumoriNo,
          CONCAT(year(Dmitumori.mitumoridate) , '年',lpad(month(Dmitumori.mitumoridate),2,'0'), '月',lpad(day(Dmitumori.mitumoridate),2,'0'), '日' ) as mitumridate,
          case Mtokuisaki.keisyo
            when '' then concat_ws(' ', Dmitumori.tokuisakiNM ,'御中')
            else concat_ws(' ', Dmitumori.tokuisakiNM, Mtokuisaki.keisyo)
          end PTtokuisakiNM,
          dataMitumoriZeiSum.sKingaku as kingakuKei,
          Mtani.taniNM as taniNM,
          Mtantosya.jigyosyoCD as kanjigyosyoCD,
          Mjigyosyo.jigyosyoNM as kanjigyosyoNM,
          Mjigyosyo.jigyosyoRNM as kanjigyosyoRNM,
          Mkanri.kaisyaNM as kankaisyaNM,
          Mjigyosyo.postalCD as kanpostalCD,
          Mjigyosyo.address1 as kanaddress1,
          Mjigyosyo.address2 as kanaddress2,
          Mjigyosyo.tel      as kantel,
          Mjigyosyo.fax      as kanfax,
          Mtokuisaki.postalCD as PTpostalCD,
          Mtokuisaki.address1 as PTaddress1,
          Mtokuisaki.address2 as PTaddress2,
          Mtokuisaki.tokuisaki_tantousyaNM as PTtokuisaki_tantousyaNM

      from Dmitumori
      left outer join Mtokuisaki as Mtokuisaki
      on   Mtokuisaki.tokuisakiCD = Dmitumori.tokuisakiCD
      left outer join dataMitumoriZeiSum
      on   dataMitumoriZeiSum.skaikeiNendo = Dmitumori.kaikeiNendo
      and  dataMitumoriZeiSum.sdenpyouNO   = Dmitumori.denpyouNO
      left outer join dataMitumoriZei
      on   dataMitumoriZei.zkaikeiNendo = Dmitumori.kaikeiNendo
      and  dataMitumoriZei.zdenpyouNO   = Dmitumori.denpyouNO
      and  dataMitumoriZei.zgyouNO      = Dmitumori.gyouNO
      left outer join Mtani
      on   Mtani.taniCD = Dmitumori.taniCD
      left outer join Mtantosya as Mtantosya
      on   Mtantosya.tantosyaCD = Mtokuisaki.tantousyaCD
      left outer join Mjigyosyo as Mjigyosyo
      on   Mjigyosyo.jigyosyoCD = Mtantosya.jigyosyoCD
      inner join Mkanri
      on   Mkanri.kanriCD = 1

      where 1 = 1
      and  (_i_mitumoriDatefr = "2000-01-01" or Dmitumori.mitumoridate >= _i_mitumoriDatefr)
      and  (_i_mitumoriDateto = "2000-01-01" or Dmitumori.mitumoridate <= _i_mitumoriDateto)
      and  (_i_kaikeiNendofr = 0 or Dmitumori.kaikeiNendo = _i_kaikeiNendofr)
      and  (_i_denpyouNOfr = 0 or Dmitumori.denpyouNO >= _i_denpyouNOfr)
      and  (_i_denpyouNOto = 0 or Dmitumori.denpyouNO <= _i_denpyouNOto)
      /* 2014/07/25 start */
      and  (_i_tokuisakiCDfr = 0 or Dmitumori.tokuisakiCD >= _i_tokuisakiCDfr)
      and  (_i_tokuisakiCDto = 0 or Dmitumori.tokuisakiCD <= _i_tokuisakiCDto)
      /* 2014/07/25 end   */
      and  (_i_CheckSaihakkou = 1 or Dmitumori.DenpyouHakkou = 0)

      order by Dmitumori.kaikeiNendo, Dmitumori.denpyouNO, Dmitumori.gyouNO
      ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
