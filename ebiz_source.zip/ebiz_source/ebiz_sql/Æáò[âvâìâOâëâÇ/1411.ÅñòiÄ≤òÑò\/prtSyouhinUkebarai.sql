DROP PROCEDURE IF EXISTS prtSyouhinUkebarai;
DELIMITER //
CREATE PROCEDURE prtSyouhinUkebarai(
    IN _i_syori_yyyymm       integer(6),
    IN _i_soukoCDfr          integer(6),
    IN _i_syouhinCDfr        varchar(10),
    IN _i_syukkaDatefr       date,
    IN _i_syukkaDateto       date,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    drop table if exists SSyouhinUkebarai;
    create temporary table SSyouhinUkebarai
      select
         Dnyuusyukko.seq
        ,Dnyuusyukko.kaikeiNendo
        ,Dnyuusyukko.denpyouNO
        ,Dnyuusyukko.keijounengetu
        ,Dnyuusyukko.dataKBN
        ,Dnyuusyukko.torihikiKBN
        ,Dnyuusyukko.systemKBN
        ,case Dnyuusyukko.dataKBN  when 40 then "出荷" when 50 then "売上" when 70 then "入荷" when 80 then "仕入" else "移動" end as torihikiNM
        ,Dnyuusyukko.nyuusyukkodate
        ,Dnyuusyukko.soukoCD
        ,Msouko.soukoNM as soukoNM
        ,Dnyuusyukko.syouhinCD
        ,Dnyuusyukko.syouhinNM
        ,Dnyuusyukko.suryou
        ,Dnyuusyukko.taniCD
        ,Mtani.taniNM
        ,0000000.000 as inSuu
        ,0000000.000 as outSuu
        ,0000000.000 as zandaka
      from Dnyuusyukko
      inner join Msyouhin
      on  Msyouhin.syouhinCD = Dnyuusyukko.syouhinCD
      left outer join Msouko
      on  Msouko.soukoCD = Dnyuusyukko.soukoCD
      left outer join Mtani
      on  Mtani.taniCD   = Dnyuusyukko.taniCD

      where 1 = 1
      and  Msyouhin.zaikokanriKBN = 0

      and  (_i_syori_yyyymm = 0 or Dnyuusyukko.keijounengetu = _i_syori_yyyymm)
      and  (_i_soukoCDfr    = 0 or Dnyuusyukko.soukoCD = _i_soukoCDfr)
      and  (_i_syouhinCDfr  = "" or Dnyuusyukko.syouhinCD = _i_syouhinCDfr)  -- 2013/12/04
      and  (_i_syukkaDatefr = 0 or Dnyuusyukko.nyuusyukkodate >= _i_syukkaDatefr)
      and  (_i_syukkaDateto = 0 or Dnyuusyukko.nyuusyukkodate <= _i_syukkaDateto)

      order by Dnyuusyukko.nyuusyukkodate, Dnyuusyukko.syouhinCD, Dnyuusyukko.seq
      ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
