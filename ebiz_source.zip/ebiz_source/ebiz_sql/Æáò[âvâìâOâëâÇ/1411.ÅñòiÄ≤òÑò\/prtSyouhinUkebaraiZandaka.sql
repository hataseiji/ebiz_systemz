DROP PROCEDURE IF EXISTS prtSyouhinUkebaraiZandaka;
DELIMITER //
CREATE PROCEDURE prtSyouhinUkebaraiZandaka(
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg          varchar(256);
    DECLARE _Result            Boolean;

    DECLARE _seq                   integer(6) DEFAULT 0;
    DECLARE _keijounengetu         integer(6) DEFAULT 0;
    DECLARE _nyuusyukkodate        date;
    DECLARE _dataKBN               integer(3) DEFAULT 0;
    DECLARE _torihikiKBN           integer(3) DEFAULT 0;
    DECLARE _systemKBN             integer(3) DEFAULT 0;
    DECLARE _soukoCD               integer(6) DEFAULT 0;
    DECLARE _syouhinCD             varchar(10);
    DECLARE _suryou                decimal(10,3) DEFAULT 0;
    DECLARE _zengetumatu_zaikosu   decimal(10,3) DEFAULT 0;

    DECLARE _zandaka           decimal(10,3) DEFAULT 0;
    DECLARE _inSuu             decimal(10,3) DEFAULT 0;
    DECLARE _outSuu            decimal(10,3) DEFAULT 0;
    DECLARE _aa                INT DEFAULT 0;
    DECLARE done               INT DEFAULT 0;

    DECLARE curZandaka CURSOR FOR
        select
             SSyouhinUkebarai.seq
            ,SSyouhinUkebarai.keijounengetu
            ,SSyouhinUkebarai.nyuusyukkodate
            ,SSyouhinUkebarai.dataKBN
            ,SSyouhinUkebarai.torihikiKBN
            ,SSyouhinUkebarai.systemKBN
            ,SSyouhinUkebarai.soukoCD
            ,SSyouhinUkebarai.syouhinCD
            ,SSyouhinUkebarai.suryou
            ,IFNULL(Dzaiko.zengetumatu_zaikosu, 0)
        from SSyouhinUkebarai
        left outer join Dzaiko
        on  Dzaiko.soukoCD       = SSyouhinUkebarai.soukoCD
        and Dzaiko.syouhinCD     = SSyouhinUkebarai.syouhinCD
        and Dzaiko.keijounengetu = SSyouhinUkebarai.keijounengetu
        Order By nyuusyukkodate, syouhinCD, seq
        ;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     残高算出
     ========================================================================= */
    set _zandaka = 0;
    set _aa = 0;

    OPEN curZandaka;

    REPEAT
    FETCH curZandaka
    INTO _seq, _keijounengetu, _nyuusyukkodate, _dataKBN, _torihikiKBN, _systemKBN, _soukoCD, _syouhinCD, _suryou, _zengetumatu_zaikosu;

    IF done = 0 THEN
        IF _aa = 0 then
            set _zandaka = _zengetumatu_zaikosu;
        END IF;
        set _aa = 1;
        set _inSuu  = 0;
        set _outSuu = 0;

        IF _dataKBN = 40 then          -- 出荷
            set _outSuu = _suryou;
            set _zandaka = _zandaka - _suryou;
        ELSEIF _dataKBN = 70 then     -- 入荷
            set _inSuu  = _suryou;
            set _zandaka = _zandaka + _suryou;
        ELSEIF _dataKBN = 110 and (_torihikiKBN = 10 or _torihikiKBN = 40) then  -- 社内品増・棚卸増
            set _inSuu  = _suryou;
            set _zandaka = _zandaka + _suryou;
        ELSEIF _dataKBN = 110 and (_torihikiKBN = 20 or _torihikiKBN = 50) then  -- 社内品減・棚卸減
            set _outSuu = _suryou;
            set _zandaka = _zandaka - _suryou;
        END IF;

        update SSyouhinUkebarai
            set  zandaka = _zandaka
                ,inSuu   = _inSuu
                ,outSuu  = _outSuu
            where SSyouhinUkebarai.seq = _seq
            ;


    END IF;
    UNTIL done END REPEAT;

    CLOSE curZandaka;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
