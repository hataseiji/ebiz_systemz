DROP PROCEDURE IF EXISTS prtSeikyuu;
DELIMITER //
CREATE PROCEDURE prtSeikyuu(
    IN _i_jigyosyoCDfr       integer(2),
    IN _i_jigyosyoCDto       integer(2),
    IN _i_tokuisakiCDfr      integer(6),
    IN _i_tokuisakiCDto      integer(6),
    IN _i_kaikeiNendo        integer(4),
    IN _i_simebi             integer(6),
    IN _i_saiHakkou          integer(1),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    drop table if exists SSeikyu;
    create temporary table SSeikyu
    (select
      1 as No     ,
      DseikyuuHead.seikyuusyoBangou  as seikyuusyoBangou1,
      DseikyuuHead.seikyuusakiCD     as seikyuusakiCD,
      CONCAT(Mtokuisaki.tokuisakiNM, ' ', Mtokuisaki.keisyo) as tokuisakiNM,
      Mtokuisaki.postalCD     ,Mtokuisaki.address1     ,Mtokuisaki.address2,
      Mtokuisaki.zeisansyutuKBN      as zeisansyutuKBN,
      DseikyuuHead.ZENZAN            as ZENZAN,
      DseikyuuHead.gkmn_uriagegaku   as uriagegaku,
      DseikyuuHead.gkmn_hennpinngaku as hennpinngaku,
      DseikyuuHead.gkmn_nebikigaku   as nebikigaku,
      DseikyuuHead.gkmn_nyuukinngaku as nyuukinngaku,
      DseikyuuHead.gkmn_syouhizeigaku + DseikyuuHead.gkmn_syouhizeisagaku as syouhizei     ,
      DseikyuuHead.jikaikurikosigaku as jikaikurikosigaku,
      CONCAT(year(Duriage.uriagedate) , '/',lpad(month(Duriage.uriagedate),2,'0'), '/',lpad(day(Duriage.uriagedate),2,'0'), '' ) as denpyouDate,
      concat_ws('-', Duriage.kaikeiNendo ,lpad(Duriage.denpyouNO,6,'0')) as denpyouNo     ,
      Duriage.gyouNO  as gyouNO,  Duriage.syouhinCD      as syouhinCD, Duriage.syouhinNM as syouhinNM,
      Duriage.suryou  as suryou,  Duriage.taniCD         as taniCD,    Mtani.taniNM      as taniNM   , Duriage.tanka as tanka,
      Duriage.kingaku as kingaku, Duriage.hontai_kingaku as hontai_kingaku,
      case Duriage.gyouNO  when 1 then DUR2.kaikei_syouhizei + COALESCE(Dsyouhizei.kaikei_syouhizei, 0) else DUR2.kaikei_syouhizei end as meisai_syouhizei,
      Mjigyosyo.jigyosyoRNM as jigyosyoRNM   ,Mjigyosyo.jigyosyoNM as jigyosyoNM   ,Mkanri.kaisyaNM as kankaisyaNM     ,
      Mjigyosyo.postalCD   as kanpostalCD  ,Mjigyosyo.address1 as kanaddress1  ,
      Mjigyosyo.address2   as kanaddress2  ,Mjigyosyo.tel as kantel     ,Mjigyosyo.fax as kanfax
      from DseikyuuHead
      left outer join Mtokuisaki
        on Mtokuisaki.tokuisakiCD = DseikyuuHead.seikyuusakiCD
      inner join Duriage as Duriage
        on  Duriage.kaikeiNendo = DseikyuuHead.kaikeiNendo
        and Duriage.seikyuusyoBangou = DseikyuuHead.seikyuusyoBangou
      left outer join Duriage as Dsyouhizei
        on Dsyouhizei.kaikeiNendo = Duriage.kaikeiNendo
        and Dsyouhizei.denpyouNO = Duriage.denpyouNO
        and Dsyouhizei.uriageKBN = 80
      left outer join Mtani
        on Mtani.taniCD = Duriage.taniCD
      left outer join (select Duriage.kaikeiNendo, Duriage.denpyouNO, Duriage.gyouNO, case Msyouhin.sotoutiKBN when 1 then 0 else Duriage.kaikei_syouhizei end kaikei_syouhizei from Duriage inner join Msyouhin on Msyouhin.syouhinCD = Duriage.syouhinCD ) DUR2
        on  DUR2.kaikeiNendo = Duriage.kaikeiNendo
        and DUR2.denpyouNO = Duriage.denpyouNO
        and DUR2.gyouNO = Duriage.gyouNO
      left outer join Mtantosya
        on  Mtantosya.tantosyaCD = Mtokuisaki.tantousyaCD
      left outer join Mjigyosyo
        on  Mjigyosyo.jigyosyoCD = Mtantosya.jigyosyoCD
      inner join Mkanri
        on  Mkanri.kanriCD = 1
      where 1 = 1
      and (_i_jigyosyoCDfr  = 0 or Mtantosya.jigyosyoCD >= _i_jigyosyoCDfr)
      and (_i_jigyosyoCDto  = 0 or Mtantosya.jigyosyoCD <= _i_jigyosyoCDto)
      and (_i_tokuisakiCDfr = 0 or DseikyuuHead.seikyuusakiCD >= _i_tokuisakiCDfr)
      and (_i_tokuisakiCDto = 0 or DseikyuuHead.seikyuusakiCD <= _i_tokuisakiCDto)
      and DseikyuuHead.seikyuunengetu = _i_kaikeiNendo
      and DseikyuuHead.simebi = _i_simebi
      and Duriage.uriageKBN <> 80
      and Mtokuisaki.seikyuusyoKBN = 0
      and (_i_saiHakkou = 1 or DseikyuuHead.hakkouKBN = 0)
      )
    UNION ALL
    (select 2 as No     ,
      DseikyuuHead.seikyuusyoBangou as seikyuusyoBangou1,
      DseikyuuHead.seikyuusakiCD    as seikyuusakiCD     ,
      CONCAT(Mtokuisaki.tokuisakiNM, ' ', Mtokuisaki.keisyo) as tokuisakiNM     ,
      Mtokuisaki.postalCD     ,Mtokuisaki.address1     ,Mtokuisaki.address2     ,
      Mtokuisaki.zeisansyutuKBN     ,DseikyuuHead.ZENZAN     ,
      DseikyuuHead.gkmn_uriagegaku as uriagegaku     ,
      DseikyuuHead.gkmn_hennpinngaku as hennpinngaku     ,
      DseikyuuHead.gkmn_nebikigaku as nebikigaku     ,
      DseikyuuHead.gkmn_nyuukinngaku as nyuukinngaku     ,
      DseikyuuHead.gkmn_syouhizeigaku + DseikyuuHead.gkmn_syouhizeisagaku as syouhizei     ,
      DseikyuuHead.jikaikurikosigaku     ,
      CONCAT(year(Dnyuukin.nyuukindate) , '/',lpad(month(Dnyuukin.nyuukindate),2,'0'), '/',lpad(day(Dnyuukin.nyuukindate),2,'0'), '' ) as denpyouDate     ,
      concat_ws('-', Dnyuukin.kaikeiNendo ,lpad(Dnyuukin.denpyouNO,6,'0')) as denpyouNo     ,
      Dnyuukin.gyouNO     ,'' as syouhinCD     ,'＊入金' as syouhinNM     ,
      '' as suryou     ,'' as taniCD     ,'' as taniNM     ,'' as tanka     ,Dnyuukin.kingaku     ,
      Dnyuukin.hontai_kingaku     ,'' as meisai_syouhizei     ,Mjigyosyo.jigyosyoRNM as jigyosyoRNM     ,Mjigyosyo.jigyosyoNM as jigyosyoNM     ,
      Mkanri.kaisyaNM as kankaisyaNM     ,Mjigyosyo.postalCD as kanpostalCD     ,
      Mjigyosyo.address1 as kanaddress1     ,Mjigyosyo.address2 as kanaddress2     ,
      Mjigyosyo.tel as kantel     ,Mjigyosyo.fax as kanfax
      from DseikyuuHead
      left outer join Mtokuisaki
        on Mtokuisaki.tokuisakiCD = DseikyuuHead.seikyuusakiCD
      inner join Dnyuukin as Dnyuukin
        on Dnyuukin.seikyuusyoBangou = DseikyuuHead.seikyuusyoBangou
      left outer join Mtantosya
        on   Mtantosya.tantosyaCD = Mtokuisaki.tantousyaCD
      left outer join Mjigyosyo
        on   Mjigyosyo.jigyosyoCD = Mtantosya.jigyosyoCD
      inner join Mkanri
        on   Mkanri.kanriCD = 1
      where 1 = 1
      and (_i_jigyosyoCDfr  = 0 or Mtantosya.jigyosyoCD >= _i_jigyosyoCDfr)
      and (_i_jigyosyoCDto  = 0 or Mtantosya.jigyosyoCD <= _i_jigyosyoCDto)
      and (_i_tokuisakiCDfr = 0 or DseikyuuHead.seikyuusakiCD >= _i_tokuisakiCDfr)
      and (_i_tokuisakiCDto = 0 or DseikyuuHead.seikyuusakiCD <= _i_tokuisakiCDto)
      and DseikyuuHead.seikyuunengetu = _i_kaikeiNendo
      and DseikyuuHead.simebi = _i_simebi
      and Mtokuisaki.seikyuusyoKBN = 0
      and (_i_saiHakkou = 1 or DseikyuuHead.hakkouKBN = 0)
      )
    Order By seikyuusyoBangou1, seikyuusakiCD, denpyouDate, denpyouNo, gyouNO ;
    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
