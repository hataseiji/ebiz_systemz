DROP PROCEDURE IF EXISTS prtTokuisakiMototyouZandaka;
DELIMITER //
CREATE PROCEDURE prtTokuisakiMototyouZandaka(
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg          varchar(256);
    DECLARE _Result            Boolean;

    DECLARE _No                integer(2) DEFAULT 0;
    DECLARE _tokuisakiCD       integer(6) DEFAULT 0;
    DECLARE _denpyouNo         varchar(11);
    DECLARE _gyouNO            integer(6) DEFAULT 0;
    DECLARE _seq               integer(6) DEFAULT 0;
    DECLARE _denpyouDate       varchar(20);
    DECLARE _zenzan            decimal(10) DEFAULT 0;
    DECLARE _hontai_kingaku    decimal(10) DEFAULT 0;
    DECLARE _kaikei_syouhizei  decimal(10) DEFAULT 0;
    DECLARE _mnyuukinngaku     decimal(10) DEFAULT 0;

    DECLARE _breakTokuisakiCD  integer(6) DEFAULT 0;
    DECLARE _zandaka           decimal(10) DEFAULT 0;
    DECLARE done               INT DEFAULT 0;
    DECLARE _countRanking      integer(4) DEFAULT 0;
    DECLARE _updRanking        integer(4) DEFAULT 0;

    DECLARE curZandaka CURSOR FOR
        select
           No
          ,tokuisakiCD
          ,denpyouNo
          ,gyouNO
          ,seq
          ,denpyouDate
          ,ZENZAN
          ,hontai_kingaku
          ,kaikei_syouhizei
          ,mnyuukinngaku
        from STokuisakiMototyou
        Order By tokuisakiCD, denpyouDate, denpyouNo, gyouNO, seq
        ;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     残高算出
     ========================================================================= */
    set _breakTokuisakiCD = 0;
    OPEN curZandaka;

    REPEAT
    FETCH curZandaka
    INTO _No, _tokuisakiCD, _denpyouNo, _gyouNO, _seq, _denpyouDate, _zenzan, _hontai_kingaku, _kaikei_syouhizei, _mnyuukinngaku;

    IF done = 0 THEN
        if _tokuisakiCD <> _breakTokuisakiCD then
            set _zandaka = _zenzan;
        end if;
        if _No = 1 then
            set _zandaka = _zandaka + _hontai_kingaku;
            set _zandaka = _zandaka + _kaikei_syouhizei;
        else
            set _zandaka = _zandaka - _mnyuukinngaku;
        end if;

        set _breakTokuisakiCD = _tokuisakiCD;

        update STokuisakiMototyou
            set zandaka = _zandaka
            where STokuisakiMototyou.No = _No
            and   STokuisakiMototyou.seq = _seq
        ;
    END IF;
    UNTIL done END REPEAT;

    CLOSE curZandaka;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
