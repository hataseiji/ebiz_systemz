DROP PROCEDURE IF EXISTS prtDailySyukka;
DELIMITER //
CREATE PROCEDURE prtDailySyukka(
    IN _i_jigyosyoCDfr       integer(2),
    IN _i_jigyosyoCDto       integer(2),
    IN _i_syukkaDatefr       date,
    IN _i_syukkaDateto       date,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    DROP table IF EXISTS preDataDailySyukka;
    create temporary table preDataDailySyukka
        select
            Dsyukka.* ,
            '納入先' as pnounyusaki_title ,
            concat_ws('-', Dsyukka.kaikeiNendo ,lpad(Dsyukka.denpyouNO,6,'0')) as syukkaNo ,
            CONCAT(year(Dsyukka.syukkadate) , '年',lpad(month(Dsyukka.syukkadate),2,'0'), '月',lpad(day(Dsyukka.syukkadate),2,'0'), '日' ) as ptsyukkadate ,
            concat_ws('-', Djutyuu.kaikeiNendo ,lpad(Djutyuu.denpyouNO,6,'0')) as hjutyuuNo , 
            CONCAT(year(Djutyuu.jutyuudate) , '年',lpad(month(Djutyuu.jutyuudate),2,'0'), '月',lpad(day(Djutyuu.jutyuudate),2,'0'), '日' ) as jutyuudate , 
            concat_ws('-', Dsyukkasiji.kaikeiNendo ,lpad(Dsyukkasiji.denpyouNO,6,'0')) as syukkasijiNo , 
            Msouko.soukoNM as soukoNM ,
            --  事業所CD
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtantosyaJ.jigyosyoCD
              else MtantosyaU.jigyosyoCD
            end kanjigyosyoCD,
            --  事業所名
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.jigyosyoNM
              else MjigyosyoU.jigyosyoNM
            end kanjigyosyoNM,
            --  会社名
            Mkanri.kaisyaNM as kankaisyaNM,
            --  事業所郵便番号
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.postalCD
              else MjigyosyoU.postalCD
            end kanpostalCD,
            --  事業所住所1
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.address1
              else MjigyosyoU.address1
            end kanaddress1,
            --  事業所住所2
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.address2
              else MjigyosyoU.address2
            end kanaddress2,
            --  事業所電話
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.tel
              else MjigyosyoU.tel
            end kantel,
            --  事業所FAX
            case Dsyukka.uriageKaikeiNendo
              when 0 then MjigyosyoJ.fax
              else MjigyosyoU.fax
            end kanfax,
            --  得意先CD
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.tokuisakiCD
              else Duriage.tokuisakiCD
            end PTtokuisakiCD,
            --  得意先名
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.tokuisakiNM
              else Duriage.tokuisakiNM
            end PTtokuisakiNM,
            --  得意先郵便番号
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtokuisakiJ.postalCD
              else MtokuisakiU.postalCD
            end PTpostalCD,
            --  得意先住所1
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtokuisakiJ.address1
              else MtokuisakiU.address1
            end PTaddress1,
            --  得意先住所2
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtokuisakiJ.address2
              else MtokuisakiU.address2
            end PTaddress2,
            --  得意先担当者
            case Dsyukka.uriageKaikeiNendo
              when 0 then MtokuisakiJ.tokuisaki_tantousyaNM
              else MtokuisakiU.tokuisaki_tantousyaNM
            end PTtokuisaki_tantousyaNM,
            --  納入先CD
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.nounyuusakiCD
              else Duriage.nounyuusakiCD
            end PNnounyuusakiCD,
            --  納入先名
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.nounyuusakiNM
              else Duriage.nounyuusakiNM
            end PNnounyuusakiNM,
            --  納入先郵便番号
            case Dsyukka.uriageKaikeiNendo
              when 0 then  Djutyuu.postalCD
              else Duriage.postalCD
            end PNpostalCD,
            --  納入先住所1
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.nounyusaki_address1
              else Duriage.nounyusaki_address1
            end PNnounyusaki_address1,
            --  納入先住所2
            case Dsyukka.uriageKaikeiNendo
              when 0 then Djutyuu.nounyusaki_address2
              else Duriage.nounyusaki_address2
            end PNnounyusaki_address2,
            --  納入先担当者
            case Dsyukka.uriageKaikeiNendo
              when 0 then  Djutyuu.nounyusaki_tantousyaNM
              else Duriage.nounyusaki_tantousyaNM
            end PNnounyusaki_tantousyaNM,
            --  得意先注文番号
            case Dsyukka.uriageKaikeiNendo
              when 0 then  Djutyuu.TtyuumonNo
              else Duriage.TtyuumonNo
            end TtyuumonNo,
            --  受注案件名
            case Dsyukka.uriageKaikeiNendo
              when 0 then  Djutyuu.ankenNM
              else UriDjutyuu.ankenNM
            end ankenNM,

            Storihiki.torihikiNM as torihikiNM,
            Mtani.taniNM as taniNM

        from Dsyukka
        left outer join Djutyuu
        on   Djutyuu.kaikeiNendo = Dsyukka.jutyuuKaikeiNendo
        and  Djutyuu.denpyouNO   = Dsyukka.jutyuuNO
        and  Djutyuu.gyouNO   = 1
        left outer join Dsyukkasiji 
        on  Dsyukkasiji.syukkaKaikeiNendo  = Dsyukka.kaikeiNendo 
        and Dsyukkasiji.syukkaNO           = Dsyukka.denpyouNO 
        and Dsyukkasiji.syukka_gyouNO      = Dsyukka.gyouNO 
        left outer join Duriage
        on   Duriage.kaikeiNendo = Dsyukka.uriageKaikeiNendo
        and  Duriage.denpyouNO   = Dsyukka.uriageNO
        and  Duriage.gyouNO   = 1
        left outer join Djutyuu as UriDjutyuu
        on   UriDjutyuu.kaikeiNendo = Duriage.ankenKaikeiNendo
        and  UriDjutyuu.denpyouNO   = Duriage.ankenjutyuuNO
        and  UriDjutyuu.gyouNO   = 1
        left outer join Mtokuisaki as MtokuisakiJ
        on   MtokuisakiJ.tokuisakiCD = Djutyuu.tokuisakiCD
        left outer join Mtokuisaki as MtokuisakiU
        on   MtokuisakiU.tokuisakiCD = Duriage.tokuisakiCD
        left outer join Msouko
        on   Msouko.soukoCD = Dsyukka.soukoCD
        left outer join Mtani
        on   Mtani.taniCD = Dsyukka.taniCD
        left outer join Mtantosya as MtantosyaJ
        on   MtantosyaJ.tantosyaCD = MtokuisakiJ.tantousyaCD
        left outer join Mtantosya as MtantosyaU
        on   MtantosyaU.tantosyaCD = MtokuisakiU.tantousyaCD
        left outer join Mjigyosyo as MjigyosyoJ
        on   MjigyosyoJ.jigyosyoCD = MtantosyaJ.jigyosyoCD
        left outer join Mjigyosyo as MjigyosyoU
        on   MjigyosyoU.jigyosyoCD = MtantosyaU.jigyosyoCD
        inner join Mkanri
        on   Mkanri.kanriCD = 1
        inner join Storihiki as Storihiki
        on   Storihiki.dataKBN = Dsyukka.dataKBN
        and  Storihiki.torihikiKBN = Dsyukka.torihikiKBN

        where 1 = 1
        and  (_i_syukkaDatefr = "2000-01-01" or Dsyukka.syukkadate >= _i_syukkaDatefr)
        and  (_i_syukkaDateto = "2000-01-01" or Dsyukka.syukkadate <= _i_syukkaDateto)

        order by Dsyukka.kaikeiNendo, Dsyukka.denpyouNO, Dsyukka.gyouNO
        ;

    DROP table IF EXISTS dataDailySyukka;
    create temporary table dataDailySyukka
        select
            preDataDailySyukka.kaikeiNendo,
            preDataDailySyukka.denpyouNO,
            preDataDailySyukka.gyouNO,
            preDataDailySyukka.syukkaNo,
            preDataDailySyukka.ptsyukkadate,
            preDataDailySyukka.hjutyuuNo,
            preDataDailySyukka.ankenNM,
            preDataDailySyukka.syukkasijiNo,
            preDataDailySyukka.PTtokuisakiCD as tokuisakiCD,
            preDataDailySyukka.PTtokuisakiNM as tokuisakiNM,
            preDataDailySyukka.PNnounyuusakiCD , 
            preDataDailySyukka.PNpostalCD,
            preDataDailySyukka.PNnounyuusakiNM,
            preDataDailySyukka.denpyou_tekiyou1 , 
            preDataDailySyukka.denpyou_tekiyou2 , 
            preDataDailySyukka.torihikiNM,
            preDataDailySyukka.syouhinCD,
            preDataDailySyukka.syouhinNM,
            preDataDailySyukka.soukoNM,
            preDataDailySyukka.suryou,
            preDataDailySyukka.taniNM,
            preDataDailySyukka.kanjigyosyoCD,
            preDataDailySyukka.kanjigyosyoNM,
            0 as zero
        from preDataDailySyukka
        where 1 = 1
        and  (_i_jigyosyoCDfr = 0 or kanjigyosyoCD >= _i_jigyosyoCDfr)
        and  (_i_jigyosyoCDto = 0 or kanjigyosyoCD <= _i_jigyosyoCDto)
        order by
            preDataDailySyukka.kanjigyosyoCD,
            preDataDailySyukka.kaikeiNendo,
            preDataDailySyukka.denpyouNO,
            preDataDailySyukka.gyouNO
        ;
    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
