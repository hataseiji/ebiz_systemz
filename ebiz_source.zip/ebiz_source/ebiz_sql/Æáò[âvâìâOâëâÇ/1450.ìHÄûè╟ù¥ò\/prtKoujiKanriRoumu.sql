DROP PROCEDURE IF EXISTS prtKoujiKanriRoumu;
DELIMITER //
CREATE PROCEDURE prtKoujiKanriRoumu(
    IN _i_kaikeiNendo       integer(4),
    IN _i_denpyouNO         integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
	DECLARE _kaikeiNendo 		integer(4);
	DECLARE _denpyouNO 			integer(6);
	DECLARE _ankenKaikeiNendo 	integer(4);
	DECLARE _ankenjutyuuNO 		integer(6);
	DECLARE _siiresakiCD 		integer(6);
	DECLARE _siiredate 			date;
	DECLARE _suryou 			decimal(6,3) DEFAULT 0;
	DECLARE _tanka 				decimal(6) DEFAULT 0;
	DECLARE _kingaku 			decimal(12) DEFAULT 0;


/* =========================================================================
	労務費 工数 作成用一時テーブル
 ========================================================================= */
	drop table if exists Shattyuu;
	create temporary table Shattyuu
		select
			Dsiire.kaikeiNendo as kaikeiNendo,
			Dsiire.denpyouNO as denpyouNO,
			Dsiire.ankenKaikeiNendo as ankenKaikeiNendo,
			Dsiire.ankenjutyuuNO as ankenjutyuuNO,
			Dsiire.siiresakiCD as siiresakiCD,
			Dsiire.siiresakiNM as siiresakiNM,
			Dsiire.siiredate as siiredate,
			sum(Dsiire.suryou) as suryou,
			Dsiire.tanka as tanka,
			sum(Dsiire.kingaku) as kingaku
		from Dsiire
		inner join Msyouhin
		on  Msyouhin.syouhinCD = Dsiire.syouhinCD
		where 1 = 1
		and Dsiire.ankenKaikeiNendo      = _i_kaikeiNendo
		and Dsiire.ankenjutyuuNO         = _i_denpyouNO
		and Msyouhin.daibunruiCD  = 100001
		and Msyouhin.tyuubunruiCD = 000002
		group by Dsiire.ankenKaikeiNendo, Dsiire.ankenjutyuuNO, Dsiire.kaikeiNendo, Dsiire.denpyouNO, Dsiire.siiresakiCD, Dsiire.siiredate
		;

/* =========================================================================
     工事管理表 通常労務費 作成処理開始
 ========================================================================= */
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

	INSERT ignore INTO SKoujiRoumu
	(
		siireNO,
		kaikeiNendo,
		denpyouNO,
		ankenKaikeiNendo,
		ankenjutyuuNO,
		ankenNM,
		yoteiKousu,
		syoukaKousu,
		yoteiRoumu,
		syoukaRoumu,
		siiresakiCD,
		siiresakiNM,
		roumudate,
		kousuu,
		tanka,
		kingaku,
		zangyou,
		ztanka,
		zKingaku,
		goukei,
		tantosyaCD,
		tantosyaNM
	)
	select
		concat_ws('-', Dsiire.ankenKaikeiNendo ,lpad(Dsiire.ankenjutyuuNO,6,'0')) as siireNO,
		Dsiire.kaikeiNendo,
		Dsiire.denpyouNO,
		Dsiire.ankenKaikeiNendo,
		Dsiire.ankenjutyuuNO,
		Djutyuu.ankenNM,
		0,
		0,
		0,
		0,
		Dsiire.siiresakiCD,
		Dsiire.siiresakiNM,
		CONCAT(year(Dsiire.siiredate) , '/',lpad(month(Dsiire.siiredate),2,'0'), '/',lpad(day(Dsiire.siiredate),2,'0'), '' ) as siiredate ,
		sum(Dsiire.suryou),
		Dsiire.tanka,
		sum(Dsiire.kingaku),
		0,
		0,
		0,
		0,
        Mtokuisaki.tantousyaCD,
        Mtantosya.tantosyaNM
	from Dsiire
	left outer join (select distinct kaikeiNendo,denpyouNO,ankenNM,tokuisakiCD from Djutyuu) as Djutyuu
	on  Djutyuu.kaikeiNendo = Dsiire.ankenKaikeiNendo
	and Djutyuu.denpyouNO = Dsiire.ankenjutyuuNO
	inner join Msyouhin
	on  Msyouhin.syouhinCD = Dsiire.syouhinCD

    left outer join Mtokuisaki
    on  Mtokuisaki.tokuisakiCD = Djutyuu.tokuisakiCD
    left outer join Mtantosya
    on  Mtantosya.tantosyaCD = Mtokuisaki.tantousyaCD

	where 1 = 1
	and Dsiire.ankenKaikeiNendo      = _i_kaikeiNendo
	and Dsiire.ankenjutyuuNO         = _i_denpyouNO
	and Msyouhin.daibunruiCD  = 100001
	and Msyouhin.tyuubunruiCD = 000001
		/* 2014/01/22 end */
	group by Dsiire.ankenKaikeiNendo, Dsiire.ankenjutyuuNO, Dsiire.kaikeiNendo, Dsiire.denpyouNO, Dsiire.siiresakiCD, Dsiire.siiredate
	;

	/* =========================================================================
	     工事管理表 労務費 工数 作成処理開始
	 ========================================================================= */
	update
		SKoujiRoumu as SK,
		Shattyuu    as SH
	set SK.zangyou  = SH.suryou,
		SK.ztanka   = SH.tanka,
		SK.zKingaku = SH.kingaku
	where 1 = 1
	and SK.ankenKaikeiNendo  = _i_kaikeiNendo
	and SK.ankenjutyuuNO     = _i_denpyouNO
	and SK.kaikeiNendo       = SH.kaikeiNendo
	and SK.denpyouNO         = SH.denpyouNO
	and SK.ankenKaikeiNendo  = SH.ankenKaikeiNendo
	and SK.ankenjutyuuNO     = SH.ankenjutyuuNO
	and SK.siiresakiCD       = SH.siiresakiCD
	and SK.siiresakiNM       = SH.siiresakiNM
	and SK.roumudate         = SH.siiredate
	;


	/* =========================================================================
	     工事管理表 労務費 作成処理開始
	 ========================================================================= */
	-- 予定工数
	select
		Dhattyuu.ankenKaikeiNendo,
		Dhattyuu.ankenjutyuuNO,
		sum(Dhattyuu.suryou),
		sum(Dhattyuu.kingaku)
	into
		_ankenKaikeiNendo,
		_ankenjutyuuNO,
		_suryou,
		_kingaku
	from Dhattyuu
	inner join Msyouhin
	on  Msyouhin.syouhinCD = Dhattyuu.syouhinCD
	where 1 = 1
	and Dhattyuu.ankenKaikeiNendo      = _i_kaikeiNendo
	and Dhattyuu.ankenjutyuuNO         = _i_denpyouNO
	and Msyouhin.daibunruiCD  = 100001
	group by Dhattyuu.ankenKaikeiNendo, Dhattyuu.ankenjutyuuNO
	;

	update SKoujiRoumu
	set
		yoteiKousu  = _suryou,
		yoteiRoumu  = _kingaku
	where 1 = 1
	and ankenKaikeiNendo  = _ankenKaikeiNendo
	and ankenjutyuuNO     = _ankenjutyuuNO
	;

	/* =========================================================================
	     工事管理表 労務費 作成処理開始
	 ========================================================================= */
	-- 実績工数
	select
		Dsiire.ankenKaikeiNendo,
		Dsiire.ankenjutyuuNO,
		sum(Dsiire.suryou),
		sum(Dsiire.kingaku)
	into
		_ankenKaikeiNendo,
		_ankenjutyuuNO,
		_suryou,
		_kingaku
	from Dsiire
	inner join Msyouhin
	on  Msyouhin.syouhinCD = Dsiire.syouhinCD
	where 1 = 1
	and Dsiire.ankenKaikeiNendo      = _i_kaikeiNendo
	and Dsiire.ankenjutyuuNO         = _i_denpyouNO
	and Msyouhin.daibunruiCD  = 100001
	group by Dsiire.ankenKaikeiNendo, Dsiire.ankenjutyuuNO
	;

	update SKoujiRoumu
	set
		syoukaKousu  = _suryou,
		zanKousu     = yoteiKousu - _suryou,
		syoukaRoumu  = _kingaku,
		zanRoumu     = yoteiRoumu - _kingaku,
		goukei       = kingaku + zKingaku
	where 1 = 1
	and ankenKaikeiNendo  = _ankenKaikeiNendo
	and ankenjutyuuNO     = _ankenjutyuuNO
	;

	set _o_Result = 1;
	set _o_ErrorMsg = '';
END;
//
DELIMITER ;
