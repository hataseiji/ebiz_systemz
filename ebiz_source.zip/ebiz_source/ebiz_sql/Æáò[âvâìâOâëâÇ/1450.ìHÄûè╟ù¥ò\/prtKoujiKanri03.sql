DROP PROCEDURE IF EXISTS prtKoujiKanri03;
DELIMITER //
CREATE PROCEDURE prtKoujiKanri03(
    IN _i_kaikeiNendo       integer(4),
    IN _i_denpyouNO         integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg 		varchar(256);
    DECLARE _Result 		Boolean;
    DECLARE _counter 		integer;
    DECLARE _LineCounter 	integer;
	DECLARE _aa				tinyint;
    DECLARE done            INT DEFAULT 0;

    /* =========================================================================
         収支予想・実績作成
     ========================================================================= */
    DECLARE _uriageGaku             decimal(10) DEFAULT 0;
    DECLARE _mitumoriGnk            decimal(10) DEFAULT 0;
    DECLARE _siireGaku              decimal(10) DEFAULT 0;


    /* =========================================================================
         収支予想・実績作成処理開始
     ========================================================================= */
    -- [売上高]
    select sum(Djutyuu.kingaku) into _uriageGaku from Djutyuu
    where Djutyuu.ankenKaikeiNendo = _i_kaikeiNendo and Djutyuu.ankenjutyuuNO = _i_denpyouNO
    group by Djutyuu.ankenKaikeiNendo, Djutyuu.ankenjutyuuNO;

    -- [見積原価]
    select sum(Dhattyuu.kingaku) into _mitumoriGnk from Dhattyuu
    where Dhattyuu.ankenKaikeiNendo = _i_kaikeiNendo and Dhattyuu.ankenjutyuuNO = _i_denpyouNO
    group by Dhattyuu.ankenKaikeiNendo, Dhattyuu.ankenjutyuuNO;

    -- [実粗利算出用]
    select sum(Dsiire.kingaku) into _siireGaku from Dsiire
    where Dsiire.ankenKaikeiNendo = _i_kaikeiNendo and Dsiire.ankenjutyuuNO = _i_denpyouNO
    group by Dsiire.ankenKaikeiNendo, Dsiire.ankenjutyuuNO;

    update SKoujikanri
        SET
            uriageKei       =   _uriageGaku,
            mitumoriGenka   =   _mitumoriGnk,
            mitumoriArari   =   _uriageGaku - _mitumoriGnk,
            jissiGenka      =   _siireGaku,
            jissiArari      =   _uriageGaku - _siireGaku
        where   kaikeiNendo = _i_kaikeiNendo
                and denpyouNO = _i_denpyouNO
    ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
