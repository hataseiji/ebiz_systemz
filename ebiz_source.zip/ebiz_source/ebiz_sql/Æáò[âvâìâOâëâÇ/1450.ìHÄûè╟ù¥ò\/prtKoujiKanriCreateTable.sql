DROP PROCEDURE IF EXISTS prtKoujiKanriCreateTable;
DELIMITER //
CREATE PROCEDURE prtKoujiKanriCreateTable(
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

	SET NAMES utf8;
	SET FOREIGN_KEY_CHECKS = 0;

	DROP TABLE IF EXISTS `SKoujikanri`;
	CREATE temporary TABLE `SKoujikanri` (
		`jutyuuNO` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票番号',
		`kaikeiNendo` integer(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
		`denpyouNO` integer(6) NOT NULL DEFAULT '0' COMMENT '伝票番号',
		`ankenNM` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '案件名',
		`jutyuudate` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '着工日',
		`syukkadate` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '完成予定日',
		`nouki` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '完成日',
		`tokuisakiCD` integer(6) NOT NULL DEFAULT '0' COMMENT '得意先CD',
		`tokuisakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '得意先名',
		`address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所1',
		`address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '住所2',
		`tel1` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '電話番号1',
		`fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'FAX番号',
		`simebi1` tinyint(2) NOT NULL DEFAULT '0' COMMENT '締日1',
		`kaisyuu_mm1` tinyint(2) NOT NULL DEFAULT '0' COMMENT '回収月1',
		`kaisyuu_dd1` tinyint(2) NOT NULL DEFAULT '0' COMMENT '回収日1',
		`nounyuusakiCD` integer(6) NOT NULL DEFAULT '0' COMMENT '納入先CD',
		`nounyuusakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先名',
		`nounyusaki_address1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所1',
		`nounyusaki_address2` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先住所2',
		`nounyusaki_tantousyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '納入先担当者名',
		`jutyuudate1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '受注日1',
		`jutyuuNO1` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '受注番号1',
		`jutyuukaikeiNendo1` integer(4) NOT NULL DEFAULT '0' COMMENT '受注会計年度1',
		`jutyuuDenpyouNO1` integer(6) NOT NULL DEFAULT '0' COMMENT '受注伝票番号1',
		`jutyuuKingaku1` decimal(10) NOT NULL DEFAULT '0' COMMENT '受注金額1',
		`jutyuuSyouhizei1` decimal(10) NOT NULL DEFAULT '0' COMMENT '受注消費税額1',
		`zeiJutyuuKingaku1` decimal(10) NOT NULL DEFAULT '0' COMMENT '税込受注額1',
		`jutyuudate2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '受注日2',
		`jutyuuNO2` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '受注番号2',
		`jutyuukaikeiNendo2` integer(4) NOT NULL DEFAULT '0' COMMENT '受注会計年度2',
		`jutyuuDenpyouNO2` integer(6) NOT NULL DEFAULT '0' COMMENT '受注伝票番号2',
		`jutyuuKingaku2` decimal(10) NOT NULL DEFAULT '0' COMMENT '受注金額2',
		`jutyuuSyouhizei2` decimal(10) NOT NULL DEFAULT '0' COMMENT '受注消費税額2',
		`zeiJutyuuKingaku2` decimal(10) NOT NULL DEFAULT '0' COMMENT '税込受注額2',
		`jutyuudate3` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '受注日3',
		`jutyuuNO3` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '受注番号3',
		`jutyuukaikeiNendo3` integer(4) NOT NULL DEFAULT '0' COMMENT '受注会計年度3',
		`jutyuuDenpyouNO3` integer(6) NOT NULL DEFAULT '0' COMMENT '受注伝票番号3',
		`jutyuuKingaku3` decimal(10) NOT NULL DEFAULT '0' COMMENT '受注金額3',
		`jutyuuSyouhizei3` decimal(10) NOT NULL DEFAULT '0' COMMENT '受注消費税額3',
		`zeiJutyuuKingaku3` decimal(10) NOT NULL DEFAULT '0' COMMENT '税込受注額3',
		`jutyuudate4` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '受注日4',
		`jutyuuNO4` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '受注番号4',
		`jutyuukaikeiNendo4` integer(4) NOT NULL DEFAULT '0' COMMENT '受注会計年度4',
		`jutyuuDenpyouNO4` integer(6) NOT NULL DEFAULT '0' COMMENT '受注伝票番号4',
		`jutyuuKingaku4` decimal(10) NOT NULL DEFAULT '0' COMMENT '受注金額4',
		`jutyuuSyouhizei4` decimal(10) NOT NULL DEFAULT '0' COMMENT '受注消費税額4',
		`zeiJutyuuKingaku4` decimal(10) NOT NULL DEFAULT '0' COMMENT '税込受注額4',
		`jutyuuKingaku5` decimal(10) NOT NULL DEFAULT '0' COMMENT '受注金額5',
		`jutyuuSyouhizei5` decimal(10) NOT NULL DEFAULT '0' COMMENT '受注消費税額5',
		`zeiJutyuuKingaku5` decimal(10) NOT NULL DEFAULT '0' COMMENT '税込受注額5',
		`uriageKei` decimal(10) NOT NULL DEFAULT '0' COMMENT '売上高',
		`mitumoriGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '見積原価',
		`mitumoriArari` decimal(10) NOT NULL DEFAULT '0' COMMENT '見積粗利',
		`jissiGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '実施原価',
		`jissiArari` decimal(10) NOT NULL DEFAULT '0' COMMENT '実施粗利',
		`zMitumoriGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '材料見積原価',
		`zJissiGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '材料実施原価',
		`zRitu` decimal(6,3) NOT NULL DEFAULT '0' COMMENT '材料消化率',
		`zZankin` decimal(10) NOT NULL DEFAULT '0' COMMENT '材料残金',
		`rMitumoriGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '労務見積原価',
		`rJissiGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '労務実施原価',
		`rRitu` decimal(6,3) NOT NULL DEFAULT '0' COMMENT '労務消化率',
		`rZankin` decimal(10) NOT NULL DEFAULT '0' COMMENT '労務残金',
		`gMitumoriGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '外注見積原価',
		`gJissiGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '外注実施原価',
		`gRitu` decimal(6,3) NOT NULL DEFAULT '0' COMMENT '外注消化率',
		`gZankin` decimal(10) NOT NULL DEFAULT '0' COMMENT '外注残金',
		`kMitumoriGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '経費見積原価',
		`kJissiGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '経費実施原価',
		`kRitu` decimal(6,3) NOT NULL DEFAULT '0' COMMENT '経費消化率',
		`kZankin` decimal(10) NOT NULL DEFAULT '0' COMMENT '経費残金',
		`tMitumoriGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '合計見積原価',
		`tJissiGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '合計実施原価',
		`tRitu` decimal(6,3) NOT NULL DEFAULT '0' COMMENT '合計消化率',
		`tZankin` decimal(10) NOT NULL DEFAULT '0' COMMENT '合計残金',
		`aMitumoriGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '粗利見積原価',
		`aJissiGenka` decimal(10) NOT NULL DEFAULT '0' COMMENT '粗利実施',
		`seikyuuDate1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '請求日1',
		`seikyuuKingaku1` decimal(10) NOT NULL DEFAULT '0' COMMENT '請求金額1',
		`nyuukinYoteiDate1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '入金予定日1',
		`seikyuuDate2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '請求日2',
		`seikyuuKingaku2` decimal(10) NOT NULL DEFAULT '0' COMMENT '請求金額2',
		`nyuukinYoteiDate2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '入金予定日2',
		`seikyuuDate3` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '請求日3',
		`seikyuuKingaku3` decimal(10) NOT NULL DEFAULT '0' COMMENT '請求金額3',
		`nyuukinYoteiDate3` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '入金予定日3',
		`seikyuuDate4` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '請求日4',
		`seikyuuKingaku4` decimal(10) NOT NULL DEFAULT '0' COMMENT '請求金額4',
		`nyuukinYoteiDate4` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '入金予定日4',
		`tantosyaCD` integer(6) NOT NULL DEFAULT '0' COMMENT '担当者CD',
		`tantosyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '担当者名'
	) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='工事管理表一時テーブル';

	DROP TABLE IF EXISTS `SKoujiRoumu`;
	CREATE temporary TABLE `SKoujiRoumu` (
		`siireNO` varchar(11)  COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票番号',
		`kaikeiNendo` integer(4)  NOT NULL DEFAULT '0' COMMENT '会計年度',
		`denpyouNO` integer(6)  NOT NULL DEFAULT '0' COMMENT '伝票番号',
		`ankenKaikeiNendo` integer(4)  NOT NULL DEFAULT '0' COMMENT '案件受注会計年度',
		`ankenjutyuuNO` integer(6)  NOT NULL DEFAULT '0' COMMENT '案件受注番号',
		`ankenNM` varchar(100)  COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '案件名',
		`yoteiKousu` decimal(3)  NOT NULL DEFAULT '0' COMMENT '予定工数',
		`syoukaKousu` decimal(3)  NOT NULL DEFAULT '0' COMMENT '消化工数',
		`zanKousu` decimal(3)  NOT NULL DEFAULT '0' COMMENT '残工数',
		`yoteiRoumu` decimal(10)  NOT NULL DEFAULT '0' COMMENT '労務費予算',
		`syoukaRoumu` decimal(10)  NOT NULL DEFAULT '0' COMMENT '労務費',
		`zanRoumu` decimal(10)  NOT NULL DEFAULT '0' COMMENT '労務費残',
		`siiresakiCD` integer(6)  NOT NULL DEFAULT '0' COMMENT '仕入先CD',
		`siiresakiNM` varchar(40)  COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先名',
		`roumudate` varchar(10)  COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '日付',
		`kousuu` decimal(6,3)  NOT NULL DEFAULT '0' COMMENT '工数',
		`tanka` decimal(6)  NOT NULL DEFAULT '0' COMMENT '単価',
		`kingaku` decimal(6)  NOT NULL DEFAULT '0' COMMENT '金額',
		`zangyou` decimal(6,3)  NOT NULL DEFAULT '0' COMMENT '残業',
		`ztanka` decimal(6)  NOT NULL DEFAULT '0' COMMENT '残業単価',
		`zKingaku` decimal(6)  NOT NULL DEFAULT '0' COMMENT '残業代',
		`goukei` decimal(6)  NOT NULL DEFAULT '0' COMMENT '合計',
		`tantosyaCD` integer(6)  NOT NULL DEFAULT '0' COMMENT '担当者CD',
		`tantosyaNM` varchar(40)  COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '担当者名'
	) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='工事管理表一時テーブル';

	DROP TABLE IF EXISTS `SKoujiZairyo`;
	CREATE temporary TABLE `SKoujiZairyo` (
		`jutyuuNO` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票番号',
		`kaikeiNendo` integer(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
		`denpyouNO` integer(6) NOT NULL DEFAULT '0' COMMENT '伝票番号',
		`ankenNM` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '案件名',
		`siiresakiCD` integer(6) NOT NULL DEFAULT '0' COMMENT '仕入先CD',
		`siiresakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先名',
		`roumudate` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '日付',
		`syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
		`syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
		`suryou` decimal(7,3) NOT NULL DEFAULT '0' COMMENT '数量',
		`tanka` decimal(7) NOT NULL DEFAULT '0' COMMENT '単価',
		`kingaku` decimal(9) NOT NULL DEFAULT '0' COMMENT '金額',
		`tantosyaCD` integer(6) NOT NULL DEFAULT '0' COMMENT '担当者CD',
		`tantosyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '担当者名'
	) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='工事管理表 材料費';

	DROP TABLE IF EXISTS `SKoujiKeihi`;
	CREATE temporary TABLE `SKoujiKeihi` (
		`jutyuuNO` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '伝票番号',
		`kaikeiNendo` integer(4) NOT NULL DEFAULT '0' COMMENT '会計年度',
		`denpyouNO` integer(6) NOT NULL DEFAULT '0' COMMENT '伝票番号',
		`ankenNM` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '案件名',
		`siiresakiCD` integer(6) NOT NULL DEFAULT '0' COMMENT '仕入先CD',
		`siiresakiNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仕入先名',
		`roumudate` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '日付',
		`syouhinCD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品CD',
		`syouhinNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品名',
		`suryou` decimal(7,3) NOT NULL DEFAULT '0' COMMENT '数量',
		`tanka` decimal(7) NOT NULL DEFAULT '0' COMMENT '単価',
		`kingaku` decimal(9) NOT NULL DEFAULT '0' COMMENT '金額',
		`tantosyaCD` integer(6) NOT NULL DEFAULT '0' COMMENT '担当者CD',
		`tantosyaNM` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '担当者名'
	) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='工事管理表 経費';

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
