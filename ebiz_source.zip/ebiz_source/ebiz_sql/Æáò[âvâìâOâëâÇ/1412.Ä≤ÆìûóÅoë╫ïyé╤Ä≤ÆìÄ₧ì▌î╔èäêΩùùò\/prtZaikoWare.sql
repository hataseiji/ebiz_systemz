DROP PROCEDURE IF EXISTS prtZaikoWare;
DELIMITER //
CREATE PROCEDURE prtZaikoWare(
    IN _i_syouhinCDfr        varchar(10),
    IN _i_syouhinCDto        varchar(10),
    IN _i_jutyuuDatefr       date,
    IN _i_jutyuuDateto       date,
    IN _i_noukifr            date,
    IN _i_noukito            date,
    IN _i_kaikeiNendofr      integer(4),
    IN _i_denpyouNOfr        integer(6),
    IN _i_denpyouNOto        integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象データ
     ========================================================================= */
    drop table if exists SZaikoWareNeta;
    create temporary table SZaikoWareNeta
        select
            Djutyuu.jutyuudate,
            Djutyuu.nouki,
            Djutyuu.kaikeiNendo,
            Djutyuu.denpyouNO,
            Djutyuu.syouhinCD,
            Djutyuu.syouhinNM,
            Djutyuu.soukoCD,
            Msouko.soukoNM,
            Djutyuu.suryou as jutyuuSuu,
            Djutyuu.taniCD,
            Mtani.taniNM,
            IFNULL(Dsyukka.suryou, 0) as syukkaZumiSuu,
            IFNULL(Djutyuu.suryou, 0) - IFNULL(Dsyukka.suryou, 0) as miSyukkaZanSuu,
            (IFNULL(Dzaiko.zengetumatu_zaikosu, 0)
            - IFNULL(Dzaiko.tougetu_uriagesu, 0)
            - IFNULL(Dzaiko.tougetu_syukkosu, 0)
            - IFNULL(Dzaiko.tougetu_sonotasyukkosu, 0)
            - IFNULL(Dzaiko.tougetu_tanaorosigen, 0)
            + IFNULL(Dzaiko.tougetu_siiresu, 0)
            + IFNULL(Dzaiko.tougetu_nyuukosu, 0)
            + IFNULL(Dzaiko.tougetu_sonotanyuukosu, 0)
            + IFNULL(Dzaiko.tougetu_tanaorosizou, 0)
            - IFNULL(Dzaiko.yokugetu_uriagesu, 0)
            - IFNULL(Dzaiko.yokugetu_syukkosu, 0)
            - IFNULL(Dzaiko.yokugetu_sonotasyukkosu, 0)
            - IFNULL(Dzaiko.yokugetu_tanaorosigen, 0)
            + IFNULL(Dzaiko.yokugetu_siiresu, 0)
            + IFNULL(Dzaiko.yokugetu_nyuukosu, 0)
            + IFNULL(Dzaiko.yokugetu_sonotanyuukosu, 0)
            + IFNULL(Dzaiko.yokugetu_tanaorosizou, 0)) as genzaiZaiko
        from Djutyuu
        left outer join Msyouhin
        on  Msyouhin.syouhinCD = Djutyuu.syouhinCD
        left outer join Mtani
        on  Mtani.taniCD = Djutyuu.taniCD
        left outer join Msouko
        on  Msouko.soukoCD = Djutyuu.soukoCD
        left outer join (select
                            jutyuuKaikeiNendo,
                            jutyuuNO,
                            jutyuu_gyouNO,
                            sum(IFNULL(suryou, 0)) as suryou
                        from Dsyukka
                        Group by jutyuuKaikeiNendo,jutyuuNO,jutyuu_gyouNO) as Dsyukka
        on  Dsyukka.jutyuuKaikeiNendo = Djutyuu.kaikeiNendo
        and Dsyukka.jutyuuNO          = Djutyuu.denpyouNO
        and Dsyukka.jutyuu_gyouNO     = Djutyuu.gyouNO
        left outer join Dzaiko
        on  Dzaiko.soukoCD        = Djutyuu.soukoCD
        and Dzaiko.syouhinCD      = Djutyuu.syouhinCD
        and Dzaiko.keijounengetu  = Djutyuu.keijounengetu
        where 1 = 1
        and  Msyouhin.zaikokanriKBN = 0
        and  Djutyuu.kanryou_flg = 0
        and  Djutyuu.suryou > IFNULL(Dsyukka.suryou, 0)
        and  (_i_syouhinCDfr   = '' or Djutyuu.syouhinCD   >= _i_syouhinCDfr)
        and  (_i_syouhinCDto   = '' or Djutyuu.syouhinCD   <= _i_syouhinCDto)
        and  (_i_jutyuuDatefr  = 0 or Djutyuu.jutyuudate  >= _i_jutyuuDatefr)
        and  (_i_jutyuuDateto  = 0 or Djutyuu.jutyuudate  <= _i_jutyuuDateto)
        and  (_i_noukifr       = 0 or Djutyuu.nouki       >= _i_noukifr)
        and  (_i_noukito       = 0 or Djutyuu.nouki       <= _i_noukito)
        and  (_i_kaikeiNendofr = 0 or Djutyuu.kaikeiNendo =  _i_kaikeiNendofr)
        and  (_i_denpyouNOfr   = 0 or Djutyuu.denpyouNO   >= _i_denpyouNOfr)
        and  (_i_denpyouNOto   = 0 or Djutyuu.denpyouNO   <= _i_denpyouNOto)
        ;

    drop table if exists SZaikoWare;
    create temporary table SZaikoWare
        select
            SZaikoWareNeta.syouhinCD as syouhinCD,
            SZaikoWareNeta.syouhinNM as syouhinNM,
            SZaikoWareNeta.soukoCD as soukoCD,
            SZaikoWareNeta.soukoNM as soukoNM,
            CONCAT(year(SZaikoWareNeta.nouki) , '/',lpad(month(SZaikoWareNeta.nouki),2,'0'), '/',lpad(day(SZaikoWareNeta.nouki),2,'0') ) as pnouki ,
            CONCAT(year(SZaikoWareNeta.jutyuudate) , '/',lpad(month(SZaikoWareNeta.jutyuudate),2,'0'), '/',lpad(day(SZaikoWareNeta.jutyuudate),2,'0') ) as pjutyuudate ,
            concat_ws('-', SZaikoWareNeta.kaikeiNendo ,lpad(SZaikoWareNeta.denpyouNO,6,'0')) as pjutyuuNo ,
            SZaikoWareNeta.jutyuuSuu as jutyuuSuu,
            SZaikoWareNeta.taniCD as taniCD,
            SZaikoWareNeta.taniNM as taniNM,
            SZaikoWareNeta.syukkaZumiSuu as syukkaZumiSuu,
            SZaikoWareNeta.miSyukkaZanSuu as miSyukkaZanSuu,
            SZaikoWareNeta.genzaiZaiko as genzaiZaiko,
            SZaikoWareSum.jutyuuKei as jutyuuKei,
            SZaikoWareSum.syukkaZumiKei as syukkaZumiKei,
            SZaikoWareSum.miSyukkaZanKei as miSyukkaZanKei,
            case when SZaikoWareSum.miSyukkaZanKei > SZaikoWareNeta.genzaiZaiko
                THEN SZaikoWareSum.miSyukkaZanKei - SZaikoWareNeta.genzaiZaiko
                else 0
            end hojuuSuu,
            0 as zero
        from SZaikoWareNeta
        inner join (select syouhinCD, sum(jutyuuSuu) as jutyuuKei, sum(syukkaZumiSuu) as syukkaZumiKei, sum(miSyukkaZanSuu) as miSyukkaZanKei, sum(genzaiZaiko) as genzaiZaikokei from SZaikoWareNeta group by syouhinCD) as SZaikoWareSum
        on  SZaikoWareSum.syouhinCD = SZaikoWareNeta.syouhinCD
        Order by syouhinCD, nouki, kaikeiNendo, denpyouNO
        ;


    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
