DROP PROCEDURE IF EXISTS ins_Dmitumori;
DELIMITER //
CREATE PROCEDURE ins_Dmitumori (
    IN _i_kaikeiNendo          integer(4),
    IN _i_denpyouNO            integer(6),
    IN _i_gyouNO               integer(3),
    IN _i_seq                  integer(6),
    IN _i_akakuro              tinyint(1),
    IN _i_yuukou               tinyint(1),
    IN _i_keijounengetu        date,
    IN _i_dataKBN              tinyint(2),
    IN _i_torihikiKBN          tinyint(2),
    IN _i_mitumoriKBN          tinyint(2),
    IN _i_mitumoridate         date,
    IN _i_syukkadate           date,
    IN _i_nouki                date,
    IN _i_tokuisakiCD          integer(6),
    IN _i_tokuisakiNM          varchar(40),
    IN _i_soukoCD              integer(6),
    IN _i_TtyuumonNo           varchar(20),
    IN fmitumorianken1         varchar(40),
    IN fmitumorianken2         varchar(40),
    IN _i_denpyou_tekiyou1     varchar(40),
    IN _i_denpyou_tekiyou2     varchar(40),
    IN _i_syouhinCD            varchar(10),
    IN _i_syouhinNM            varchar(40),
    IN _i_suryou               decimal(10,3),
    IN _i_taniCD               tinyint(2),
    IN _i_tanka                decimal(8),
    IN _i_kingaku              decimal(10),
    IN _i_genkatanka           decimal(8),
    IN _i_genka_kingaku        decimal(10),
    IN _i_arari                decimal(10),
    IN _i_meisai_tekiyou       varchar(40),
    IN _i_hontai_kingaku       decimal(10),
    IN _i_inji_syouhizei       decimal(10),
    IN _i_kaikei_syouhizei     decimal(10),
    IN _i_insertdate           datetime,
    IN _i_insertTantosya       integer(6),
    OUT _o_ErrorMsg            varchar(256),
    OUT _o_Result              Boolean
)
BEGIN
    DECLARE _counter integer;

    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    select count(*) INTO _counter from Dmitumori where kaikeiNendo = _i_kaikeiNendo and denpyouNO = _i_denpyouNO and gyouNO = _i_gyouNO;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Dmitumori (
            kaikeiNendo,
            denpyouNO,
            gyouNO,
            seq,
            akakuro,
            yuukou,
            keijounengetu,
            dataKBN,
            torihikiKBN,
            mitumoriKBN,
            mitumoridate,
            syukkadate,
            nouki,
            tokuisakiCD,
            tokuisakiNM,
            soukoCD,
            TtyuumonNo,
            mitumriAnken1,
            mitumriAnken2,
            denpyou_tekiyou1,
            denpyou_tekiyou2,
            mmitumoriKBN,
            syouhinCD,
            syouhinNM,
            suryou,
            taniCD,
            tanka,
            kingaku,
            genka_tanka,
            genka_kingaku,
            arari,
            meisai_tekiyou,
            hontai_kingaku,
            inji_syouhizei,
            kaikei_syouhizei,
            DenpyouHakkou,
            insertdate,
            insertTantosya
        )
        values
        (
            _i_kaikeiNendo,
            _i_denpyouNO,
            _i_gyouNO,
            _i_seq,
            _i_akakuro,
            _i_yuukou,
            cal_KeijouDate(_i_mitumoridate),
            _i_dataKBN,
            _i_torihikiKBN,
            _i_mitumoriKBN,
            _i_mitumoridate,
            _i_syukkadate,
            _i_nouki,
            _i_tokuisakiCD,
            _i_tokuisakiNM,
            _i_soukoCD,
            _i_TtyuumonNo,
            fmitumorianken1,
            fmitumorianken2,
            _i_denpyou_tekiyou1,
            _i_denpyou_tekiyou2,
            _i_mitumoriKBN,
            _i_syouhinCD,
            _i_syouhinNM,
            _i_suryou,
            _i_taniCD,
            _i_tanka,
            _i_kingaku,
            _i_genkatanka,
            _i_genka_kingaku,
            _i_arari,
            _i_meisai_tekiyou,
            _i_hontai_kingaku,
            _i_inji_syouhizei,
            _i_kaikei_syouhizei,
            0,
            _i_insertdate,
            _i_insertTantosya
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
