DROP PROCEDURE IF EXISTS ins_Dzaiko;
DELIMITER //
CREATE PROCEDURE ins_Dzaiko (
    IN _i_soukoCD                   integer(6),
    IN _i_syouhinCD                 varchar(10),
    IN _i_keijounengetu             integer(6),
    IN _i_zengetumatu_zaikosu       decimal(12,3),
    IN _i_tougetu_uriagesu          decimal(12,3),
    IN _i_tougetu_syukkosu          decimal(12,3),
    IN _i_tougetu_sonotasyukkosu    decimal(12,3),
    IN _i_tougetu_tanaorosigen     decimal(12,3),
    IN _i_tougetu_siiresu           decimal(12,3),
    IN _i_tougetu_nyuukosu          decimal(12,3),
    IN _i_tougetu_sonotanyuukosu    decimal(12,3),
    IN _i_tougetu_tanaorosizou     decimal(12,3),
    IN _i_yokugetu_uriagesu         decimal(12,3),
    IN _i_yokugetu_syukkosu         decimal(12,3),
    IN _i_yokugetu_sonotasyukkosu   decimal(12,3),
    IN _i_yokugetu_tanaorosigen    decimal(12,3),
    IN _i_yokugetu_siiresu          decimal(12,3),
    IN _i_yokugetu_nyuukosu         decimal(12,3),
    IN _i_yokugetu_sonotanyuukosu	decimal(12,3),
    IN _i_yokugetu_tanaorosizou    decimal(12,3),
    IN _i_tanka                     decimal(8),
    IN _i_insertdate                datetime,
    IN _i_insertTantosya            integer(6),
    IN _i_updatedate                datetime,
    IN _i_updateTantosya            integer(6),
    OUT _o_ErrorMsg                 varchar(256),
    OUT _o_Result                   Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    select count(*) INTO _counter from Dzaiko where soukoCD = _i_soukoCD and syouhinCD = _i_syouhinCD and keijounengetu = _i_keijounengetu;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Dzaiko (
            soukoCD,
            syouhinCD,
            keijounengetu,
            zengetumatu_zaikosu,
            tougetu_uriagesu,
            tougetu_syukkosu,
            tougetu_sonotasyukkosu,
            tougetu_tanaorosigen,
            tougetu_siiresu,
            tougetu_nyuukosu,
            tougetu_sonotanyuukosu,
            tougetu_tanaorosizou,
            yokugetu_uriagesu,
            yokugetu_syukkosu,
            yokugetu_sonotasyukkosu,
            yokugetu_tanaorosigen,
            yokugetu_siiresu,
            yokugetu_nyuukosu,
            yokugetu_sonotanyuukosu,
            yokugetu_tanaorosizou,
            tanka,
            insertdate,
            insertTantosya,
            updatedate,
            updateTantosya
        )
        values
        (
            _i_soukoCD,
            _i_syouhinCD,
            _i_keijounengetu,
            _i_zengetumatu_zaikosu,
            _i_tougetu_uriagesu,
            _i_tougetu_syukkosu,
            _i_tougetu_sonotasyukkosu,
            _i_tougetu_tanaorosigen,
            _i_tougetu_siiresu,
            _i_tougetu_nyuukosu,
            _i_tougetu_sonotanyuukosu,
            _i_tougetu_tanaorosizou,
            _i_yokugetu_uriagesu,
            _i_yokugetu_syukkosu,
            _i_yokugetu_sonotasyukkosu,
            _i_yokugetu_tanaorosigen,
            _i_yokugetu_siiresu,
            _i_yokugetu_nyuukosu,
            _i_yokugetu_sonotanyuukosu,
            _i_yokugetu_tanaorosizou,
            _i_tanka,
            _i_insertdate,
            _i_insertTantosya,
            _i_updatedate,
            _i_updateTantosya
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
