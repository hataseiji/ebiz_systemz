DROP PROCEDURE IF EXISTS sel_Dmitumri;
DELIMITER //
CREATE PROCEDURE sel_Dmitumri (
    IN _i_kaikeiNendo      integer(4),
    IN _i_denpyouNO     integer(6),
    IN _i_gyouNO        integer(3),
    OUT _o_ErrorMsg     varchar(256),
    OUT _o_Result       Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    
    if _i_gyouNO IS NULL then
        select * from Dmitumri where kaikeinendo = _i_kaikeinendo and denpyouNO = _i_denpyouNO order by denpyouNO,gyouNO;
    else
        select * from Dmitumri where kaikeinendo = _i_kaikeinendo and denpyouNO = _i_denpyouNO and gyouNO = _i_gyouNO order by denpyouNO,gyouNO;
    end if;
    if _counter = 0 then
        set _o_ErrorMsg = '存在しないデータです。';
    else
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
