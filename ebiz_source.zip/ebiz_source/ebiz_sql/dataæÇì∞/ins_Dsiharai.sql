DROP PROCEDURE IF EXISTS ins_Dsiharai;
DELIMITER //
CREATE PROCEDURE ins_Dsiharai (
    IN _i_kaikeiNendo       integer(4),
    IN _i_denpyouNO         integer(6),
    IN _i_gyouNO            integer(3),
    IN _i_seq               integer(6),
    IN _i_akakuro           tinyint(1),
    IN _i_yuukou            tinyint(1),
    IN _i_keijounengetu     date,
    IN _i_dataKBN           integer(3),
    IN _i_torihikiKBN       integer(3),
    IN _i_siharaiKBN        integer(3),
    IN _i_siharaidate       date,
    IN _i_siharaisakiCD     integer(6),
    IN _i_denpyou_tekiyou1  varchar(40),
    IN _i_denpyou_tekiyou2  varchar(40),
    IN _i_msiharaiKBN       tinyint(2),
    IN _i_kingaku           decimal(10),
    IN _i_meisai_tekiyou    varchar(40),
    IN _i_hontai_kingaku    decimal(10,0),
    IN _i_syouhizei         decimal(10,0),
    IN _i_siharaisyoBangou  integer(6),
    IN _i_DenpyouHakkou     tinyint(1),
    IN _i_ginkouNM          varchar(40),
    IN _i_sitenNM           varchar(40),
    IN _i_tegatadate        date,
    IN _i_tegataNO          varchar(20),
    IN _i_furidasiNM        varchar(40),
    IN _i_insertdate          datetime,
    IN _i_insertTantosya      integer(6),
    OUT _o_ErrorMsg         varchar(256),
    OUT _o_Result           Boolean
)
BEGIN
    DECLARE _counter integer;

    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    select count(*) INTO _counter from Dsiharai where kaikeiNendo = _i_kaikeiNendo and denpyouNO = _i_denpyouNO and gyouNO = _i_gyouNO;
    if _counter > 0 then
        set _o_ErrorMsg = '既にマスタに存在するコードです。';
    else
        -- データ更新
        insert into Dsiharai (
            kaikeiNendo,
            denpyouNO,
            gyouNO,
            seq,
            akakuro,
            yuukou,
            keijounengetu,
            dataKBN,
            torihikiKBN,
            siharaiKBN,
            siharaidate,
            siharaisakiCD,
            denpyou_tekiyou1,
            denpyou_tekiyou2,
            msiharaiKBN,
            kingaku,
            meisai_tekiyou,
            hontai_kingaku,
            syouhizei,
            siharaisyoBangou,
            DenpyouHakkou,
            ginkouNM,
            sitenNM,
            tegatadate,
            tegataNO,
            furidasiNM,
            Krenkeidate,  -- 2013/10/13
            insertdate,
            insertTantosya
        )
        values
        (
            _i_kaikeiNendo,
            _i_denpyouNO,
            _i_gyouNO,
            _i_seq,
            _i_akakuro,
            _i_yuukou,
            cal_KeijouDate(_i_siharaidate),
            _i_dataKBN,
            _i_torihikiKBN,
            _i_siharaiKBN,
            _i_siharaidate,
            _i_siharaisakiCD,
            _i_denpyou_tekiyou1,
            _i_denpyou_tekiyou2,
            _i_msiharaiKBN,
            _i_kingaku,
            _i_meisai_tekiyou,
            _i_hontai_kingaku,
            _i_syouhizei,
            _i_siharaisyoBangou,
            0,
            _i_ginkouNM,
            _i_sitenNM,
            _i_tegatadate,
            _i_tegataNO,
            _i_furidasiNM,
            Null,  -- 2013/10/13
            _i_insertdate,
            _i_insertTantosya
        );
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
