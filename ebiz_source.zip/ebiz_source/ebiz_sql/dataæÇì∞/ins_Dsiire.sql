DROP PROCEDURE IF EXISTS ins_Dsiire;
DELIMITER //
CREATE PROCEDURE ins_Dsiire (
  IN _i_kaikeiNendo       integer(4),
  IN _i_denpyouNO         integer(6),
  IN _i_gyouNO            integer(3),
  IN _i_seq               integer(6),
  IN _i_akakuro           tinyint(1),
  IN _i_yuukou            tinyint(1),
  IN _i_keijounengetu     date,
  IN _i_dataKBN           tinyint(2),
  IN _i_torihikiKBN       tinyint(2),
  IN _i_siireKBN          tinyint(2),
  IN _i_hattyuuKaikeiNendo integer(4),
  IN _i_hattyuuNO         integer(6),
  IN _i_hattyuuGyouNO     integer(3),
  IN _i_nyuukaKaikeiNendo integer(4),
  IN _i_nyuukaNO          integer(6),
  IN _i_nyuukaGyouNO      integer(3),
  IN _i_siiredate         date,
  IN _i_nyuukadate        date,
  IN _i_ankenKaikeiNendo  integer(4),
  IN _i_ankenjutyuuNO     integer(6),
  IN _i_siiresakiCD       integer(6),
  IN _i_siiresakiNM       varchar(40),
  IN _i_soukoCD           integer(6),
  IN _i_denpyou_tekiyou1  varchar(40),
  IN _i_denpyou_tekiyou2  varchar(40),
  IN _i_msiireKBN         tinyint(2),
  IN _i_syouhinCD         varchar(10),
  IN _i_syouhinNM         varchar(40),
  IN _i_suryou            decimal(10,3),
  IN _i_taniCD            tinyint(2),
  IN _i_tanka             decimal(8),
  IN _i_kingaku           decimal(10),
  IN _i_meisai_tekiyou    varchar(40),
  IN _i_hontai_kingaku    decimal(10),
  IN _i_inji_syouhizei    decimal(10),
  IN _i_kaikei_syouhizei  decimal(10),
  IN _i_siharaisyoBangou  integer(6),
  IN _i_insertdate        datetime,
  IN _i_insertTantosya    integer(6),
  OUT _o_ErrorMsg         varchar(256),
  OUT _o_Result           Boolean
)
BEGIN
  DECLARE _counter integer;

  -- データ存在チェック
  set _o_Result = 0;
  set _o_ErrorMsg = '予期しないエラーが発生しました。';

  select count(*) INTO _counter from Dsiire where kaikeiNendo = _i_kaikeiNendo and denpyouNO = _i_denpyouNO and gyouNO = _i_gyouNO;
  if _counter > 0 then
    set _o_ErrorMsg = '既にマスタに存在するコードです。';
  else
    -- データ更新
    insert into Dsiire (
      kaikeiNendo,
      denpyouNO,
      gyouNO,
      seq,
      akakuro,
      yuukou,
      keijounengetu,
      dataKBN,
      torihikiKBN,
      siireKBN,
      hattyuuKaikeiNendo,
      hattyuuNO,
      hattyuu_gyouNO,
      nyuukaKaikeiNendo,
      nyuukaNO,
      nyuuka_gyouNO,
      siiredate,
      nyuukadate,
      ankenKaikeiNendo,
      ankenjutyuuNO,
      siiresakiCD,
      siiresakiNM,
      soukoCD,
      denpyou_tekiyou1,
      denpyou_tekiyou2,
      msiireKBN,
      syouhinCD,
      syouhinNM,
      suryou,
      taniCD,
      tanka,
      kingaku,
      meisai_tekiyou,
      hontai_kingaku,
      inji_syouhizei,
      kaikei_syouhizei,
      siharaisyoBangou,
      DenpyouHakkou,
      Krenkeidate,  -- 2013/10/13
      insertdate,
      insertTantosya
    )
    values
    (
      _i_kaikeiNendo,
      _i_denpyouNO,
      _i_gyouNO,
      _i_seq,
      _i_akakuro,
      _i_yuukou,
      cal_KeijouDate(_i_siiredate),
      _i_dataKBN,
      _i_torihikiKBN,
      _i_siireKBN,
      _i_hattyuuKaikeiNendo,
      _i_hattyuuNO,
      _i_hattyuuGyouNO,
      _i_nyuukaKaikeiNendo,
      _i_nyuukaNO,
      _i_nyuukaGyouNO,
      _i_siiredate,
      _i_nyuukadate,
      _i_ankenKaikeiNendo,
      _i_ankenjutyuuNO,
      _i_siiresakiCD,
      _i_siiresakiNM,
      _i_soukoCD,
      _i_denpyou_tekiyou1,
      _i_denpyou_tekiyou2,
      _i_msiireKBN,
      _i_syouhinCD,
      _i_syouhinNM,
      _i_suryou,
      _i_taniCD,
      _i_tanka,
      _i_kingaku,
      _i_meisai_tekiyou,
      _i_hontai_kingaku,
      _i_inji_syouhizei,
      _i_kaikei_syouhizei,
      _i_siharaisyoBangou,
      0,
      Null,  -- 2013/10/13
      _i_insertdate,
      _i_insertTantosya
    );
    set _o_Result = 1;
    set _o_ErrorMsg = '';
  end if;
END;
//
DELIMITER ;
