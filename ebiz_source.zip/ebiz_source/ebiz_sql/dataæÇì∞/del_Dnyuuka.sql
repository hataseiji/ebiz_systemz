DROP PROCEDURE IF EXISTS del_Dnyuuka;
DELIMITER //
CREATE PROCEDURE del_Dnyuuka (
    IN _i_kaikeiNendo      integer(4),
    IN _i_denpyouNO        integer(6),
    IN _i_gyouNO        integer(3),
    OUT _o_ErrorMsg        varchar(256),
    OUT _o_Result        Boolean
)
BEGIN
    DECLARE _counter integer;
    
    -- データ存在チェック
    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    if _i_gyouNO = 0 then
        select count(*) INTO _counter from Dnyuuka where kaikeinendo = _i_kaikeinendo and denpyouNO = _i_denpyouNO;
    else
        select count(*) INTO _counter from Dnyuuka where kaikeinendo = _i_kaikeinendo and denpyouNO = _i_denpyouNO and gyouNO = _i_gyouNO;
    end if;
    if _counter = 0 then
        set _o_ErrorMsg = 'マスタに存在しないコードです。';
    else
        -- データ更新
        if _i_gyouNO = 0 then
            delete from Dnyuuka where kaikeinendo = _i_kaikeinendo and denpyouNO = _i_denpyouNO;
        else
            delete from Dnyuuka where kaikeinendo = _i_kaikeinendo and denpyouNO = _i_denpyouNO and gyouNO = _i_gyouNO;
        end if;
        set _o_Result = 1;
        set _o_ErrorMsg = '';
    end if;
END;
//
DELIMITER ;
