DROP PROCEDURE IF EXISTS NenjiKakuteiKanri;
DELIMITER //
CREATE PROCEDURE NenjiKakuteiKanri(
    IN  _I_date         date,
    IN  _I_Tantosya     integer(6),
    OUT _o_ErrorMsg      varchar(256),
    OUT _o_Result        Boolean
)
BEGIN
/*
    年次更新
    基本情報管理マスタの更新を行います。
*/
    DECLARE _wDate              date;
    DECLARE _kaikei_yyyymm      integer; /* 処理年月 */
    DECLARE _keikatu_kisuu      integer;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    select keikatu_kisuu into _keikatu_kisuu from Mkanri where kanriCD=1;
    if _keikatu_kisuu = 12 then
        update Mkanri
        set
             kisyudate    =  kisyudate    + 10000
            ,kaikei_nendo =  kaikei_nendo + 1
            ,kessan_kisu  =  kessan_kisu  + 1
            ,keikatu_kisuu = 0
        where kanriCD=1;
    end if;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
