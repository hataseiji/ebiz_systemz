DROP PROCEDURE IF EXISTS siharaiMaeShoriCreateTable;
DELIMITER //
CREATE PROCEDURE siharaiMaeShoriCreateTable(
    IN _i_siharaisakiCD1     integer(6),
    IN _i_siharaisakiCD2     integer(6),
    IN _i_siharaisakiCD3     integer(6),
    IN _i_siharaisakiCD4     integer(6),
    IN _i_siharaisakiCD5     integer(6),
    IN _i_siharaisakiCD6     integer(6),
    IN _i_siharaisakiCD7     integer(6),
    IN _i_siharaisakiCD8     integer(6),
    IN _i_siharaisakiCD9     integer(6),
    IN _i_siharaisakiCD10    integer(6),
    IN _i_siharaisakiFrom    integer(6),
    IN _i_siharaisakiTo      integer(6),
    IN _i_siharainengetu     integer(6),
    IN _i_siharaiDateFrom    date,
    IN _i_siharaiDateTo      date,
    IN _i_simeBi             tinyint,
    IN _i_insertdate         date,
    IN _i_insertTantosya     integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* =========================================================================
     一時テーブル生成 今回対象仕入データ
     ========================================================================= */
    drop table if exists Ssiire;
    create temporary table Ssiire
        select
            DSIR.*
        from Dsiire as DSIR
        inner join Msiiresaki as MSIR  -- 得意先
        on DSIR.siiresakiCD = MSIR.siiresakiCD
        inner join (select siharaisakiCD,simebi1,simebi2,simebi3 from Msiiresaki where siharaisakiCD = siiresakiCD) as MSHR  -- 支払先
        on MSHR.siharaisakiCD = MSIR.siharaisakiCD
        -- 2013/05/25 start
        left outer join (select distinct siharaisakiCD,kaikeiNendo,siharaisyoBangou,siharainengetu,siharaikakuteidate from DsiharaiHead) as SHRH
        on  SHRH.siharaisakiCD = MSIR.siharaisakiCD
        and SHRH.kaikeiNendo = DSIR.kaikeiNendo
        and SHRH.siharaisyoBangou = DSIR.siharaisyoBangou
        -- 2013/05/25 end

        where
                (_i_siharaiDateFrom IS NULL or DSIR.siiredate >= _i_siharaiDateFrom)
            and (_i_siharaiDateTo IS NULL   or DSIR.siiredate <= _i_siharaiDateTo)
            and (_i_siharaisakiFrom = 0 or MSHR.siharaisakiCD >= _i_siharaisakiFrom)
            and (_i_siharaisakiTo = 0   or MSHR.siharaisakiCD <= _i_siharaisakiTo)
            and
            (
                (
                        _i_siharaisakiCD1 = 0 and _i_siharaisakiCD2 = 0
                    and _i_siharaisakiCD3 = 0 and _i_siharaisakiCD4 = 0
                    and _i_siharaisakiCD5 = 0 and _i_siharaisakiCD6 = 0
                    and _i_siharaisakiCD7 = 0 and _i_siharaisakiCD8 = 0
                    and _i_siharaisakiCD9 = 0 and _i_siharaisakiCD10 = 0
                )
                or
                (
                MSHR.siharaisakiCD in (_i_siharaisakiCD1,_i_siharaisakiCD2,_i_siharaisakiCD3,
                                        _i_siharaisakiCD4,_i_siharaisakiCD5,_i_siharaisakiCD6,
                                        _i_siharaisakiCD7,_i_siharaisakiCD8,_i_siharaisakiCD9,
                                        _i_siharaisakiCD10)
                )
            )
            and
            (
                   MSHR.simebi1 = _i_simeBi
                or MSHR.simebi2 = _i_simeBi
                or MSHR.simebi3 = _i_simeBi
            )
            -- 2013/05/25 start
            and SHRH.siharaikakuteidate IS NULL
            ;
            /*
            and
            -- 支払確定が終わってないもの
            not exists(select
                 SHRH.siharaisakiCD
                ,SHRH.kaikeiNendo
                ,SHRH.siharaisyoBangou
                from DsiharaiHead as SHRH
                where
                        SHRH.siharaisakiCD = MSIR.siharaisakiCD
                    and SHRH.kaikeiNendo = DSIR.kaikeiNendo
                    and SHRH.siharainengetu = _i_siharainengetu
                    and SHRH.simeBi = _i_simeBi
                    and SHRH.siharaisyoBangou = DSIR.siharaisyoBangou
                    and SHRH.siharaikakuteidate IS NOT NULL
                group by
                     SHRH.siharaisakiCD
                    ,SHRH.kaikeiNendo
                    ,SHRH.siharaisyoBangou
            );
            */
            -- 2013/05/25 end

    /* =========================================================================
     一時テーブル生成 今回対象入金データ
     ========================================================================= */
    drop table if exists SSiharai;
    create temporary table SSiharai
        select
                 DSHR.*
        from Dsiharai as DSHR
        inner join Msiiresaki as MSHR  -- 支払先
        on MSHR.siiresakiCD = DSHR.siharaisakiCD
        -- 2013/05/25 start
        left outer join (select distinct siharaisakiCD,kaikeiNendo,siharaisyoBangou,siharainengetu,siharaikakuteidate from DsiharaiHead) as SHRH
        on  SHRH.siharaisakiCD = DSHR.siharaisakiCD
        and SHRH.kaikeiNendo = DSHR.kaikeiNendo
        and SHRH.siharaisyoBangou = DSHR.siharaisyoBangou
        -- 2013/05/25 end
        where
                (_i_siharaiDateFrom IS NULL or DSHR.siharaidate >= _i_siharaiDateFrom)
            and (_i_siharaiDateTo IS NULL   or DSHR.siharaidate <= _i_siharaiDateTo)
            and (_i_siharaisakiFrom = 0 or DSHR.siharaisakiCD >= _i_siharaisakiFrom)
            and (_i_siharaisakiTo = 0   or DSHR.siharaisakiCD <= _i_siharaisakiTo)
            and
            (
                (
                        _i_siharaisakiCD1 = 0 and _i_siharaisakiCD2 = 0
                    and _i_siharaisakiCD3 = 0 and _i_siharaisakiCD4 = 0
                    and _i_siharaisakiCD5 = 0 and _i_siharaisakiCD6 = 0
                    and _i_siharaisakiCD7 = 0 and _i_siharaisakiCD8 = 0
                    and _i_siharaisakiCD9 = 0 and _i_siharaisakiCD10 = 0
                )
                or
                (
                DSHR.siharaisakiCD in (_i_siharaisakiCD1,_i_siharaisakiCD2,_i_siharaisakiCD3,
                                        _i_siharaisakiCD4,_i_siharaisakiCD5,_i_siharaisakiCD6,
                                        _i_siharaisakiCD7,_i_siharaisakiCD8,_i_siharaisakiCD9,
                                        _i_siharaisakiCD10)
                )
            )
            and
            (
                   MSHR.simebi1 = _i_simeBi
                or MSHR.simebi2 = _i_simeBi
                or MSHR.simebi3 = _i_simeBi
            )
            -- 2013/05/25 start
            and SHRH.siharaikakuteidate IS NULL
            ;
            /*
            and
            -- 支払確定が終わってないもの
            not exists(select
                 SHRH.siharaisakiCD
                ,SHRH.kaikeiNendo
                ,SHRH.siharaisyoBangou
                from DsiharaiHead as SHRH
                where
                        SHRH.siharaisakiCD = DSHR.siiresakiCD
                    and SHRH.kaikeiNendo = DSHR.kaikeiNendo
                    and SHRH.siharainengetu = _i_siharainengetu
                    and SHRH.simeBi = _i_simeBi
                    and SHRH.siharaisyoBangou = DSHR.siharaisyoBangou
                    and SHRH.siharaikakuteidate IS NOT NULL
                group by
                     SHRH.siharaisakiCD
                    ,SHRH.kaikeiNendo
                    ,SHRH.siharaisyoBangou
            );
            */

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
