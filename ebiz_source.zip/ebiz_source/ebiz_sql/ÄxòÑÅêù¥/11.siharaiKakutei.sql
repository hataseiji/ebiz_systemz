DROP PROCEDURE IF EXISTS siharaiKakutei;
DELIMITER //
CREATE PROCEDURE siharaiKakutei(
    IN  _i_kaikei_nendo       integer(4),
    IN  _i_siharainengetu     integer(6),
    IN  _i_simeBi             tinyint(2),
    IN  _i_siharaisakiFrom    integer(6),  -- 2013/06/09
    IN  _i_siharaisakiTo      integer(6),  -- 2013/06/09
    IN  _i_insertdate         date,
    IN  _i_insertTantosya     integer(6),
    OUT _o_ErrorMsg           varchar(256),
    OUT _o_Result             Boolean
)
BEGIN
/* =========================================================================
    支払確定処理
 ========================================================================= */
    DECLARE _siharaisakiCD      integer(6);
    DECLARE _siiregaku         decimal(12);
    DECLARE _hennpinngaku       decimal(12);
    DECLARE _nebikigaku         decimal(12);
    DECLARE _siharaigaku        decimal(12);
    DECLARE _syouhizeigaku      decimal(12);
    DECLARE _syouhizeisagaku    decimal(12);
    DECLARE _siharaisyoBangou   integer(6);
    DECLARE _kijun_kingaku      decimal(12);
    DECLARE _siharai_mm1        tinyint(2);
    DECLARE _siharai_dd1        tinyint(2);
    DECLARE _siharai_mm2        tinyint(2);
    DECLARE _siharai_dd2        tinyint(2);
    DECLARE _siharaisyubetu1     tinyint(2);
    DECLARE _siharaisyubetu2     tinyint(2);
    DECLARE _siharai_kingaku    decimal(12);
    DECLARE _hontai_kingaku     decimal(12);
    DECLARE _syouhizeiKei       decimal(12);
    DECLARE _siharai_kingaku1   decimal(12);
    DECLARE _siharai_kingaku2   decimal(12);

    DECLARE _wDate              date;
    DECLARE _wDate1             date;
    DECLARE _wDate2             date;
    DECLARE _counter            integer(6);

    DECLARE _aa                 tinyint DEFAULT 0;
    DECLARE done                INT DEFAULT 0;

    -- 2013/09/21 start
    DECLARE cursiharaiH CURSOR FOR
        select
             DSIH.siharaisakiCD         AS siharaisakiCD
            ,sum(DSIH.siiregaku)        AS siiregaku
            ,sum(DSIH.hennpinngaku)     AS hennpinngaku
            ,sum(DSIH.nebikigaku)       AS nebikigaku
            ,sum(DSIH.siharaigaku)      AS siharaigaku
            ,sum(DSIH.syouhizeigaku)    AS syouhizeigaku
            ,sum(DSIH.syouhizeisagaku)  AS syouhizeisagaku
            ,min(DSIH.siharaisyoBangou) AS siharaisyoBangou
            ,min(MSIR.kijun_kingaku)    AS kijun_kingaku
            ,min(MSIR.siharai_mm1)      AS siharai_mm1
            ,min(MSIR.siharai_dd1)      AS siharai_dd1
            ,min(MSIR.siharai_mm2)      AS siharai_mm2
            ,min(MSIR.siharai_dd2)      AS siharai_dd2
            ,min(MSIR.siharaisyubetu1)  AS siharaisyubetu1
            ,min(MSIR.siharaisyubetu2)  AS siharaisyubetu2
        from DsiharaiHead DSIH
        inner join Msiiresaki as MSIR -- 支払先
        on MSIR.siiresakiCD   = DSIH.siharaisakiCD
        where
            DSIH.kaikeiNendo        = _i_kaikei_nendo
            and DSIH.siharainengetu = _i_siharainengetu
            and DSIH.simebi         = _i_simeBi
            and (_i_siharaisakiFrom = 0 or DSIH.siharaisakiCD >= _i_siharaisakiFrom) -- 2013/06/09
            and (_i_siharaisakiTo = 0   or DSIH.siharaisakiCD <= _i_siharaisakiTo)   -- 2013/06/09
            -- and MSEI.kaisyuu_mm1    <> 0    -- 回収月1が入力されてない場合は回収予定データの作成は無し。
            and MSIR.siharai_dd1    <> 0
        Group by DSIH.siharaisakiCD;
    -- 2013/09/21 end

    -- 2013/09/21 start
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';
    -- 2013/09/21 end

    /* =============================================================================
       支払ヘッダ  支払確定日時・次回繰越額更新
     ========================================================================= */

    update DsiharaiHead
        set
         jikaikurikosigaku = ZENZAN + siiregaku + hennpinngaku + nebikigaku - siharaigaku + syouhizeigaku + syouhizeisagaku
    where
        kaikeiNendo    = _i_kaikei_nendo
    and siharainengetu = _i_siharainengetu
    and simebi         = _i_simeBi
    and (_i_siharaisakiFrom = 0 or siharaisakiCD >= _i_siharaisakiFrom) -- 2014/02/08
    and (_i_siharaisakiTo = 0   or siharaisakiCD <= _i_siharaisakiTo)   -- 2014/02/08
    ;

    /* =============================================================================
       支払予定データ生成
     ========================================================================= */
    -- 2013/09/21 start
    OPEN cursiharaiH;

    REPEAT
    FETCH cursiharaiH
    INTO _siharaisakiCD, _siiregaku, _hennpinngaku, _nebikigaku, _siharaigaku, _syouhizeigaku, _syouhizeisagaku, _siharaisyoBangou, _kijun_kingaku, _siharai_mm1, _siharai_dd1, _siharai_mm2, _siharai_dd2, _siharaisyubetu1, _siharaisyubetu2;
    IF done = 0 THEN

        /* 2013/09/23 start
        支払額は支払予定としては加味しない。発生している支払額はどこかの支払予定でで消し込まれてる。
        SET _siharai_kingaku = _siiregaku + _hennpinngaku + _nebikigaku - _siharaigaku + _syouhizeigaku + _syouhizeisagaku;
        SET _hontai_kingaku  = _siiregaku + _hennpinngaku + _nebikigaku - _siharaigaku;
        */
        SET _siharai_kingaku = _siiregaku + _hennpinngaku + _nebikigaku + _syouhizeigaku + _syouhizeisagaku;
        SET _hontai_kingaku  = _siiregaku + _hennpinngaku + _nebikigaku ;
        SET _syouhizeiKei    = _syouhizeigaku + _syouhizeisagaku;
        -- 2013/09/23 end

        -- 回収予定日1算出
        IF _siharai_dd1 <> 31 THEN
            SET _wDate1 = _i_siharainengetu * 100 + _siharai_dd1;
            if _wDate1 IS NULL THEN
                SET _wDate1 = _i_siharainengetu * 100 + 1;
                SET _wDate1 = LAST_DAY(_wDate1);
            end if;
            SET _wDate1 = _wDate1 + INTERVAL _siharai_mm1 MONTH;
        ELSE
            SET _wDate1 = _i_siharainengetu * 100 + 1;
            SET _wDate1 = _wDate1 + INTERVAL _siharai_mm1 MONTH;
            SET _wDate1 = LAST_DAY(_wDate1);
        END IF;

        -- 回収予定日2算出
        IF _siharai_mm2 <> 0 AND _siharai_dd2 <> 0 THEN
            IF _siharai_dd2 <> 31 THEN
                SET _wDate2 = _i_siharainengetu * 100 + _siharai_dd2;
                if _wDate1 IS NULL THEN
                    SET _wDate2 = _i_siharainengetu * 100 + 1;
                    SET _wDate2 = LAST_DAY(_wDate2);
                end if;
                SET _wDate2 = _wDate2 + INTERVAL _siharai_mm2 MONTH;
            ELSE
                SET _wDate2 = _i_siharainengetu * 100 + 1;
                SET _wDate2 = _wDate2 + INTERVAL _siharai_mm2 MONTH;
                SET _wDate2 = LAST_DAY(_wDate2);
            END IF;
            -- SET _wDate2 = _wDate2 + INTERVAL _siharai_mm2 MONTH;
        ELSE
            SET _wDate2 = _wDate1;
        END IF;

        IF _siharai_kingaku > _kijun_kingaku and _kijun_kingaku <> 0 THEN
        --  基準金額が存在して支払額が上回っている時に回収予定が分割される
            SET _siharai_kingaku1 = _kijun_kingaku;
            SET _siharai_kingaku2 = _siharai_kingaku - _kijun_kingaku;
        ELSE
            SET _siharai_kingaku1 = _siharai_kingaku;
            SET _siharai_kingaku2 = 0;
        END IF;


        select count(*) INTO _counter from Dsiharaiyotei where siharaisakiCD = _siharaisakiCD and siharaiyoteidate = _wDate1 and siharaisyubetu = _siharaisyubetu1 and simebi = _i_simeBi;
        IF _counter = 0 THEN
            insert into Dsiharaiyotei (
                 siharaisakiCD
                ,siharaiyoteidate
                ,siharaisyubetu
                ,simebi
                ,siharaiyoteigaku
                ,hontai_kingaku
                ,syouhizei
                ,siharai_kesikomigaku
                ,siharainengetu
                ,siharaisyoBangou
                ,kanryouKBN
                ,tegataBangou
                ,tegataKijitu
                ,tegataFuridasinin
                ,insertdate
                ,insertTantosya
            ) values (
                 _siharaisakiCD
                ,_wDate1
                ,_siharaisyubetu1
                ,_i_simeBi
                ,_siharai_kingaku1
                ,_hontai_kingaku
                ,_syouhizeiKei
                ,0
                ,_i_siharainengetu
                ,_siharaisyoBangou
                ,0
                ,''
                ,'2000-01-01'
                ,''
                ,_i_insertdate
                ,_i_insertTantosya
            );
        END IF;

        IF _siharai_kingaku > _kijun_kingaku and _kijun_kingaku <> 0 THEN
        -- 基準金額が存在して支払額が上回っている時に支払予定が分割される。
        -- 支払が分割される場合

            select count(*) INTO _counter from Dsiharaiyotei where siharaisakiCD = _siharaisakiCD and siharaiyoteidate = _wDate2 and siharaisyubetu = _siharaisyubetu2 and simebi = _i_simeBi;
            IF _counter = 0 THEN
                insert into Dsiharaiyotei (
                     siharaisakiCD
                    ,siharaiyoteidate
                    ,siharaisyubetu
                    ,simebi
                    ,siharaiyoteigaku
                    ,hontai_kingaku
                    ,syouhizei
                    ,siharai_kesikomigaku
                    ,siharainengetu
                    ,siharaisyoBangou
                    ,kanryouKBN
                    ,tegataBangou
                    ,tegataKijitu
                    ,tegataFuridasinin
                    ,insertdate
                    ,insertTantosya
                ) values (
                     _siharaisakiCD
                    ,_wDate2
                    ,_siharaisyubetu2
                    ,_i_simeBi
                    ,_siharai_kingaku2
                    ,0
                    ,0
                    ,0
                    ,_i_siharainengetu
                    ,_siharaisyoBangou
                    ,0
                    ,''
                    ,'2000-01-01'
                    ,''
                    ,_i_insertdate
                    ,_i_insertTantosya
                );
            END IF;
        END IF;
    END IF;
    UNTIL done END REPEAT;
    CLOSE cursiharaiH;
    -- 2013/09/21 end

    /* =============================================================================
       支払ヘッダ  支払確定日時・次回繰越額更新
     ========================================================================= */

    update DsiharaiHead
        set
         kakuteiKBN = 1
        ,siharaikakuteidate = Now()
    where
        kaikeiNendo    = _i_kaikei_nendo
    and siharainengetu = _i_siharainengetu
    and simebi         = _i_simeBi
    and (_i_siharaisakiFrom = 0 or siharaisakiCD >= _i_siharaisakiFrom) -- 2014/02/08
    and (_i_siharaisakiTo = 0   or siharaisakiCD <= _i_siharaisakiTo)   -- 2014/02/08
    ;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
