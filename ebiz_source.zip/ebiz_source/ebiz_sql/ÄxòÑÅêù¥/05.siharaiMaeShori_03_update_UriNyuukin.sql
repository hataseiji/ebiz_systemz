DROP PROCEDURE IF EXISTS siharaiMaeShori_03_update_UriNyuukin;
DELIMITER //
CREATE PROCEDURE siharaiMaeShori_03_update_UriNyuukin(
    IN _i_siharainengetu     integer(6),
    IN _i_simeBi             tinyint,
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    /* =============================
       仕入・入金データに支払書番号を更新
     ============================ */
    DECLARE _siharaisakiCD           integer(6) DEFAULT 0;
    DECLARE _kaikei_nendo            integer(4);
    DECLARE _kaikeinendo             integer(4);
    DECLARE _denpyouNO               integer(6);  -- 伝票番号取得時にも使用
    DECLARE _gyouNO                  integer(3);
    DECLARE _dataKBN                   tinyint DEFAULT 0;
    DECLARE _torihikiKBN               tinyint DEFAULT 0;
    DECLARE _siharaisyoBangou          integer(6) DEFAULT 0;
    DECLARE _aa                        tinyint DEFAULT 0;
    DECLARE done                       INT DEFAULT 0;

    DECLARE curUriSiharai CURSOR FOR
        (
            select
                 SURI.kaikeiNendo      AS kaikeiNendo
                ,SURI.denpyouNO        AS denpyouNO
                ,SURI.gyouNO           AS gyouNO
                ,MTOK.siharaisakiCD    AS siharaisakiCD
                ,SURI.dataKBN          AS dataKBN
                ,SURI.torihikiKBN      AS torihikiKBN
                ,DSHD.siharaisyoBangou AS siharaisyoBangou
            from Ssiire SURI
            inner join Msiiresaki as MTOK -- 得意先
            on MTOK.siiresakiCD   = SURI.siiresakiCD
            inner join DsiharaiHead as DSHD
            on  DSHD.siharaisakiCD  = MTOK.siharaisakiCD
            and DSHD.kaikeiNendo    = _kaikei_nendo
            and DSHD.siharainengetu = _i_siharainengetu
            and DSHD.simebi         = _i_simeBi
        )
        UNION ALL
        (
            select
                 SNYU.kaikeiNendo      AS kaikeiNendo
                ,SNYU.denpyouNO        AS denpyouNO
                ,SNYU.gyouNO           AS gyouNO
                ,SNYU.siharaisakiCD    AS siharaisakiCD
                ,SNYU.dataKBN          AS dataKBN
                ,SNYU.torihikiKBN      AS torihikiKBN
                ,DSHD.siharaisyoBangou AS siharaisyoBangou
            from SSiharai SNYU
            inner join DsiharaiHead as DSHD
            on  DSHD.siharaisakiCD  = SNYU.siharaisakiCD
            and DSHD.kaikeiNendo    = _kaikei_nendo
            and DSHD.siharainengetu = _i_siharainengetu
            and DSHD.simebi         = _i_simeBi
        )
        ORDER by
                 kaikeiNendo
                ,denpyouNO
                ,gyouNO;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

    /* 管理マスタより会計年度を取得 */
    select kaikei_nendo into _kaikei_nendo from MKanri where kanriCD = 1;

    -- 仕入・入金データ更新開始
    OPEN curUriSiharai;

    REPEAT
    FETCH curUriSiharai
    INTO _kaikeiNendo, _denpyouNO, _gyouNO, _siharaisakiCD, _dataKBN, _torihikiKBN, _siharaisyoBangou;
    IF done = 0 THEN
        IF _dataKBN = 80 THEN
            update Dsiire  SET siharaisyoBangou = _siharaisyoBangou where kaikeiNendo = _kaikeiNendo and denpyouNO = _denpyouNO and gyouNO = _gyouNO;
        ELSE
            update Dsiharai SET siharaisyoBangou = _siharaisyoBangou where kaikeiNendo = _kaikeiNendo and denpyouNO = _denpyouNO and gyouNO = _gyouNO;
        END IF;
    END IF;
    UNTIL done END REPEAT;

    CLOSE curUriSiharai;

    set _o_Result = 1;
    set _o_ErrorMsg = '';
END;
//
DELIMITER ;
