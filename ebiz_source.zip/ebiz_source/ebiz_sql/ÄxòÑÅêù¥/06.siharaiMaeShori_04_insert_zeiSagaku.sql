DROP PROCEDURE IF EXISTS siharaiMaeShori_04_insert_zeiSagaku;
DELIMITER //
CREATE PROCEDURE siharaiMaeShori_04_insert_zeiSagaku(
    IN _i_siharainengetu     integer(6),
    IN _i_simeBi             tinyint,
    IN _i_insertdate         date,
    IN _i_insertTantosya     integer(6),
    OUT _o_ErrorMsg          varchar(256),
    OUT _o_Result            Boolean
)
BEGIN
    /* =============================
       仕入データに消費税差額データを追加
     ============================ */
    DECLARE _siharaisakiCD           integer(6) DEFAULT 0;
    DECLARE _kaikeinendo             integer(4);
    DECLARE _siiredate              date;
    DECLARE _denpyouNumber           integer(6);  -- 伝票番号取得時にも使用
    DECLARE _gyouNO                  integer(3);
    DECLARE _kingaku                 decimal(10);
    DECLARE _hontai_kingaku          decimal(10);
    DECLARE _syouhizei               decimal(10);
    DECLARE _siharaisyoBangou        integer(6);
    DECLARE _syouhinCD               varchar(10);
    DECLARE _syouhinNM               varchar(40);
    DECLARE _O_utiZeinukigaku        decimal(10);
    DECLARE _O_sotoZei               decimal(10);
    DECLARE _O_utiZei                decimal(10);
    DECLARE _sum_hontai_kingaku      decimal(10) DEFAULT 0;
    DECLARE _sum_syouhizei           decimal(10) DEFAULT 0;
    DECLARE _break_siharaisakiCD     integer(6) DEFAULT 0;
    DECLARE _break_kaikeinendo       integer(4);
    DECLARE _break_siiredate        date;
    DECLARE _break_denpyouNumber     integer(6);  -- 伝票番号取得時にも使用
    DECLARE _break_gyouNO            integer(3);
    DECLARE _break_siharaisyoBangou  integer(6);
    DECLARE _aa                      tinyint DEFAULT 0;
    DECLARE done                     INT DEFAULT 0;
    DECLARE _ErrorMsg        varchar(256);
    DECLARE _Result          Boolean;

    DECLARE curZeiSagaku CURSOR FOR
        select
             MSIR.siharaisakiCD
            ,DSIR.kaikeiNendo
            ,DSIR.siiredate
            ,DSIR.denpyouNO
            ,DSIR.gyouNO
            ,DSIR.hontai_kingaku
            ,DSIR.kaikei_syouhizei
            ,DSIR.siharaisyoBangou
        from Dsiire as DSIR
        inner join Ssiire as SURI     -- 今回支払対象のデータを抽出済み
        on  SURI.kaikeiNendo = DSIR.kaikeiNendo
        and SURI.denpyouNO   = DSIR.denpyouNO
        and SURI.gyouNO      = DSIR.gyouNO
        inner join Msiiresaki as MSIR  -- 仕入先
        on MSIR.siiresakiCD   = DSIR.siiresakiCD
        left outer join Msyouhin as MSYO
        on MSYO.syouhinCD     = DSIR.syouhinCD
        where DSIR.dataKBN        = 80 -- 仕入
        and   MSIR.zeisansyutuKBN = 2  -- 支払時一括
        and   MSYO.sotoutiKBN     = 0  -- 外税
        ORDER by
             MSIR.siharaisakiCD
            ,DSIR.kaikeiNendo
            ,DSIR.denpyouNO
            ,DSIR.gyouNO;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

    set _o_Result = 0;
    set _o_ErrorMsg = '予期しないエラーが発生しました。';

  select min(syouhinCD) , min(syouhinNM) into _syouhinCD, _syouhinNM from Msyouhin where zeisyohinKBN       = 1;

    -- 消費税差額データ作成処理開始
    OPEN curZeiSagaku;

    SET _aa = 0;
    REPEAT
    FETCH curZeiSagaku
    INTO _siharaisakiCD, _kaikeinendo, _siiredate, _denpyouNumber, _gyouNO, _hontai_kingaku, _syouhizei, _siharaisyoBangou;
    IF NOT done THEN
        IF _aa <> 0 and _siharaisakiCD <> _break_siharaisakiCD THEN
            -- ブレイク処理
            -- 消費税算出
            call GetZei(
                 80
                ,_break_siiredate
                ,_break_siharaisakiCD
                ,0
                ,_sum_hontai_kingaku
                ,_O_utiZeinukigaku
                ,_O_sotoZei
                ,_O_utiZei
            );
            /*
                _I_dataKBN          50:仕入入金/80:仕入支払
                _I_date             消費税算出基準日(仕入計上日)
                _I_torihikisakiCD   支払先CDまたは支払先CD
                _I_zeikomiKingaku   これから内税を算出
                _I_zeinukiKingaku   これから外税を算出
                _O_utiZeinukigaku   内税の税抜額が返される
                _O_sotoZei          外税の消費税額が返される
                _O_utiZei           内税の消費税額が返される
                _zeisansyutuKBN     0:明細単位 1:伝票単位 2:支払時一括 3:計算しない
                _zeihasuuKBN        0:四捨五入 1:切捨て 2:切上げ
                内税の算出方法         内税額 = 税込額 - (税込額 / 1.05)
            */
            IF _O_sotoZei <> _sum_syouhizei THEN
            -- 伝票番号取得
            SET @kaikei_yyyy = 0;
            SET @DenpyouNumber = 0;
            call GetDenpyouNumber(
                  80
                 ,@kaikei_yyyy
                 ,@DenpyouNumber);
                -- 消費税差額データinsert
                call ins_Dsiire(
                     @kaikei_yyyy
                    ,@DenpyouNumber
                    ,1
                    ,1
                    ,0
                    ,0
                    ,_break_siiredate
                    ,80
                    ,82
                    ,80
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,_break_siiredate
                    ,_break_siiredate
                    ,0
                    ,0
                    ,_break_siharaisakiCD
                    ,''
                    ,999999
                    ,''
                    ,''
                    ,80
                    ,_syouhinCD
                    ,_syouhinNM
                    ,0
                    ,0
                    ,0
                    ,0
                    ,''
                    ,0
                    ,_O_sotoZei                     -- 印字用消費税
                    ,_O_sotoZei - _sum_syouhizei    -- 会計用消費税
                    ,_break_siharaisyoBangou
                    ,_i_insertdate
                    ,_i_insertTantosya
                    ,_ErrorMsg
                    ,_Result
                    );                -- 支払ヘッダに反映
                update DsiharaiHead
                    SET syouhizeisagaku = syouhizeisagaku + _O_sotoZei - _sum_syouhizei
                        ,gkmn_syouhizeisagaku = gkmn_syouhizeisagaku + _O_sotoZei - _sum_syouhizei
                        ,jikaikurikosigaku = jikaikurikosigaku + _O_sotoZei - _sum_syouhizei
                where siharaisakiCD  = _break_siharaisakiCD
                and   kaikeiNendo    = _break_kaikeinendo
                and   siharainengetu = _i_siharainengetu
                and   simebi         = _i_simeBi;

            END IF;

            SET _sum_hontai_kingaku = 0;
            SET _sum_syouhizei      = 0;

        END IF;

        SET _break_siharaisakiCD    = _siharaisakiCD;
        SET _break_kaikeinendo      = _kaikeinendo;
        SET _break_siiredate       = _siiredate;
        SET _break_gyouNO           = _gyouNO;
        SET _break_siharaisyoBangou = _siharaisyoBangou;
        SET _sum_hontai_kingaku     = _sum_hontai_kingaku + _hontai_kingaku;
        SET _sum_syouhizei          = _sum_syouhizei      + _syouhizei;
        SET _aa = 1;

    END IF;
    UNTIL done END REPEAT;

    IF _aa <> 0 THEN
    -- ブレイク処理
        -- 消費税算出
        call GetZei(
             80
            ,_break_siiredate
            ,_break_siharaisakiCD
            ,0
            ,_sum_hontai_kingaku
            ,_O_utiZeinukigaku
            ,_O_sotoZei
            ,_O_utiZei
        );
        /*
            _I_dataKBN          50:仕入入金/80:仕入支払
            _I_date             消費税算出基準日(仕入計上日)
            _I_torihikisakiCD   支払先CDまたは支払先CD
            _I_zeikomiKingaku   これから内税を算出
            _I_zeinukiKingaku   これから外税を算出
            _O_utiZeinukigaku   内税の税抜額が返される
            _O_sotoZei          外税の消費税額が返される
            _O_utiZei           内税の消費税額が返される
            _zeisansyutuKBN     0:明細単位 1:伝票単位 2:支払時一括 3:計算しない
            _zeihasuuKBN        0:四捨五入 1:切捨て 2:切上げ
            内税の算出方法         内税額 = 税込額 - (税込額 / 1.05)
        */
        IF _O_sotoZei <> _sum_syouhizei THEN
            -- 伝票番号取得
            SET @kaikei_yyyy = 0;
            SET @DenpyouNumber = 0;
            call GetDenpyouNumber(
                  80
                 ,@kaikei_yyyy
                 ,@DenpyouNumber);
            -- 消費税差額データinsert
            call ins_Dsiire(
                     @kaikei_yyyy
                    ,@DenpyouNumber
                    ,1
                    ,1
                    ,0
                    ,0
                    ,_break_siiredate
                    ,80
                    ,82
                    ,80
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,0
                    ,_break_siiredate
                    ,_break_siiredate
                    ,0
                    ,0
                    ,_break_siharaisakiCD
                    ,''
                    ,999999
                    ,''
                    ,''
                    ,80
                    ,_syouhinCD
                    ,_syouhinNM
                    ,0
                    ,0
                    ,0
                    ,0
                    ,''
                    ,0
                    ,_O_sotoZei                     -- 印字用消費税
                    ,_O_sotoZei - _sum_syouhizei    -- 会計用消費税
                    ,_break_siharaisyoBangou
                    ,_i_insertdate
                    ,_i_insertTantosya
                    ,_ErrorMsg
                    ,_Result
                    );                -- 支払ヘッダに反映

                -- 支払ヘッダに反映
                update DsiharaiHead
                    SET syouhizeisagaku = syouhizeisagaku + _O_sotoZei - _sum_syouhizei
                        ,gkmn_syouhizeisagaku = gkmn_syouhizeisagaku + _O_sotoZei - _sum_syouhizei
                        ,jikaikurikosigaku = jikaikurikosigaku + _O_sotoZei - _sum_syouhizei
                where siharaisakiCD  = _break_siharaisakiCD
                and   kaikeiNendo    = _break_kaikeinendo
                and   siharainengetu = _i_siharainengetu
                and   simebi         = _i_simeBi;
        END IF;
    END IF;

    CLOSE curZeiSagaku;

    set _o_Result = 1;
    set _o_ErrorMsg = '';

END;
//
DELIMITER ;
